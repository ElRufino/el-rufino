<?php
/*
Plugin Name: El Rufino — Panel
Description: Panel operativo completo con 14 módulos, 11 agentes, registro de promesas persistente y contexto IA.
Version: 7.0.1
Author: El Rufino
*/

if (!defined('ABSPATH')) exit;

// ============================================================
// 1. BASE DE DATOS
// ============================================================
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table   = $wpdb->prefix . 'er_promesas';
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id           mediumint(9)  NOT NULL AUTO_INCREMENT,
        fecha        datetime      DEFAULT CURRENT_TIMESTAMP NOT NULL,
        funcionario  varchar(100)  NOT NULL,
        promesa      text          NOT NULL,
        estado       varchar(20)   DEFAULT 'Abierta' NOT NULL,
        pilar        varchar(10)   DEFAULT '' NOT NULL,
        fuente       varchar(255)  DEFAULT '' NOT NULL,
        evidencia    text          DEFAULT '' NOT NULL,
        fecha_prom   date          DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    add_option('el_rufino_do_redirect', true);
});

// ============================================================
// 2. REDIRECCION AL ACTIVAR
// ============================================================
add_action('admin_init', function() {
    if (get_option('el_rufino_do_redirect', false)) {
        delete_option('el_rufino_do_redirect');
        wp_safe_redirect(admin_url('admin.php?page=el-rufino-panel'));
        exit;
    }
});

// ============================================================
// 3. FULLSCREEN CSS — v7: oculta barra WP completamente
// ============================================================
add_action('admin_enqueue_scripts', function($hook) {
    if (!isset($_GET['page']) || $_GET['page'] !== 'el-rufino-panel') return;
    wp_enqueue_style(
        'er-panel',
        plugin_dir_url(__FILE__) . 'panel.css',
        [],
        '7.0.1'
    );
});

add_action('admin_head', function() {
    if (!isset($_GET['page']) || $_GET['page'] !== 'el-rufino-panel') return;
    echo '<style>
        #adminmenuback,#adminmenuwrap,#adminmenu,#wpadminbar,#wpfooter,
        body.wp-admin #wpadminbar,
        body.admin-bar #wpadminbar,
        .wp-responsive-overlay,.update-nag,.notice,.is-dismissible,
        #screen-meta-links,#screen-meta,.screen-meta-toggle,
        #wpbody>.wrap,.wrap>h1,.wrap>h2{display:none!important;visibility:hidden!important}
        html,body,body.admin-bar{overflow:hidden!important;margin:0!important;padding:0!important;background:#f5f0e8!important;padding-top:0!important}
        html.wp-toolbar{padding-top:0!important}
        #wpcontent,#wpbody,#wpbody-content{margin:0!important;padding:0!important;float:none!important;width:100%!important}
        #wpwrap{overflow:hidden!important}
        #el-rufino-fullscreen{position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;z-index:999999!important;overflow:hidden!important;background:#f5f0e8!important}
    </style>
    <script>
        document.documentElement.classList.remove("wp-toolbar");
        document.addEventListener("DOMContentLoaded", function() {
            document.body.style.paddingTop = "0";
            var bar = document.getElementById("wpadminbar");
            if (bar) bar.style.display = "none";
        });
    </script>';
});

// ============================================================
// 4. MENU
// ============================================================
add_action('admin_menu', function() {
    add_menu_page('El Rufino', 'El Rufino', 'manage_options', 'el-rufino-panel', 'er_render_panel', 'dashicons-media-document', 2);
});

// ============================================================
// 5. RENDER
// ============================================================
function er_render_panel() {
    echo '<div id="el-rufino-fullscreen">';
    include plugin_dir_path(__FILE__) . 'panel.html';
    echo '</div>';
}

// ============================================================
// 6. INYECTAR VARIABLES JS — v7: agrega siteUrl y adminUrl
// ============================================================
add_action('admin_footer', function() {
    if (!isset($_GET['page']) || $_GET['page'] !== 'el-rufino-panel') return;
    $theme = wp_get_theme();
    ?>
    <script>
    var erAjax = {
        url:           "<?php echo esc_url(admin_url('admin-ajax.php')); ?>",
        nonce:         "<?php echo wp_create_nonce('er_nonce'); ?>",
        mediaUrl:      "<?php echo esc_url(admin_url('media-new.php')); ?>",
        customizerUrl: "<?php echo esc_url(admin_url('customize.php')); ?>",
        siteUrl:       "<?php echo esc_url(get_site_url()); ?>",
        adminUrl:      "<?php echo esc_url(admin_url()); ?>",
        themeVersion:  "<?php echo esc_js($theme->get('Version')); ?>",
        themeName:     "<?php echo esc_js($theme->get('Name')); ?>"
    };
    </script>
    <?php
});

// ============================================================
// 7. AJAX — GUARDAR PROMESA
// ============================================================
add_action('wp_ajax_er_save_promesa', function() {
    check_ajax_referer('er_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos');
    global $wpdb;
    $table = $wpdb->prefix . 'er_promesas';
    $data = [
        'funcionario' => sanitize_text_field($_POST['funcionario'] ?? ''),
        'promesa'     => sanitize_textarea_field($_POST['promesa'] ?? ''),
        'pilar'       => sanitize_text_field($_POST['pilar'] ?? ''),
        'fuente'      => sanitize_text_field($_POST['fuente'] ?? ''),
        'evidencia'   => sanitize_textarea_field($_POST['evidencia'] ?? ''),
        'fecha_prom'  => sanitize_text_field($_POST['fecha_prom'] ?? ''),
        'estado'      => 'Abierta',
    ];
    if (!$data['promesa'] || !$data['funcionario'] || !$data['fecha_prom']) {
        wp_send_json_error('Campos obligatorios vacios');
    }
    $wpdb->insert($table, $data);
    $id = $wpdb->insert_id;
    wp_send_json_success(['id' => $id, 'codigo' => 'P' . str_pad($id, 3, '0', STR_PAD_LEFT)]);
});

// ============================================================
// 8. AJAX — LISTAR PROMESAS
// ============================================================
add_action('wp_ajax_er_get_promesas', function() {
    check_ajax_referer('er_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos');
    global $wpdb;
    $table = $wpdb->prefix . 'er_promesas';
    $rows  = $wpdb->get_results("SELECT * FROM $table ORDER BY fecha DESC");
    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'id'      => (int)$r->id,
            'codigo'  => 'P' . str_pad($r->id, 3, '0', STR_PAD_LEFT),
            'promesa' => $r->promesa,
            'who'     => $r->funcionario,
            'date'    => $r->fecha_prom,
            'pilar'   => $r->pilar,
            'source'  => $r->fuente,
            'ev'      => $r->evidencia,
            'estado'  => $r->estado,
            'created' => date('d/m/Y', strtotime($r->fecha)),
        ];
    }
    wp_send_json_success($out);
});

// ============================================================
// 9. AJAX — ACTUALIZAR ESTADO
// ============================================================
add_action('wp_ajax_er_update_estado', function() {
    check_ajax_referer('er_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos');
    global $wpdb;
    $table   = $wpdb->prefix . 'er_promesas';
    $id      = (int)($_POST['id'] ?? 0);
    $estado  = sanitize_text_field($_POST['estado'] ?? '');
    $allowed = ['Abierta', 'En curso', 'Cumplida', 'Incumplida', 'Parcial'];
    if (!$id || !in_array($estado, $allowed)) wp_send_json_error('Datos invalidos');
    $wpdb->update($table, ['estado' => $estado], ['id' => $id]);
    wp_send_json_success();
});

// ============================================================
// 10. AJAX — ELIMINAR PROMESA
// ============================================================
add_action('wp_ajax_er_delete_promesa', function() {
    check_ajax_referer('er_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos');
    global $wpdb;
    $table = $wpdb->prefix . 'er_promesas';
    $id    = (int)($_POST['id'] ?? 0);
    if (!$id) wp_send_json_error('ID invalido');
    $wpdb->delete($table, ['id' => $id]);
    wp_send_json_success();
});

// ============================================================
// 11. AJAX — DIAGNOSTICO REAL DE WP
// ============================================================
add_action('wp_ajax_er_diagnostico', function() {
    check_ajax_referer('er_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos');
    global $wp_version;

    $active_plugins = get_option('active_plugins', []);
    $plugin_names   = [];
    foreach ($active_plugins as $p) {
        $pfile = WP_PLUGIN_DIR . '/' . $p;
        if (file_exists($pfile)) {
            $data = get_plugin_data($pfile, false, false);
            $plugin_names[] = ($data['Name'] ?? $p) . ' v' . ($data['Version'] ?? '?');
        }
    }

    $theme       = wp_get_theme();
    $parent      = $theme->parent();
    $update_pl   = get_site_transient('update_plugins');
    $pl_updates  = ($update_pl && !empty($update_pl->response)) ? count($update_pl->response) : 0;
    $update_core = get_site_transient('update_core');
    $wp_upd      = false;
    if ($update_core && !empty($update_core->updates)) {
        foreach ($update_core->updates as $u) {
            if ($u->response === 'upgrade') { $wp_upd = true; break; }
        }
    }

    wp_send_json_success([
        'wp_version'       => $wp_version,
        'php_version'      => phpversion(),
        'theme'            => $theme->get('Name') . ' v' . $theme->get('Version'),
        'parent_theme'     => $parent ? $parent->get('Name') : null,
        'ssl'              => is_ssl(),
        'plugins'          => $plugin_names,
        'plugins_update'   => $pl_updates,
        'wp_update'        => $wp_upd,
        'memory_limit'     => WP_MEMORY_LIMIT,
        'site_url'         => get_site_url(),
        'admin_email'      => get_option('admin_email'),
    ]);
});

// ============================================================
// 12. AJAX — SUBIR IMAGEN A MEDIA LIBRARY
// ============================================================
add_action('wp_ajax_er_upload_image', function() {
    check_ajax_referer('er_nonce', 'nonce');
    if (!current_user_can('upload_files')) wp_send_json_error('Sin permisos para subir archivos');
    if (empty($_FILES['file'])) wp_send_json_error('No se recibio ningun archivo');

    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $attachment_id = media_handle_upload('file', 0);
    if (is_wp_error($attachment_id)) {
        wp_send_json_error($attachment_id->get_error_message());
    }
    wp_send_json_success([
        'id'  => $attachment_id,
        'url' => wp_get_attachment_url($attachment_id),
    ]);
});

// ============================================================
// 13. AJAX — APLICAR SEO via AJAX (v7 nuevo)
// ============================================================
add_action('wp_ajax_er_apply_seo', function() {
    check_ajax_referer('er_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Sin permisos');

    $results = [];

    // Título del sitio y tagline
    update_option('blogname', 'El Rufino');
    update_option('blogdescription', 'Lo que pasa y lo que significa');
    $results[] = 'Título del sitio y tagline actualizados ✓';

    // Rank Math: si está activo, configurar opciones básicas
    if (defined('RANK_MATH_VERSION')) {
        update_option('rank_math_general_settings', array_merge(
            (array) get_option('rank_math_general_settings', []),
            [
                'breadcrumbs'       => 'on',
                'breadcrumbs_home'  => 'Inicio',
            ]
        ));
        $results[] = 'Rank Math: breadcrumbs activados ✓';

        // Schema Organization
        $titles = get_option('rank_math_titles', []);
        $titles['local_business_type'] = 'NewsMediaOrganization';
        $titles['knowledgegraph_name'] = 'El Rufino';
        $titles['knowledgegraph_type'] = 'company';
        update_option('rank_math_titles', $titles);
        $results[] = 'Rank Math: Schema NewsMediaOrganization configurado ✓';
    } else {
        $results[] = 'Rank Math no activo — instalar desde Módulo 04 ✗';
    }

    // Indexación de categorías
    update_option('category_base', '');
    $results[] = 'Slug de categorías limpio ✓';

    wp_send_json_success(['results' => $results]);
});
