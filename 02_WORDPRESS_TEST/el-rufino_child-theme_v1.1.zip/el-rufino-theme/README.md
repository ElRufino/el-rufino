# El Rufino — Child Theme v1.1.0

Tema hijo para WordPress. Requiere tema padre: Newsup.

## Instalación
1. Instalar tema padre Newsup desde Apariencia → Temas → Añadir nuevo
2. Subir este zip desde Apariencia → Temas → Añadir nuevo → Subir tema
3. Activar "El Rufino"

## Estructura
- style.css — paleta B: #c0271b rojo · #1a1a1a negro · #f5f0e8 crema
- functions.php — enqueue, image sizes, shortcodes, seguridad

## Shortcodes disponibles
- [er_wa_subscribe link="URL"] — bloque de suscripción WhatsApp
- [er_seguimiento estado="en proceso"] — badge de estado de promesa

## Dominio definitivo
elrufino.com.ar → elrufino.ar (futuro)
