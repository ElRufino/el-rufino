<?php
/*
Plugin Name: El Rufino - Panel v5
Description: Panel operativo completo con 14 módulos, 11 agentes, registro de promesas y contexto IA.
Version: 5.0.0
Author: El Rufino
*/

if (!defined('ABSPATH')) exit;

// 1. BASE DE DATOS — tabla promesas
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . 'er_promesas';
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        fecha datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        funcionario varchar(100) NOT NULL,
        promesa text NOT NULL,
        estado varchar(20) DEFAULT 'pendiente' NOT NULL,
        evidencia_url varchar(255) DEFAULT '',
        PRIMARY KEY (id)
    ) $charset;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    add_option('el_rufino_do_redirect', true);
});

// 2. REDIRECCIÓN AL ACTIVAR
add_action('admin_init', function() {
    if (get_option('el_rufino_do_redirect', false)) {
        delete_option('el_rufino_do_redirect');
        wp_redirect(admin_url('admin.php?page=el-rufino-panel'));
        exit;
    }
});

// 3. OCULTAR UI DE WORDPRESS — FULLSCREEN
add_action('admin_head', function() {
    if (isset($_GET['page']) && $_GET['page'] === 'el-rufino-panel') {
        echo '<style>
            #adminmenuback,#adminmenuwrap,#wpadminbar,#wpfooter,
            #adminmenu,.wp-responsive-overlay,.update-nag,.notice,
            #screen-meta-links,#screen-meta,.screen-meta-toggle { display:none!important; }
            html,body { overflow:hidden!important; margin:0!important; padding:0!important; }
            html.wp-toolbar { padding-top:0!important; }
            #wpcontent,#wpbody,#wpbody-content { margin:0!important; padding:0!important; float:none!important; }
            #wpwrap { display:block!important; }
            #el-rufino-fullscreen { position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:99999; overflow:hidden; }
        </style>';
    }
});

// 4. MENÚ
add_action('admin_menu', function() {
    add_menu_page('El Rufino', 'El Rufino v5', 'manage_options', 'el-rufino-panel', 'er_render_panel', 'dashicons-media-document', 2);
});

// 5. RENDER — incluye el HTML del panel
function er_render_panel() {
    echo '<div id="el-rufino-fullscreen">';
    include(plugin_dir_path(__FILE__) . 'panel.html');
    echo '</div>';
}
