<?php
/**
 * Plugin Name:       El Rufino — Panel IA
 * Plugin URI:        https://elrufino.com.ar
 * Description:       Panel operativo de El Rufino. 12 módulos, 12 agentes IA, Kanban editorial, Registro de promesas, Chat Claude integrado.
 * Version:           8.0.0
 * Author:            El Rufino
 * Text Domain:       el-rufino-panel
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ER_PANEL_VERSION', '8.0.0' );
define( 'ER_PANEL_DIR',     plugin_dir_path( __FILE__ ) );
define( 'ER_PANEL_URL',     plugin_dir_url( __FILE__ ) );

/* ---------------------------------------------------------------
   ACTIVACIÓN — crear tabla wp_er_promesas
--------------------------------------------------------------- */
register_activation_hook( __FILE__, 'er_panel_activate' );
function er_panel_activate() {
    global $wpdb;
    $table   = $wpdb->prefix . 'er_promesas';
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        codigo      VARCHAR(10)  NOT NULL,
        promesa     TEXT         NOT NULL,
        quien       VARCHAR(255) NOT NULL,
        fecha       DATE         NOT NULL,
        pilar       VARCHAR(10)  NOT NULL DEFAULT 'P05',
        fuente      VARCHAR(500) DEFAULT '',
        evidencia   TEXT         DEFAULT '',
        estado      VARCHAR(50)  NOT NULL DEFAULT 'Abierta',
        created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
    add_option( 'er_panel_version', ER_PANEL_VERSION );
}

/* ---------------------------------------------------------------
   MENÚ DE ADMINISTRACIÓN
--------------------------------------------------------------- */
add_action( 'admin_menu', 'er_panel_menu' );
function er_panel_menu() {
    add_menu_page(
        'El Rufino — Panel',
        'El Rufino',
        'manage_options',
        'el-rufino-panel',
        'er_panel_render_page',
        'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect width="20" height="20" rx="3" fill="#c0271b"/><text x="3" y="15" font-family="serif" font-size="11" font-weight="900" fill="#fff">ER</text></svg>'),
        3
    );
}

/* ---------------------------------------------------------------
   ENQUEUE: React + Babel + Google Fonts
--------------------------------------------------------------- */
add_action( 'admin_enqueue_scripts', 'er_panel_enqueue' );
function er_panel_enqueue( $hook ) {
    if ( $hook !== 'toplevel_page_el-rufino-panel' ) return;

    // Google Fonts
    wp_enqueue_style(
        'er-google-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Source+Serif+4:wght@400;600&display=swap',
        [], null
    );

    // React 18
    wp_enqueue_script( 'er-react',     'https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js',     [], '18.2.0', false );
    wp_enqueue_script( 'er-react-dom', 'https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js', ['er-react'], '18.2.0', false );
    wp_enqueue_script( 'er-babel',     'https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/7.23.5/babel.min.js',           [], '7.23.5',  false );

    // Inline: pasar nonce y ajax_url al JS
    wp_add_inline_script( 'er-react', '
        window.ER_AJAX = ' . json_encode([
            'url'   => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'er_panel_nonce' ),
        ]) . ';
    ' );

    wp_enqueue_style( 'er-panel-css', ER_PANEL_URL . 'assets/panel.css', [], ER_PANEL_VERSION );
}

/* ---------------------------------------------------------------
   PÁGINA HTML — monta el contenedor y carga el JSX via Babel
--------------------------------------------------------------- */
function er_panel_render_page() {
    ?>
    <div id="er-panel-root" style="margin:-8px -20px 0; height:calc(100vh - 32px);"></div>
    <script type="text/babel" data-presets="react" src="<?php echo esc_url( ER_PANEL_URL . 'assets/panel.jsx' ); ?>"></script>
    <script>
      // Babel termina async; esperamos al elemento raíz
      document.addEventListener('DOMContentLoaded', function() {});
    </script>
    <?php
}

/* ---------------------------------------------------------------
   AJAX — Guardar promesa
--------------------------------------------------------------- */
add_action( 'wp_ajax_er_save_promesa',   'er_ajax_save_promesa' );
function er_ajax_save_promesa() {
    check_ajax_referer( 'er_panel_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Sin permiso', 403 );

    global $wpdb;
    $table = $wpdb->prefix . 'er_promesas';

    $data = [
        'codigo'    => sanitize_text_field( $_POST['codigo']    ?? '' ),
        'promesa'   => sanitize_textarea_field( $_POST['promesa']   ?? '' ),
        'quien'     => sanitize_text_field( $_POST['quien']     ?? '' ),
        'fecha'     => sanitize_text_field( $_POST['fecha']     ?? '' ),
        'pilar'     => sanitize_text_field( $_POST['pilar']     ?? 'P05' ),
        'fuente'    => sanitize_text_field( $_POST['fuente']    ?? '' ),
        'evidencia' => sanitize_textarea_field( $_POST['evidencia'] ?? '' ),
        'estado'    => sanitize_text_field( $_POST['estado']    ?? 'Abierta' ),
    ];

    if ( empty( $data['promesa'] ) || empty( $data['quien'] ) || empty( $data['fecha'] ) ) {
        wp_send_json_error( 'Campos obligatorios vacíos' );
    }

    $id = intval( $_POST['id'] ?? 0 );
    if ( $id ) {
        $wpdb->update( $table, $data, ['id' => $id] );
        wp_send_json_success( ['id' => $id] );
    } else {
        $wpdb->insert( $table, $data );
        wp_send_json_success( ['id' => $wpdb->insert_id] );
    }
}

/* ---------------------------------------------------------------
   AJAX — Listar promesas
--------------------------------------------------------------- */
add_action( 'wp_ajax_er_get_promesas', 'er_ajax_get_promesas' );
function er_ajax_get_promesas() {
    check_ajax_referer( 'er_panel_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Sin permiso', 403 );

    global $wpdb;
    $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}er_promesas ORDER BY id DESC" );
    wp_send_json_success( $rows );
}

/* ---------------------------------------------------------------
   AJAX — Actualizar estado de promesa
--------------------------------------------------------------- */
add_action( 'wp_ajax_er_update_estado', 'er_ajax_update_estado' );
function er_ajax_update_estado() {
    check_ajax_referer( 'er_panel_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Sin permiso', 403 );

    global $wpdb;
    $id     = intval( $_POST['id'] );
    $estado = sanitize_text_field( $_POST['estado'] );
    $wpdb->update( $wpdb->prefix . 'er_promesas', ['estado' => $estado], ['id' => $id] );
    wp_send_json_success();
}

/* ---------------------------------------------------------------
   AJAX — Eliminar promesa
--------------------------------------------------------------- */
add_action( 'wp_ajax_er_delete_promesa', 'er_ajax_delete_promesa' );
function er_ajax_delete_promesa() {
    check_ajax_referer( 'er_panel_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Sin permiso', 403 );

    global $wpdb;
    $id = intval( $_POST['id'] );
    $wpdb->delete( $wpdb->prefix . 'er_promesas', ['id' => $id] );
    wp_send_json_success();
}
