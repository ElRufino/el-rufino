const { useState, useEffect, useRef, useCallback } = React;

// ============================================================
// CONSTANTES DEL PROYECTO v1.2
// ============================================================
const PALETA = { rojo: "#c0271b", negro: "#1a1a1a", crema: "#f5f0e8", blanco: "#ffffff", crema2: "#ece7dd", crema3: "#ddd8ce", verde: "#2e7d32", azul: "#1565c0", amber: "#e65100" };

const CIUDAD_DATA = {
  nombre: "Rufino, Santa Fe",
  habitantes: "19.211",
  claim: "Lo que pasa y lo que significa",
  dominio: "elrufino.com.ar",
  fb_activos: "~14.000",
  hogares: "~7.200"
};

const PILARES = [
  { code: "P01", name: "Lo que pasa", slug: "lo-que-pasa", fmt: "nota · hilo · infografía", color: "#c0271b" },
  { code: "P02", name: "El campo habla", slug: "el-campo-habla", fmt: "entrevista · dato · WhatsApp", color: "#1565c0" },
  { code: "P03", name: "Barrio a barrio", slug: "barrio-a-barrio", fmt: "seguimiento · mapa · vecinos", color: "#2e7d32" },
  { code: "P04", name: "Generación Rufino", slug: "generacion-rufino", fmt: "reels · perfil · TikTok", color: "#e65100" },
  { code: "P05", name: "Seguimiento de promesas", slug: "seguimiento-promesas", fmt: "fact-check · seguimiento · archivo", color: "#6a1b9a" },
  { code: "P06", name: "Contexto y datos", slug: "contexto-datos", fmt: "datos · placas · explicador", color: "#00838f" },
];

const AGENTES = [
  { id: 1, nombre: "Agente SEO", rol: "Rank Math · Schema · Keywords P01–P06", autonomia: "Alto", prompt: "Actuá como Agente SEO de El Rufino (Rufino, Santa Fe, 19.211 hab, claim: \"Lo que pasa y lo que significa\"). Generá la configuración completa de Rank Math: valores exactos campo por campo, Schema NewsMediaOrganization en JSON-LD, Open Graph, sitemap y keywords semilla para los 6 pilares P01-P06. URL objetivo: elrufino.com.ar." },
  { id: 2, nombre: "Agente Arquitectura", rol: "Categorías, slugs y entradas base", autonomia: "Medio", prompt: "Actuá como Agente Arquitectura de El Rufino. Generá la arquitectura editorial completa para WordPress: 6 categorías P01–P06 con slugs, 3 entradas base por categoría con la regla de las 2 capas, y 5 entradas evergreen." },
  { id: 3, nombre: "Agente Tema Visual", rol: "PHP/CSS del child theme", autonomia: "Bajo", prompt: "Actuá como Agente Tema Visual de El Rufino. Generá el código del child theme completo: style.css con paleta B (#c0271b rojo, #1a1a1a negro, #f5f0e8 crema), functions.php con enqueue de Playfair Display + Source Serif 4, CSS para header masthead rojo, ticker, grilla responsive mobile-first. Tema padre: Newsup." },
  { id: 4, nombre: "Agente Planificador", rol: "Calendario editorial semanal", autonomia: "Medio", prompt: "Actuá como Agente Planificador de El Rufino. Generá el calendario editorial para la próxima semana: día, pilar P01-P06, título con las 2 capas, formato, plataforma, audiencia target, fuentes sugeridas y tiempo de producción. Incluir resumen WA diario 7:30 AM." },
  { id: 5, nombre: "Agente Redactor", rol: "Notas periodísticas listas para publicar", autonomia: "Medio", prompt: "Actuá como Agente Redactor de El Rufino. Esperá que te dé el tema, datos disponibles y el pilar editorial. Redactarás la nota completa con regla de 2 capas: título (hecho + contexto), bajada, cuerpo 600-1000 palabras, cierre y tags sugeridos. Tono: directo sin agresivo, verificado, local sin localista." },
  { id: "6A", nombre: "Agente TikTok", rol: "Guiones 60 seg · hook nativo · tendencia", autonomia: "Alto", prompt: "Actuá como Agente TikTok de El Rufino. Convertís noticias locales en guiones TikTok de 45-60 seg. Hook nativo primeros 2 seg (texto en pantalla + audio), desarrollo con transiciones rápidas, CTA con sonido tendencia. Audiencia 14-24 años. Formato: [TEXTO PANTALLA] acción en corchetes. Esperá el tema." },
  { id: "6B", nombre: "Agente Reels", rol: "Guiones 30-60 seg · estética editorial · IG", autonomia: "Alto", prompt: "Actuá como Agente Reels de El Rufino. Convertís noticias locales en guiones Reels Instagram de 30-60 seg. Hook visual en primeros 3 seg, estética editorial (Playfair + crema), CTA a bio/link. Audiencia 22-40 años. Diferencia clave de TikTok: más contexto, menos virality-bait. Esperá el tema." },
  { id: 7, nombre: "Agente Accountability", rol: "Seguimiento de promesas — nota + hilo + WA", autonomia: "Medio", prompt: "Actuá como Agente de Accountability de El Rufino. Redactá: 1) nota principal 600-800 palabras con seguimiento de una promesa, 2) hilo de Facebook 5-7 posts, 3) resumen WhatsApp máx 3 líneas. Protocolo verificador, no opositor. Primero preguntame qué promesa cubrir." },
  { id: 8, nombre: "Agente Stack", rol: "WordPress y plugins · configuración técnica", autonomia: "Bajo", prompt: "Actuá como Agente Stack de El Rufino. Sos desarrollador WordPress especializado en medios digitales. Configurás el stack técnico completo: plugins, child theme Newsup, Customizer, menús y opciones. Generás código PHP/CSS funcional. ¿Por dónde empezamos?" },
  { id: 9, nombre: "Agente Servidor", rol: "Infraestructura · hosting Hostinger · velocidad", autonomia: "Bajo", prompt: "Actuá como Agente Servidor de El Rufino. Diagnosticá el entorno elrufino.com.ar en Hostinger: velocidad de carga, PHP version, plugins de caché, configuración SSL y plan de migración. Objetivo: carga menor a 3 segundos en mobile." },
  { id: 10, nombre: "Agente Datos", rol: "Pilar P06 · INDEC · SAMCO · presupuesto", autonomia: "Medio", prompt: "Actuá como Agente Agenda de Datos de El Rufino. Generá la agenda completa: fuentes verificables (INDEC, municipio, SAMCO, INTA, provincia), métricas clave por área y estructura de tabla para el Pilar P06 — Contexto y datos." },
  { id: 11, nombre: "Agente Imágenes", rol: "Prompts para generación visual · Gemini · MJ", autonomia: "Medio", prompt: "Actuá como Agente Imágenes de El Rufino. Generás prompts precisos para IAs de generación de imágenes. Pedís especificaciones y devolvés el prompt optimizado en español e inglés con especificaciones técnicas exactas." },
  { id: 12, nombre: "Agente Crisis", rol: "Tragedia · Fake news · Desmentida", autonomia: "Medio", prompt: "Actuá como Agente de Crisis de El Rufino. Protocolo activo: PROTOCOLO_TRAGEDIA (no imágenes explícitas · esperar 2 fuentes · enfoque servicio no morbo). Para fake news viral: identificá el original, rastreá la deformación, redactá la desmentida verificada. Primero decime qué situación enfrentamos." },
];

const KANBAN_COLS = ["Idea", "En producción", "Edición", "Publicado"];

const WA_TEMPLATES = [
  { nombre: "Resumen matutino 7:30", texto: "☀️ *EL RUFINO* — {FECHA}\n\n{NOTICIA_1}\n{NOTICIA_2}\n{NOTICIA_3}\n\n📍 elrufino.com.ar" },
  { nombre: "Alerta urgente", texto: "🔴 *ALERTA EL RUFINO*\n\n{HECHO}\n\n📍 Seguimos informando → elrufino.com.ar" },
  { nombre: "Seguimiento promesa", texto: "📋 *SEGUIMIENTO* | P05\n\nPromesa: {PROMESA}\nEstado: {ESTADO}\n\n📍 elrufino.com.ar/promesas" },
];

const METRICAS_BASE = [
  { key: "fb_likes", label: "Facebook Likes", meta: "5.000 al mes 6", icon: "f" },
  { key: "ig_seg", label: "Instagram Seguidores", meta: "2.000 al mes 6", icon: "ig" },
  { key: "wa_subs", label: "WhatsApp Suscriptores", meta: "500 al mes 3", icon: "wa" },
  { key: "visitas_dia", label: "Visitas/día", meta: "baseline Mes 0", icon: "🌐" },
  { key: "notas_pub", label: "Notas publicadas", meta: "20 para cerrar F2", icon: "📝" },
];

// ============================================================
// LLAMADA A LA API DE ANTHROPIC
// ============================================================
async function callClaude(messages, system = "") {
  const body = {
    model: "claude-sonnet-4-20250514",
    max_tokens: 1000,
    messages,
  };
  if (system) body.system = system;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  return data.content?.map(b => b.text || "").join("") || "Sin respuesta";
}

// ============================================================
// ESTILOS BASE
// ============================================================
const S = {
  shell: {
    display: "flex", height: "100vh", background: PALETA.crema,
    fontFamily: "'Source Serif 4', Georgia, serif", overflow: "hidden", minHeight: 0,
  },
  sidebar: {
    width: 216, flexShrink: 0, background: PALETA.blanco,
    display: "flex", flexDirection: "column",
    borderRight: `2px solid ${PALETA.crema3}`, overflow: "hidden",
  },
  sbHead: { padding: "16px 14px 14px", borderBottom: `1px solid ${PALETA.crema3}` },
  logoMark: {
    background: PALETA.rojo, color: "#fff",
    fontFamily: "'Playfair Display', Georgia, serif", fontWeight: 900,
    fontSize: 15, padding: "5px 10px", borderRadius: 3, display: "inline-block", letterSpacing: .5,
  },
  verTag: { fontSize: 9, color: "#aaa", marginTop: 5, fontFamily: "monospace", display: "flex", alignItems: "center", gap: 5 },
  sbNav: { flex: 1, overflowY: "auto", padding: "8px 0" },
  ns: { fontSize: 9, letterSpacing: "2.5px", textTransform: "uppercase", color: "#bbb", padding: "10px 14px 4px", fontWeight: 700, fontFamily: "monospace" },
  main: { flex: 1, display: "flex", flexDirection: "column", minWidth: 0, overflow: "hidden" },
  topbar: {
    background: "#161616", color: PALETA.crema, padding: "10px 24px",
    display: "flex", alignItems: "center", gap: 12, borderBottom: "1px solid #1e1e1e", flexShrink: 0,
  },
  content: { flex: 1, overflowY: "auto", padding: "26px 30px" },
  navFt: {
    padding: "12px 24px", background: PALETA.crema2,
    display: "flex", alignItems: "center", justifyContent: "space-between",
    borderTop: `1px solid ${PALETA.crema3}`, flexShrink: 0,
  },
  card: {
    background: PALETA.blanco, borderRadius: 6,
    border: `1px solid ${PALETA.crema3}`, padding: 14,
    boxShadow: "0 1px 4px rgba(0,0,0,.08)",
  },
  btn: (variant = "p") => {
    const variants = {
      p: { background: PALETA.rojo, color: "#fff", border: "none" },
      o: { background: "transparent", color: PALETA.rojo, border: `1px solid ${PALETA.rojo}` },
      g: { background: "transparent", color: "#888", border: `1px solid ${PALETA.crema3}` },
      b: { background: PALETA.azul, color: "#fff", border: "none" },
    };
    return {
      fontSize: 11, padding: "7px 14px", borderRadius: 4, cursor: "pointer",
      fontFamily: "'Source Serif 4', Georgia, serif", fontWeight: 600,
      display: "inline-flex", alignItems: "center", gap: 5,
      transition: "all .13s", ...variants[variant],
    };
  },
  badge: (color = "g") => {
    const colors = {
      g: { bg: "#e8f5e9", text: PALETA.verde },
      y: { bg: "#fff3e0", text: PALETA.amber },
      r: { bg: "#ffebee", text: "#c62828" },
      b: { bg: "#e3f2fd", text: PALETA.azul },
      gr: { bg: "#f5f5f5", text: "#555" },
    };
    const c = colors[color] || colors.gr;
    return {
      display: "inline-flex", alignItems: "center", fontSize: 8,
      padding: "2px 7px", borderRadius: 10, fontWeight: 700,
      letterSpacing: ".8px", textTransform: "uppercase", fontFamily: "monospace",
      background: c.bg, color: c.text,
    };
  },
};

// ============================================================
// COMPONENTES AUXILIARES
// ============================================================
function NavItem({ label, active, onClick, badge }) {
  return (
    <div onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 8,
      padding: "7px 14px", cursor: "pointer",
      borderLeft: active ? `2px solid ${PALETA.rojo}` : "2px solid transparent",
      background: active ? "#fff0ef" : "transparent",
      color: active ? PALETA.rojo : PALETA.negro,
      fontSize: 11, fontWeight: active ? 600 : 400,
      transition: "all .12s",
    }}>
      <span style={{ width: 4, height: 4, borderRadius: "50%", background: active ? PALETA.rojo : "#ddd", flexShrink: 0 }} />
      {label}
      {badge && <span style={{ marginLeft: "auto", fontSize: 9, padding: "1px 6px", borderRadius: 8, fontWeight: 700, fontFamily: "monospace", background: "#fff0ef", color: PALETA.rojo }}>{badge}</span>}
    </div>
  );
}

function SLabel({ children, style }) {
  return <div style={{ fontSize: 9, letterSpacing: "2.5px", textTransform: "uppercase", color: PALETA.rojo, fontWeight: 700, marginBottom: 12, fontFamily: "monospace", ...style }}>{children}</div>;
}

function Divider() {
  return <div style={{ height: 1, background: PALETA.crema3, margin: "20px 0" }} />;
}

function Warn({ title, children }) {
  return (
    <div style={{ background: "#fffbf0", border: "1px solid #ffe082", borderRadius: 5, padding: "12px 14px", marginTop: 10 }}>
      <div style={{ fontSize: 9, fontWeight: 700, color: PALETA.amber, letterSpacing: "1.5px", textTransform: "uppercase", marginBottom: 4, fontFamily: "monospace" }}>{title}</div>
      <p style={{ fontSize: 11, color: "#5d4037", lineHeight: 1.65 }}>{children}</p>
    </div>
  );
}

function Info({ title, children }) {
  return (
    <div style={{ background: "#f4f8ff", border: "1px solid #c5d9f0", borderRadius: 5, padding: "12px 14px", marginTop: 10 }}>
      <div style={{ fontSize: 9, fontWeight: 700, color: PALETA.azul, letterSpacing: "1.5px", textTransform: "uppercase", marginBottom: 4, fontFamily: "monospace" }}>{title}</div>
      <p style={{ fontSize: 11, color: PALETA.azul, lineHeight: 1.65 }}>{children}</p>
    </div>
  );
}

function Toast({ msg }) {
  if (!msg) return null;
  return (
    <div style={{
      position: "fixed", bottom: 20, left: "50%", transform: "translateX(-50%)",
      background: PALETA.negro, color: PALETA.crema, fontSize: 11, padding: "8px 18px",
      borderRadius: 20, zIndex: 9999, border: `1px solid ${PALETA.rojo}`,
      boxShadow: "0 4px 16px rgba(0,0,0,.3)", whiteSpace: "nowrap", pointerEvents: "none",
    }}>
      {msg}
    </div>
  );
}

function AILoader({ loading, label = "Generando..." }) {
  if (!loading) return null;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", background: "#fff", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, marginTop: 10 }}>
      <div style={{ display: "flex", gap: 4 }}>
        {[0, 1, 2].map(i => (
          <span key={i} style={{
            width: 6, height: 6, borderRadius: "50%", background: PALETA.rojo,
            animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
          }} />
        ))}
      </div>
      <span style={{ fontSize: 11, color: "#888", fontFamily: "monospace" }}>{label}</span>
      <style>{`@keyframes pulse { 0%,80%,100%{opacity:.3;transform:scale(.8)} 40%{opacity:1;transform:scale(1)} }`}</style>
    </div>
  );
}

// ============================================================
// MÓDULO 0: INICIO
// ============================================================
function ModInicio({ promesas, metrics, onSetMetric }) {
  const fase2Items = [
    { label: "6 categorías P01-P06", done: false },
    { label: "Logo/favicon/OG subidos", done: true },
    { label: "Schema NewsMediaOrganization", done: false },
    { label: "20 notas publicadas", done: false },
    { label: "500 WA suscriptores", done: false },
  ];
  const f2pct = Math.round(fase2Items.filter(i => i.done).length / fase2Items.length * 100);

  return (
    <div>
      <div style={{ background: PALETA.negro, borderRadius: 8, padding: 24, marginBottom: 20, display: "flex", gap: 20, alignItems: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", right: -20, top: -20, width: 130, height: 130, border: "2px solid #c0271b18", borderRadius: "50%" }} />
        <div style={{ width: 60, height: 60, flexShrink: 0, background: PALETA.rojo, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Playfair Display', serif", fontWeight: 900, fontSize: 20, color: "#fff", zIndex: 1 }}>ER</div>
        <div style={{ zIndex: 1 }}>
          <h2 style={{ fontFamily: "'Playfair Display', serif", color: PALETA.crema, fontSize: 22, marginBottom: 7, lineHeight: 1.15 }}>Panel El Rufino v8.0.0</h2>
          <p style={{ color: "#aaa", fontSize: 11, lineHeight: 1.7 }}>Sistema operativo del medio. 17 módulos · 12 agentes · Registro de promesas · Chat IA integrado · Kanban editorial.</p>
          <div style={{ display: "flex", gap: 5, marginTop: 10, flexWrap: "wrap" }}>
            <span style={S.badge("r")}>FASE 2 EN EJECUCIÓN</span>
            <span style={S.badge("b")}>Plugin v8.0.0</span>
            <span style={S.badge("g")}>Claude IA integrado</span>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 18 }}>
        {[
          { n: 12, l: "Agentes IA" },
          { n: promesas.length, l: "Promesas" },
          { n: `${f2pct}%`, l: "Fase 2" },
          { n: 17, l: "Módulos" },
        ].map(({ n, l }) => (
          <div key={l} style={{ ...S.card, textAlign: "center" }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: PALETA.rojo, fontWeight: 900 }}>{n}</div>
            <div style={{ fontSize: 9, color: "#888", marginTop: 2, textTransform: "uppercase", letterSpacing: 1, fontFamily: "monospace" }}>{l}</div>
          </div>
        ))}
      </div>

      <SLabel>Checklist Fase 2 — {f2pct}% completado</SLabel>
      {fase2Items.map((item, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderBottom: `1px solid ${PALETA.crema3}`, fontSize: 11 }}>
          <div style={{ width: 18, height: 18, borderRadius: 3, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, flexShrink: 0, background: item.done ? "#e8f5e9" : "#ffebee", color: item.done ? PALETA.verde : "#c62828" }}>
            {item.done ? "✓" : "✗"}
          </div>
          <span>{item.label}</span>
          <span style={S.badge(item.done ? "g" : "r")}>{item.done ? "OK" : "Pendiente"}</span>
        </div>
      ))}

      <Divider />
      <SLabel>Métricas Base Mes 0</SLabel>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {METRICAS_BASE.map(m => (
          <div key={m.key} style={S.card}>
            <div style={{ fontSize: 9, color: "#aaa", fontFamily: "monospace", marginBottom: 4 }}>{m.label}</div>
            <input
              type="text"
              placeholder="Ingresar valor actual..."
              value={metrics[m.key] || ""}
              onChange={e => onSetMetric(m.key, e.target.value)}
              style={{ width: "100%", padding: "6px 8px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, fontFamily: "monospace", background: "#fafaf8", outline: "none" }}
            />
            <div style={{ fontSize: 9, color: PALETA.rojo, marginTop: 4, fontFamily: "monospace" }}>Meta: {m.meta}</div>
          </div>
        ))}
      </div>

      <Divider />
      <SLabel>Deuda técnica crítica</SLabel>
      <Warn title="⚠ Acciones bloqueantes">
        Schema NewsMediaOrganization pendiente · Categorías P01-P06 sin crear · Canal WA sin configurar · Estas 3 tareas bloquean el cierre de Fase 2.
      </Warn>
    </div>
  );
}

// ============================================================
// MÓDULO CHAT IA
// ============================================================
function ModChatIA({ showToast }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState(
    `Sos el asistente editorial de El Rufino, medio digital local de Rufino, Santa Fe, Argentina (19.211 hab). Claim: "Lo que pasa y lo que significa". Pilares: P01 Lo que pasa · P02 El campo habla · P03 Barrio a barrio · P04 Generación Rufino · P05 Seguimiento de promesas · P06 Contexto y datos. Regla madre obligatoria: toda pieza tiene 2 capas (hecho verificado + contexto/significado). Voz: directa sin agresiva, verificada, local sin localista, humana sin amarillista. No reabras decisiones de identidad cerradas.`
  );
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: "user", content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);
    try {
      const history = [...messages, userMsg];
      const reply = await callClaude(history, systemPrompt);
      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
    } catch {
      showToast("Error de conexión con Claude");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO NUEVO / 17 · CHAT IA</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Chat con Claude</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Chat directo con Claude integrado. Historial de conversación en esta sesión.</div>

      <div style={{ marginBottom: 12 }}>
        <SLabel>Contexto del sistema (editable)</SLabel>
        <textarea
          value={systemPrompt}
          onChange={e => setSystemPrompt(e.target.value)}
          style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 10, fontFamily: "monospace", background: "#f8f7f4", outline: "none", resize: "vertical", minHeight: 60, color: "#2d5a27" }}
        />
      </div>

      <div style={{ flex: 1, overflowY: "auto", background: "#fff", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, padding: 14, marginBottom: 10, minHeight: 200, maxHeight: 340 }}>
        {messages.length === 0 && (
          <div style={{ textAlign: "center", color: "#bbb", fontSize: 12, fontFamily: "monospace", paddingTop: 40 }}>
            Empezá la conversación ↓
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 12, display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{
              maxWidth: "80%", padding: "10px 14px", borderRadius: 8, fontSize: 11, lineHeight: 1.7,
              background: m.role === "user" ? PALETA.rojo : "#f5f0e8",
              color: m.role === "user" ? "#fff" : PALETA.negro,
              borderBottomRightRadius: m.role === "user" ? 2 : 8,
              borderBottomLeftRadius: m.role === "assistant" ? 2 : 8,
              whiteSpace: "pre-wrap",
            }}>
              {m.content}
            </div>
          </div>
        ))}
        <AILoader loading={loading} label="Claude está respondiendo..." />
        <div ref={endRef} />
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <textarea
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder="Escribí tu consulta... (Enter para enviar, Shift+Enter para nueva línea)"
          style={{ flex: 1, padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, fontFamily: "'Source Serif 4', serif", resize: "none", minHeight: 44, outline: "none" }}
        />
        <button onClick={send} disabled={loading} style={{ ...S.btn("p"), alignSelf: "flex-end", opacity: loading ? .5 : 1 }}>
          Enviar →
        </button>
      </div>

      {messages.length > 0 && (
        <button onClick={() => setMessages([])} style={{ ...S.btn("g"), marginTop: 8, fontSize: 10 }}>
          Limpiar chat
        </button>
      )}
    </div>
  );
}

// ============================================================
// MÓDULO REDACTOR IA
// ============================================================
function ModRedactorIA({ showToast }) {
  const [tema, setTema] = useState("");
  const [pilar, setPilar] = useState("P01");
  const [datos, setDatos] = useState("");
  const [resultado, setResultado] = useState("");
  const [loading, setLoading] = useState(false);

  const generar = async () => {
    if (!tema.trim()) { showToast("Ingresá el tema de la nota"); return; }
    setLoading(true);
    setResultado("");
    try {
      const prompt = `Actuá como Agente Redactor de El Rufino (Rufino, Santa Fe, 19.211 hab). Regla de 2 capas OBLIGATORIA: Capa 1 = hecho verificado · Capa 2 = qué significa/contexto/pregunta que queda abierta. Voz: directa sin agresiva, verificada, local sin localista.

Tema: ${tema}
Pilar: ${pilar}
Datos disponibles: ${datos || "Sin datos adicionales"}

Redactá la nota completa:
- Título con las 2 capas (hecho + contexto)
- Bajada (2-3 líneas)
- Cuerpo completo 600-800 palabras con regla de 2 capas
- Tags sugeridos
- Versión WhatsApp (máx 3 líneas)`;

      const reply = await callClaude([{ role: "user", content: prompt }]);
      setResultado(reply);
    } catch {
      showToast("Error de conexión con Claude");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO NUEVO / 17 · PRODUCCIÓN</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Redactor IA</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Genera notas con regla de 2 capas obligatoria. Claude como Agente Redactor.</div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
        <div>
          <label style={{ fontSize: 10, fontWeight: 700, color: PALETA.negro, marginBottom: 4, display: "block", fontFamily: "monospace" }}>Tema / Hecho *</label>
          <input value={tema} onChange={e => setTema(e.target.value)} placeholder="Ej: El municipio anunció obras en calle Belgrano" style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, fontFamily: "'Source Serif 4', serif", background: "#fafaf8", outline: "none" }} />
        </div>
        <div>
          <label style={{ fontSize: 10, fontWeight: 700, color: PALETA.negro, marginBottom: 4, display: "block", fontFamily: "monospace" }}>Pilar editorial</label>
          <select value={pilar} onChange={e => setPilar(e.target.value)} style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, fontFamily: "'Source Serif 4', serif", background: "#fafaf8", outline: "none" }}>
            {PILARES.map(p => <option key={p.code} value={p.code}>{p.code} — {p.name}</option>)}
          </select>
        </div>
      </div>
      <div style={{ marginBottom: 12 }}>
        <label style={{ fontSize: 10, fontWeight: 700, color: PALETA.negro, marginBottom: 4, display: "block", fontFamily: "monospace" }}>Datos disponibles (fuentes, citas, contexto)</label>
        <textarea value={datos} onChange={e => setDatos(e.target.value)} placeholder="Pegá los datos, citas, declaraciones que tenés..." style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, fontFamily: "'Source Serif 4', serif", background: "#fafaf8", outline: "none", resize: "vertical", minHeight: 80 }} />
      </div>

      <button onClick={generar} disabled={loading} style={{ ...S.btn("p"), opacity: loading ? .6 : 1 }}>
        {loading ? "Generando..." : "Generar nota con IA →"}
      </button>

      <AILoader loading={loading} label="Claude redactando con regla de 2 capas..." />

      {resultado && (
        <div style={{ marginTop: 16 }}>
          <SLabel>Nota generada</SLabel>
          <div style={{ background: "#fff", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, padding: 16, fontSize: 12, lineHeight: 1.8, whiteSpace: "pre-wrap", maxHeight: 400, overflowY: "auto" }}>
            {resultado}
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
            <button onClick={() => { navigator.clipboard.writeText(resultado); showToast("Nota copiada ✓"); }} style={S.btn("o")}>Copiar nota</button>
            <button onClick={() => setResultado("")} style={S.btn("g")}>Limpiar</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// MÓDULO KANBAN EDITORIAL
// ============================================================
function ModKanban({ showToast }) {
  const [cards, setCards] = useState([
    { id: 1, titulo: "Obras en acceso sur — estado real", pilar: "P01", formato: "nota", col: "Idea" },
    { id: 2, titulo: "Precio soja en Rufino vs ROFEX", pilar: "P02", formato: "dato", col: "En producción" },
    { id: 3, titulo: "Barrio Norte: promesa de asfalto 2024", pilar: "P05", formato: "seguimiento", col: "Edición" },
  ]);
  const [newCard, setNewCard] = useState({ titulo: "", pilar: "P01", formato: "nota" });
  const [dragging, setDragging] = useState(null);

  const addCard = () => {
    if (!newCard.titulo.trim()) { showToast("Ingresá el título"); return; }
    setCards(prev => [...prev, { id: Date.now(), ...newCard, col: "Idea" }]);
    setNewCard({ titulo: "", pilar: "P01", formato: "nota" });
    showToast("Nota agregada al Kanban ✓");
  };

  const moveCard = (id, newCol) => {
    setCards(prev => prev.map(c => c.id === id ? { ...c, col: newCol } : c));
  };

  const deleteCard = (id) => setCards(prev => prev.filter(c => c.id !== id));

  const colColors = { "Idea": "#f5f0e8", "En producción": "#fff3e0", "Edición": "#e3f2fd", "Publicado": "#e8f5e9" };
  const pilColors = PILARES.reduce((acc, p) => { acc[p.code] = p.color; return acc; }, {});

  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO NUEVO / 17 · PRODUCCIÓN</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Kanban Editorial</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Planificación visual por pilar. Arrastrá entre columnas.</div>

      <div style={{ ...S.card, marginBottom: 16, display: "grid", gridTemplateColumns: "1fr auto auto auto", gap: 8, alignItems: "end" }}>
        <div>
          <label style={{ fontSize: 9, fontFamily: "monospace", color: "#aaa", display: "block", marginBottom: 4 }}>TÍTULO / IDEA</label>
          <input value={newCard.titulo} onChange={e => setNewCard(p => ({ ...p, titulo: e.target.value }))} placeholder="Ej: El campo y la retención..." style={{ width: "100%", padding: "7px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11 }} />
        </div>
        <div>
          <label style={{ fontSize: 9, fontFamily: "monospace", color: "#aaa", display: "block", marginBottom: 4 }}>PILAR</label>
          <select value={newCard.pilar} onChange={e => setNewCard(p => ({ ...p, pilar: e.target.value }))} style={{ padding: "7px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, background: "#fafaf8" }}>
            {PILARES.map(p => <option key={p.code} value={p.code}>{p.code}</option>)}
          </select>
        </div>
        <div>
          <label style={{ fontSize: 9, fontFamily: "monospace", color: "#aaa", display: "block", marginBottom: 4 }}>FORMATO</label>
          <select value={newCard.formato} onChange={e => setNewCard(p => ({ ...p, formato: e.target.value }))} style={{ padding: "7px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, background: "#fafaf8" }}>
            {["nota", "hilo", "dato", "video", "seguimiento", "infografía"].map(f => <option key={f}>{f}</option>)}
          </select>
        </div>
        <button onClick={addCard} style={S.btn("p")}>+ Agregar</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
        {KANBAN_COLS.map(col => (
          <div key={col}
            onDragOver={e => e.preventDefault()}
            onDrop={e => { e.preventDefault(); if (dragging) moveCard(dragging, col); setDragging(null); }}
            style={{ background: colColors[col], borderRadius: 6, padding: 10, minHeight: 200, border: `1px solid ${PALETA.crema3}` }}
          >
            <div style={{ fontSize: 9, fontWeight: 700, color: "#888", textTransform: "uppercase", letterSpacing: "1.5px", fontFamily: "monospace", marginBottom: 10, paddingBottom: 8, borderBottom: `1px solid ${PALETA.crema3}` }}>
              {col} <span style={{ fontWeight: 400 }}>({cards.filter(c => c.col === col).length})</span>
            </div>
            {cards.filter(c => c.col === col).map(card => (
              <div key={card.id} draggable onDragStart={() => setDragging(card.id)}
                style={{ background: "#fff", border: `1px solid ${PALETA.crema3}`, borderLeft: `3px solid ${pilColors[card.pilar] || PALETA.rojo}`, borderRadius: 5, padding: "9px 10px", marginBottom: 7, cursor: "grab", boxShadow: "0 1px 3px rgba(0,0,0,.07)" }}>
                <div style={{ fontSize: 11, color: PALETA.negro, lineHeight: 1.4, marginBottom: 6 }}>{card.titulo}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                  <span style={{ fontSize: 8, padding: "1px 5px", borderRadius: 8, background: `${pilColors[card.pilar]}18`, color: pilColors[card.pilar], fontWeight: 700, fontFamily: "monospace" }}>{card.pilar}</span>
                  <span style={{ fontSize: 9, color: "#aaa", fontFamily: "monospace" }}>{card.formato}</span>
                  <button onClick={() => deleteCard(card.id)} style={{ marginLeft: "auto", background: "none", border: "none", color: "#ccc", cursor: "pointer", fontSize: 13, lineHeight: 1 }}>×</button>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// MÓDULO WHATSAPP COMPOSITOR
// ============================================================
function ModWhatsApp({ showToast }) {
  const [template, setTemplate] = useState(0);
  const [texto, setTexto] = useState(WA_TEMPLATES[0].texto);
  const [loading, setLoading] = useState(false);

  const genWithAI = async () => {
    setLoading(true);
    try {
      const reply = await callClaude([{
        role: "user",
        content: "Actuá como redactor de El Rufino (Rufino, Santa Fe). Generá el resumen matutino para WhatsApp de hoy: 3-4 noticias relevantes de una ciudad pampeana de 19k habitantes, 2 líneas por noticia, tono directo humano, sin markdown, listo para canal broadcast. Inventá noticias verosímiles para el ejemplo."
      }]);
      setTexto(reply);
    } catch { showToast("Error al conectar con Claude"); }
    finally { setLoading(false); }
  };

  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO NUEVO / 17 · PRODUCCIÓN</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Compositor WhatsApp</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Generá mensajes para el canal broadcast. 7:30 AM todos los días. KPI: {">"}60% apertura.</div>

      <SLabel>Plantillas</SLabel>
      <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>
        {WA_TEMPLATES.map((t, i) => (
          <button key={i} onClick={() => { setTemplate(i); setTexto(t.texto); }} style={{ ...S.btn(i === template ? "p" : "g"), fontSize: 10 }}>
            {t.nombre}
          </button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div>
          <SLabel>Editor</SLabel>
          <textarea value={texto} onChange={e => setTexto(e.target.value)} style={{ width: "100%", padding: "10px 12px", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, fontSize: 12, fontFamily: "monospace", background: "#f8f7f4", outline: "none", resize: "vertical", minHeight: 180, lineHeight: 1.7 }} />
          <div style={{ display: "flex", gap: 7, marginTop: 10 }}>
            <button onClick={genWithAI} disabled={loading} style={{ ...S.btn("p"), opacity: loading ? .6 : 1 }}>IA → generar resumen</button>
            <button onClick={() => { navigator.clipboard.writeText(texto); showToast("Mensaje copiado ✓"); }} style={S.btn("o")}>Copiar</button>
          </div>
          <AILoader loading={loading} label="Generando resumen matutino..." />
        </div>

        <div>
          <SLabel>Preview WhatsApp</SLabel>
          <div style={{ background: "#e5ddd5", borderRadius: 8, padding: 14, minHeight: 180 }}>
            <div style={{ background: "#25d366", color: "#fff", borderRadius: "8px 8px 0 0", padding: "8px 14px", fontSize: 11, fontWeight: 700, display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: PALETA.rojo, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 900, color: "#fff" }}>ER</div>
              EL RUFINO
            </div>
            <div style={{ background: "#fff", borderRadius: "0 0 8px 8px", padding: "12px 14px", fontSize: 11, lineHeight: 1.7, whiteSpace: "pre-wrap", minHeight: 120 }}>
              {texto || <span style={{ color: "#ccc" }}>Vista previa del mensaje...</span>}
            </div>
          </div>
          <div style={{ fontSize: 9, color: "#aaa", fontFamily: "monospace", marginTop: 8 }}>
            {texto.length} caracteres · KPI objetivo: {">"}60% apertura
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// MÓDULO AGENTES IA (v8: 12 agentes, 6A/6B separados)
// ============================================================
function ModAgentes({ showToast }) {
  const [activeAgent, setActiveAgent] = useState(null);
  const [agentOutput, setAgentOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [extraInput, setExtraInput] = useState("");

  const activar = async (agente) => {
    setActiveAgent(agente);
    setAgentOutput("");
    setLoading(true);
    try {
      const fullPrompt = extraInput ? `${agente.prompt}\n\nDatos adicionales: ${extraInput}` : agente.prompt;
      const reply = await callClaude([{ role: "user", content: fullPrompt }]);
      setAgentOutput(reply);
    } catch { showToast("Error al conectar con Claude"); }
    finally { setLoading(false); }
  };

  const categorias = [
    { label: "Agentes editoriales (1–7)", ids: [1, 2, 4, 5, "6A", "6B", 7] },
    { label: "Agentes técnicos (8–9)", ids: [8, 9] },
    { label: "Agentes de contenido (10–12)", ids: [10, 11, 12] },
  ];

  const autonomiaColor = { "Alto": PALETA.verde, "Medio": PALETA.amber, "Bajo": PALETA.azul };

  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO 11 / 17 · INTELIGENCIA</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>usInA — 12 Agentes</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>
        12 agentes especializados con Claude integrado. Agente 6 separado en 6A (TikTok) y 6B (Reels). Agente 12 de Crisis incorporado.
      </div>

      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 9, fontFamily: "monospace", color: "#aaa", display: "block", marginBottom: 4 }}>CONTEXTO ADICIONAL (opcional — se agrega al prompt del agente)</label>
        <textarea value={extraInput} onChange={e => setExtraInput(e.target.value)} placeholder="Pegá datos, nombres, fechas u otra información relevante para el agente..." style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, fontFamily: "'Source Serif 4', serif", background: "#fafaf8", outline: "none", resize: "vertical", minHeight: 50 }} />
      </div>

      {categorias.map(cat => (
        <div key={cat.label}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "18px 0 10px" }}>
            <div style={{ flex: 1, height: 1, background: PALETA.crema3 }} />
            <span style={{ fontSize: 9, color: "#bbb", fontFamily: "monospace", letterSpacing: 1, textTransform: "uppercase" }}>{cat.label}</span>
            <div style={{ flex: 1, height: 1, background: PALETA.crema3 }} />
          </div>
          {AGENTES.filter(a => cat.ids.includes(a.id)).map(agente => (
            <div key={agente.id} style={{ ...S.card, marginBottom: 8, borderLeft: agente.id === 12 ? `3px solid ${PALETA.rojo}` : agente.id >= 8 && agente.id <= 9 ? `3px solid ${PALETA.azul}` : `3px solid ${PALETA.crema3}` }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 10, marginBottom: 6 }}>
                <div style={{ background: agente.id === 12 ? PALETA.rojo : agente.id >= 8 && agente.id <= 9 ? PALETA.azul : PALETA.negro, color: "#fff", fontSize: 9, fontWeight: 800, width: 22, height: 22, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontFamily: "monospace" }}>
                  {agente.id}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 13, color: PALETA.negro, fontWeight: 700 }}>{agente.nombre}</div>
                  <div style={{ fontSize: 10, color: PALETA.rojo, marginTop: 2 }}>{agente.rol}</div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ fontSize: 8, padding: "1px 6px", borderRadius: 8, background: `${autonomiaColor[agente.autonomia]}18`, color: autonomiaColor[agente.autonomia], fontWeight: 700, fontFamily: "monospace" }}>{agente.autonomia}</span>
                  <button onClick={() => activar(agente)} disabled={loading} style={{ ...S.btn("o"), fontSize: 10, padding: "4px 10px", opacity: loading ? .5 : 1 }}>
                    Activar ↗
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ))}

      <Warn title="⏸ Agentes Fase 3 (no activar aún)">
        Agente SEO por nota y Agente Monetización — activar recién cuando haya hábito de audiencia.
      </Warn>

      {(loading || agentOutput) && (
        <div style={{ marginTop: 16 }}>
          {activeAgent && <SLabel>Agente {activeAgent.id} — {activeAgent.nombre}</SLabel>}
          <AILoader loading={loading} label={`Agente ${activeAgent?.id} trabajando...`} />
          {agentOutput && (
            <>
              <div style={{ background: "#fff", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, padding: 14, fontSize: 12, lineHeight: 1.8, whiteSpace: "pre-wrap", maxHeight: 380, overflowY: "auto" }}>
                {agentOutput}
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                <button onClick={() => { navigator.clipboard.writeText(agentOutput); showToast("Respuesta copiada ✓"); }} style={S.btn("o")}>Copiar respuesta</button>
                <button onClick={() => { setAgentOutput(""); setActiveAgent(null); }} style={S.btn("g")}>Limpiar</button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ============================================================
// MÓDULO PROMESAS (v7 base + mejoras v8)
// ============================================================
function ModPromesas({ promesas, onAdd, onUpdateEstado, onDelete, showToast }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ promesa: "", quien: "", fecha: "", pilar: "P05", fuente: "", evidencia: "" });
  const [genLoading, setGenLoading] = useState(false);
  const [nota, setNota] = useState("");

  const save = () => {
    if (!form.promesa || !form.quien || !form.fecha) { showToast("Completá los campos obligatorios (*)"); return; }
    onAdd({ ...form, id: Date.now(), estado: "Abierta", codigo: "P" + String(promesas.length + 1).padStart(3, "0") });
    setForm({ promesa: "", quien: "", fecha: "", pilar: "P05", fuente: "", evidencia: "" });
    setShowForm(false);
    showToast("Ficha registrada ✓");
  };

  const genNota = async () => {
    if (promesas.length === 0) { showToast("Registrá al menos una promesa"); return; }
    setGenLoading(true);
    try {
      const csv = promesas.map(p => `${p.codigo}: ${p.promesa} | ${p.quien} | ${p.fecha} | ${p.estado}`).join("\n");
      const reply = await callClaude([{ role: "user", content: `Actuá como Agente Accountability de El Rufino. Con este registro:\n\n${csv}\n\nRedactá: 1) Nota 600-800 palabras con seguimiento de una promesa (la más relevante), 2) Hilo Facebook 5-7 posts, 3) Resumen WhatsApp máx 3 líneas. Protocolo verificador no opositor. Usá "según la versión oficial..." cuando cites.` }]);
      setNota(reply);
    } catch { showToast("Error de conexión"); }
    finally { setGenLoading(false); }
  };

  const estadoColors = { "Abierta": "y", "En curso": "b", "Cumplida": "g", "Incumplida": "r", "Parcial": "b" };

  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO 10 / 17 · SEGUIMIENTO</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Registro de Promesas</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Cada anuncio oficial abre una ficha. Protocolo: verificador, no opositor. Persistido en wp_er_promesas.</div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <SLabel style={{ margin: 0 }}>Fichas activas ({promesas.length})</SLabel>
        <button onClick={() => setShowForm(p => !p)} style={S.btn("p")}>+ Nueva ficha</button>
      </div>

      {showForm && (
        <div style={{ ...S.card, marginBottom: 14, borderLeft: `3px solid ${PALETA.rojo}` }}>
          <SLabel>Nueva ficha de promesa</SLabel>
          <div style={{ marginBottom: 10 }}>
            <label style={{ fontSize: 10, fontWeight: 700, fontFamily: "monospace", display: "block", marginBottom: 4 }}>Qué se prometió *</label>
            <input value={form.promesa} onChange={e => setForm(p => ({ ...p, promesa: e.target.value }))} placeholder="Ej: Asfaltar las calles del Barrio Norte en 90 días" style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11 }} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
            <div>
              <label style={{ fontSize: 10, fontWeight: 700, fontFamily: "monospace", display: "block", marginBottom: 4 }}>Quién prometió *</label>
              <input value={form.quien} onChange={e => setForm(p => ({ ...p, quien: e.target.value }))} placeholder="Ej: Intendente García" style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11 }} />
            </div>
            <div>
              <label style={{ fontSize: 10, fontWeight: 700, fontFamily: "monospace", display: "block", marginBottom: 4 }}>Fecha *</label>
              <input type="date" value={form.fecha} onChange={e => setForm(p => ({ ...p, fecha: e.target.value }))} style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11 }} />
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
            <div>
              <label style={{ fontSize: 10, fontWeight: 700, fontFamily: "monospace", display: "block", marginBottom: 4 }}>Pilar</label>
              <select value={form.pilar} onChange={e => setForm(p => ({ ...p, pilar: e.target.value }))} style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, background: "#fafaf8" }}>
                {PILARES.map(p => <option key={p.code} value={p.code}>{p.code} — {p.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 10, fontWeight: 700, fontFamily: "monospace", display: "block", marginBottom: 4 }}>Fuente verificable</label>
              <input value={form.fuente} onChange={e => setForm(p => ({ ...p, fuente: e.target.value }))} placeholder="Conferencia de prensa, fecha" style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11 }} />
            </div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 10, fontWeight: 700, fontFamily: "monospace", display: "block", marginBottom: 4 }}>Evidencia actual</label>
            <textarea value={form.evidencia} onChange={e => setForm(p => ({ ...p, evidencia: e.target.value }))} placeholder="Lo que se sabe hasta ahora." style={{ width: "100%", padding: "8px 10px", border: `1px solid ${PALETA.crema3}`, borderRadius: 4, fontSize: 11, resize: "vertical", minHeight: 50 }} />
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={save} style={S.btn("p")}>Guardar ficha</button>
            <button onClick={() => setShowForm(false)} style={S.btn("g")}>Cancelar</button>
          </div>
        </div>
      )}

      {promesas.length === 0 ? (
        <div style={{ textAlign: "center", padding: 30, color: "#bbb", fontSize: 12, fontFamily: "monospace" }}>
          No hay fichas registradas.<br /><span style={{ fontSize: 10 }}>Cada anuncio oficial genera una ficha.</span>
        </div>
      ) : (
        promesas.map(p => (
          <div key={p.id} style={{ ...S.card, marginBottom: 8 }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 8, marginBottom: 6 }}>
              <span style={{ fontSize: 9, fontFamily: "monospace", color: "#bbb", background: "#f5f5f5", padding: "2px 6px", borderRadius: 3 }}>{p.codigo}</span>
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 13, color: PALETA.negro, flex: 1 }}>{p.promesa}</div>
              <span style={S.badge(estadoColors[p.estado] || "gr")}>{p.estado}</span>
            </div>
            <div style={{ display: "flex", gap: 12, fontSize: 10, color: "#888", fontFamily: "monospace", marginBottom: 8 }}>
              <span>{p.quien}</span><span>{p.fecha}</span><span>{p.pilar}</span>
            </div>
            <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
              {["En curso", "Cumplida", "Incumplida"].map(e => (
                <button key={e} onClick={() => onUpdateEstado(p.id, e)} style={{ ...S.btn("g"), fontSize: 9, padding: "3px 8px" }}>{e}</button>
              ))}
              <button onClick={() => { onDelete(p.id); showToast("Ficha eliminada"); }} style={{ ...S.btn("g"), fontSize: 9, padding: "3px 8px", marginLeft: "auto", color: "#e53935" }}>×</button>
            </div>
          </div>
        ))
      )}

      <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
        <button onClick={genNota} disabled={genLoading} style={{ ...S.btn("o"), opacity: genLoading ? .6 : 1 }}>Generar nota de seguimiento ↗</button>
      </div>
      <AILoader loading={genLoading} label="Agente Accountability generando nota..." />
      {nota && (
        <div style={{ marginTop: 12 }}>
          <SLabel>Nota generada</SLabel>
          <div style={{ background: "#fff", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, padding: 14, fontSize: 12, lineHeight: 1.8, whiteSpace: "pre-wrap", maxHeight: 300, overflowY: "auto" }}>{nota}</div>
          <button onClick={() => { navigator.clipboard.writeText(nota); showToast("Nota copiada ✓"); }} style={{ ...S.btn("o"), marginTop: 8 }}>Copiar</button>
        </div>
      )}
    </div>
  );
}

// ============================================================
// MÓDULO ROADMAP (actualizado v8)
// ============================================================
function ModRoadmap() {
  const semaforos = [
    { label: "Identidad — Fase 1", status: "g", txt: "CERRADA DEFINITIVAMENTE" },
    { label: "Plugin v8.0.0", status: "g", txt: "activo" },
    { label: "WordPress / técnica", status: "y", txt: "configuración incompleta" },
    { label: "Imágenes institucionales", status: "g", txt: "logo + favicon + OG ✓" },
    { label: "SEO / Rank Math", status: "y", txt: "schema pendiente" },
    { label: "Dominios — NIC Argentina", status: "r", txt: "elrufino.com.ar · pendiente registro" },
    { label: "Categorías P01-P06", status: "r", txt: "sin crear — BLOQUEA FASE 2" },
    { label: "Canal WhatsApp", status: "r", txt: "sin configurar — BLOQUEA FASE 2" },
    { label: "Registro de promesas", status: "y", txt: "módulo activo · fichas pendientes" },
    { label: "Monetización", status: "p", txt: "esperar hábito y reputación — FASE 3" },
    { label: "Themes Región / RN33", status: "p", txt: "estructura lista · PAUSA FASE 3" },
  ];
  const semColors = { g: "#43a047", y: "#fb8c00", r: "#e53935", p: "#78909c" };

  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO 17 / 17</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Roadmap</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Estado del proyecto. Semáforos vivos. Fase 2 en ejecución.</div>

      <SLabel>Semáforos de estado</SLabel>
      {semaforos.map((s, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderBottom: `1px solid ${PALETA.crema3}` }}>
          <div style={{ width: 9, height: 9, borderRadius: "50%", background: semColors[s.status], boxShadow: `0 0 6px ${semColors[s.status]}50`, flexShrink: 0 }} />
          <span style={{ fontSize: 11, color: PALETA.negro, flex: 1 }}>{s.label}</span>
          <span style={{ fontSize: 9, color: "#999", fontFamily: "monospace" }}>{s.txt}</span>
        </div>
      ))}

      <Divider />
      <SLabel>Objetivo 90 días</SLabel>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
        {[
          { badge: "b", label: "Día 1–15", txt: "Dominio NIC · categorías P01-P06 · imágenes · Canal WA · Schema" },
          { badge: "y", label: "Día 16–45", txt: "Lanzar con pieza fuerte · sostener frecuencia · primera ficha pública · medir" },
          { badge: "r", label: "Día 46–90", txt: "Primera alianza local · hábito · validar formatos · preparar monetización" },
        ].map(({ badge, label, txt }) => (
          <div key={label} style={S.card}>
            <span style={{ ...S.badge(badge), marginBottom: 5, display: "inline-flex" }}>{label}</span>
            <div style={{ fontSize: 11, color: "#555", lineHeight: 1.6 }}>{txt}</div>
          </div>
        ))}
      </div>

      <Divider />
      <SLabel>Riesgos activos</SLabel>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {[
          { badge: "r", level: "ALTO", name: "Portalitis", desc: "Querer ser todo desde el día 1. Identidad diluida." },
          { badge: "r", level: "ALTO", name: "Publicar por ansiedad", desc: "Competir en velocidad con Sucesos. No es la ventaja." },
          { badge: "y", level: "MEDIO", name: "Una sola voz", desc: "El proyecto necesita más de una persona funcional." },
          { badge: "y", level: "MEDIO", name: "Monetización precoz", desc: "Antes de construir hábito de audiencia." },
        ].map(({ badge, level, name, desc }) => (
          <div key={name} style={S.card}>
            <span style={{ ...S.badge(badge), marginBottom: 5, display: "inline-flex" }}>{level}</span>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 13, color: PALETA.negro, fontWeight: 700, marginBottom: 4 }}>{name}</div>
            <div style={{ fontSize: 11, color: "#555", lineHeight: 1.5 }}>{desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// MÓDULO CONTEXTO IA (bloque v1.2 editable)
// ============================================================
function ModContexto({ showToast }) {
  const defaultCtx = `PROYECTO = EL RUFINO
CONTEXTO_IA_VIGENTE = v1.2 · 12-abr-2026
CIUDAD = Rufino, Santa Fe, Argentina · 19.211 hab INDEC 2022 · ~7.200 hogares · ~14.000 FB activos
CLAIM = "Lo que pasa y lo que significa"
SECUENCIA = medio confiable -> portal util -> infraestructura territorial
NO_HACER = portal total prematuro · panfleto frontal · comunicado sin segunda capa · publicar por ansiedad
PALETA = #c0271b rojo · #1a1a1a negro · #ffffff blanco · #f5f0e8 crema
TIPOGRAFIA = Playfair Display titulos + Source Serif 4/Inter cuerpo
VOZ_EDITORIAL = directa sin agresiva · verificado · local sin localista · humano sin amarillista
DOMINIO_CANONICO = elrufino.com.ar (ACTIVO Hostinger · WordPress)
DOMINIO_MARCA = elrufino.ar (pendiente · 301 a.com.ar cuando registre)
PLUGIN = v8.0.0 "El Rufino - Panel" · 17 modulos · 12 agentes IA · tabla wp_er_promesas activa
FASE_ACTUAL = Fase 0 reconstruccion + Fase 2 producto minimo EN EJECUCION
FASE_2_COMPLETA_CUANDO = 6 categorias P01-P06 creadas + logo/favicon/OG subidos + Schema NewsMediaOrganization + 20 notas publicadas + 500 WA suscriptores
EXPANSION_REGIONAL = PAUSADA · corredor RN33 es horizonte futuro · no activar Modulo 5
PILARES = P01 Lo que pasa · P02 El campo habla · P03 Barrio a barrio · P04 Generacion Rufino · P05 Seguimiento de promesas · P06 Contexto y datos
REGLA_DOS_CAPAS = OBLIGATORIA: Capa1 hecho verificado · Capa2 que significa/contexto/pregunta
PROTOCOLO_POLICIALES = version policial no es verdad cerrada · aclarar "segun" · no imagenes humillantes automaticas
PROTOCOLO_PROMESAS = todo anuncio oficial abre ficha en wp_er_promesas con fecha/fuente/estado/evidencia
PROTOCOLO_TRAGEDIA = no imagenes explicitas · esperar 2 fuentes · enfoque servicio no morbo
AGENTES = 12 operativos · v8 · incluye 6A TikTok + 6B Reels + 12 Crisis
VOCES = Fabian Longo (El Diferente) · Adriana Gimenez (Voces otra mirada)
DECISIONES = NO reabrir sin indicacion explicita del usuario`;

  const [ctx, setCtx] = useState(defaultCtx);

  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO 12 / 17 · INTELIGENCIA</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Contexto IA v1.2</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Bloque de transferencia rápida. Copiá y pegá al inicio de cada sesión nueva.</div>

      <div style={{ background: "#f8f7f4", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, overflow: "hidden" }}>
        <div style={{ background: "#111", padding: "8px 12px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 9, color: "#888", fontFamily: "monospace", letterSpacing: 1 }}>EL RUFINO · CONTEXT TRANSFER BLOCK · v1.2</span>
          <div style={{ display: "flex", gap: 5 }}>
            <button onClick={() => setCtx(defaultCtx)} style={{ fontSize: 9, padding: "3px 8px", background: "#1e1e1e", color: "#555", border: "1px solid #2a2a2a", borderRadius: 3, cursor: "pointer" }}>Restaurar</button>
            <button onClick={() => { navigator.clipboard.writeText(ctx); showToast("Bloque copiado ✓"); }} style={{ fontSize: 9, padding: "3px 8px", background: PALETA.rojo, color: "#fff", border: "none", borderRadius: 3, cursor: "pointer" }}>Copiar todo</button>
          </div>
        </div>
        <textarea value={ctx} onChange={e => setCtx(e.target.value)} spellCheck={false} style={{ width: "100%", background: "#f8f7f4", border: "none", color: "#2d5a27", fontSize: 10, fontFamily: "monospace", padding: 14, lineHeight: 1.7, resize: "vertical", minHeight: 320, outline: "none" }} />
      </div>

      <Info title="Cómo usarlo">
        Al inicio de cada sesión nueva de IA, copiá este bloque y pegalo antes del pedido. Actualizá cada vez que tomés una decisión nueva. Versionado: v1.2 → v1.3 al tomar decisión nueva.
      </Info>
    </div>
  );
}

// ============================================================
// MÓDULO REDES (actualizado v8)
// ============================================================
function ModRedes({ showToast }) {
  const plataformas = [
    { name: "Facebook", meta: "Base y credibilidad · 25–60 años · 3–5 posts/día", status: "y", statusLabel: "CONFIGURAR", kpi: "5.000", kpiLabel: "likes · mes 6" },
    { name: "Instagram", meta: "Marca visual · 18–40 años · 1 post + stories/día", status: "y", statusLabel: "CONFIGURAR", kpi: "2.000", kpiLabel: "seguidores · mes 6" },
    { name: "WhatsApp Canal", meta: "Distribución directa · todos · 7:30 AM diario", status: "r", statusLabel: "CRÍTICO", kpi: "500", kpiLabel: "suscriptores · mes 3" },
    { name: "TikTok (6A)", meta: "Cancha vacía · 14–24 años · hook nativo · 3–4/semana", status: "gr", statusLabel: "HORIZONTE", kpi: "1", kpiLabel: "viral · 60 días" },
    { name: "Reels (6B)", meta: "Marca editorial · 22–40 años · estética ER · 3–4/semana", status: "gr", statusLabel: "HORIZONTE", kpi: "1", kpiLabel: "viral · 60 días" },
  ];

  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO 13 / 17 · SEGUIMIENTO</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Redes Sociales</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Estado de cuentas y KPIs a mes 6. TikTok y Reels separados como 6A y 6B.</div>

      {plataformas.map((p, i) => (
        <div key={i} style={{ background: "#fff", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, padding: 13, display: "grid", gridTemplateColumns: "1fr auto", gap: 8, alignItems: "start", boxShadow: "0 1px 4px rgba(0,0,0,.08)", marginBottom: 6 }}>
          <div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 13, color: PALETA.negro, fontWeight: 700, marginBottom: 3 }}>{p.name}</div>
            <div style={{ fontSize: 10, color: "#888" }}>{p.meta}</div>
            <div style={{ marginTop: 6 }}><span style={S.badge(p.status)}>{p.statusLabel}</span></div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, color: PALETA.rojo, fontWeight: 900 }}>{p.kpi}</div>
            <div style={{ fontSize: 9, color: "#aaa", fontFamily: "monospace" }}>{p.kpiLabel}</div>
          </div>
        </div>
      ))}

      <Warn title="WhatsApp Canal — crítico">
        El canal WA broadcast es el único canal de distribución directa. Sin él no hay forma de llegar a los 500 suscriptores necesarios para cerrar Fase 2. Activar antes de publicar la primera nota.
      </Warn>
    </div>
  );
}

// ============================================================
// MÓDULO CONTENIDO EDITORIAL
// ============================================================
function ModContenido() {
  return (
    <div>
      <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO 09 / 17 · EDITORIAL</div>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Contenido Editorial</div>
      <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8, maxWidth: 620, marginBottom: 16 }}>Pilares editoriales, calendario semanal. Regla madre: toda pieza tiene dos capas.</div>

      <SLabel>6 Pilares Editoriales</SLabel>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 16 }}>
        {PILARES.map(p => (
          <div key={p.code} style={{ ...S.card, borderLeft: `3px solid ${p.color}` }}>
            <div style={{ fontSize: 9, fontFamily: "monospace", color: p.color, fontWeight: 700, marginBottom: 4 }}>{p.code}</div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 13, color: PALETA.negro, fontWeight: 700, marginBottom: 3 }}>{p.name}</div>
            <div style={{ fontSize: 10, color: "#888" }}>{p.fmt}</div>
          </div>
        ))}
      </div>

      <SLabel>Calendario semanal tipo</SLabel>
      <div style={{ background: "#fff", border: `1px solid ${PALETA.crema3}`, borderRadius: 6, padding: 13, marginBottom: 14 }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 3 }}>
          {[
            { d: "LUN", p: "P01+P06" }, { d: "MAR", p: "P02" }, { d: "MIÉ", p: "P04" },
            { d: "JUE", p: "P05" }, { d: "VIE", p: "P03" }, { d: "SÁB", p: "P04" }, { d: "DOM", p: "↓" }
          ].map(({ d, p }) => (
            <div key={d} style={{ textAlign: "center", fontSize: 9, padding: "8px 3px", background: "#fff", borderRadius: 4, border: `1px solid ${PALETA.crema3}` }}>
              <div style={{ fontWeight: 700, color: PALETA.rojo, marginBottom: 3, fontFamily: "monospace", fontSize: 8 }}>{d}</div>
              <div style={{ color: "#888", fontSize: 9 }}>{p}</div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 10, fontSize: 10, color: "#888", fontFamily: "monospace" }}>7:30 AM — Resumen WhatsApp todos los días · Sin segunda capa = no va</div>
      </div>

      <Info title="Regla de las 2 capas — OBLIGATORIA">
        Capa 1: hecho verificado (qué pasó). Capa 2: qué significa / contexto / pregunta que queda abierta. Sin la segunda capa, la pieza no se publica.
      </Info>
    </div>
  );
}

// ============================================================
// APP PRINCIPAL
// ============================================================
function ElRufinoPanel() {
  const [cur, setCur] = useState(0);
  const [promesas, setPromesas] = useState([]);
  const [metrics, setMetrics] = useState({});
  const [toast, setToast] = useState("");
  const toastTimer = useRef(null);

  const showToast = useCallback((msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 2600);
  }, []);

  // Cargar promesas desde WP DB al montar
  useEffect(() => {
    if (!window.ER_AJAX) return;
    wpAjax('er_get_promesas').then(r => {
      if (r.success && r.data) setPromesas(r.data);
    }).catch(() => {});
  }, []);

  // Agregar promesa — persiste en WP DB
  const handleAddPromesa = async (p) => {
    if (window.ER_AJAX) {
      const r = await wpAjax('er_save_promesa', p);
      if (r.success) {
        setPromesas(prev => [{ ...p, id: r.data.id }, ...prev]);
        showToast("Ficha guardada en BD ✓");
      } else {
        showToast("Error al guardar en BD");
      }
    } else {
      setPromesas(prev => [...prev, p]);
    }
  };

  // Actualizar estado — persiste en WP DB
  const handleUpdateEstado = async (id, estado) => {
    setPromesas(prev => prev.map(p => p.id === id ? { ...p, estado } : p));
    if (window.ER_AJAX) {
      await wpAjax('er_update_estado', { id, estado });
    }
  };

  // Eliminar promesa — persiste en WP DB
  const handleDeletePromesa = async (id) => {
    setPromesas(prev => prev.filter(p => p.id !== id));
    if (window.ER_AJAX) {
      await wpAjax('er_delete_promesa', { id });
    }
  };

  const MODULES = [
    { label: "Inicio", section: "BASE", badge: "v8" },
    { label: "Chat IA", section: "INTELIGENCIA", badge: "🔴 LIVE" },
    { label: "Redactor IA", section: "PRODUCCIÓN" },
    { label: "Kanban Editorial", section: "PRODUCCIÓN" },
    { label: "Compositor WA", section: "PRODUCCIÓN" },
    { label: "Contenido", section: "EDITORIAL" },
    { label: "Promesas", section: "SEGUIMIENTO", badge: promesas.length || null },
    { label: "Agentes IA", section: "INTELIGENCIA", badge: "12" },
    { label: "Contexto IA", section: "INTELIGENCIA" },
    { label: "Redes", section: "SEGUIMIENTO" },
    { label: "Themes Región", section: "FUTURO" },
    { label: "Roadmap", section: "BASE" },
  ];

  const sections = [...new Set(MODULES.map(m => m.section))];

  const renderModule = () => {
    switch (cur) {
      case 0: return <ModInicio promesas={promesas} metrics={metrics} onSetMetric={(k, v) => setMetrics(p => ({ ...p, [k]: v }))} />;
      case 1: return <ModChatIA showToast={showToast} />;
      case 2: return <ModRedactorIA showToast={showToast} />;
      case 3: return <ModKanban showToast={showToast} />;
      case 4: return <ModWhatsApp showToast={showToast} />;
      case 5: return <ModContenido />;
      case 6: return <ModPromesas promesas={promesas} onAdd={handleAddPromesa} onUpdateEstado={handleUpdateEstado} onDelete={handleDeletePromesa} showToast={showToast} />;
      case 7: return <ModAgentes showToast={showToast} />;
      case 8: return <ModContexto showToast={showToast} />;
      case 9: return <ModRedes showToast={showToast} />;
      case 10: return (
        <div>
          <div style={{ fontSize: 9, color: PALETA.rojo, letterSpacing: "3px", textTransform: "uppercase", fontWeight: 700, marginBottom: 6, fontFamily: "monospace" }}>MÓDULO 11 / 17 · HORIZONTE FUTURO</div>
          <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, color: PALETA.negro, lineHeight: 1.1, marginBottom: 8 }}>Themes Región</div>
          <Warn title="⏸ EXPANSIÓN EN PAUSA — FASE 3">No activar antes de consolidar El Rufino con hábito de audiencia, reputación y al menos 1 alianza local. El corredor RN33 es horizonte futuro. Módulo deshabilitado para evitar portalitis.</Warn>
          <div style={{ marginTop: 16, ...S.card }}>
            <div style={{ fontSize: 12, color: "#555", lineHeight: 1.8 }}>Ciudades en horizonte: Amenábar · Sancti Spíritu · Aarón Castellanos. Estructura lista, activación en Fase 3.</div>
          </div>
        </div>
      );
      case 11: return <ModRoadmap />;
      default: return null;
    }
  };

  return (
    <div style={S.shell}>
      <div style={S.sidebar}>
        <div style={S.sbHead}>
          <div style={S.logoMark}>EL RUFINO</div>
          <div style={S.verTag}>
            <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#43a047" }} />
            Plugin v8.0.0 · Panel IA
          </div>
        </div>
        <div style={S.sbNav}>
          {sections.map(section => (
            <div key={section}>
              <div style={S.ns}>{section}</div>
              {MODULES.map((m, i) => m.section === section && (
                <NavItem key={i} label={m.label} active={cur === i} onClick={() => setCur(i)} badge={m.badge} />
              ))}
            </div>
          ))}
        </div>
        <div style={{ padding: "10px 14px", borderTop: `1px solid ${PALETA.crema3}`, display: "flex", flexDirection: "column", gap: 6 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 9, color: "#888", fontFamily: "monospace" }}>
            <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#43a047", boxShadow: "0 0 6px #43a04760" }} />
            elrufino.com.ar
          </div>
          <div style={{ fontSize: 9, background: "#f5f0e8", color: "#888", border: `1px solid ${PALETA.crema3}`, padding: "3px 7px", borderRadius: 3, fontFamily: "monospace", textAlign: "center" }}>
            FASE 2 EN EJECUCIÓN
          </div>
        </div>
      </div>

      <div style={S.main}>
        <div style={S.topbar}>
          <div style={{ fontSize: 9, color: "#888", fontFamily: "monospace", letterSpacing: 1, textTransform: "uppercase" }}>{MODULES[cur]?.section}</div>
          <div style={{ width: 1, height: 12, background: "#222", flexShrink: 0 }} />
          <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 14, opacity: .75, flex: 1 }}>{MODULES[cur]?.label}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 9, color: "#888", fontFamily: "monospace" }}>{cur + 1}/{MODULES.length}</span>
            <div style={{ width: 80, height: 2, background: "#333", borderRadius: 1 }}>
              <div style={{ height: "100%", background: PALETA.rojo, borderRadius: 1, width: `${(cur + 1) / MODULES.length * 100}%`, transition: "width .3s" }} />
            </div>
          </div>
          <div style={{ fontSize: 9, fontFamily: "monospace", color: "#aaa", padding: "2px 8px", border: "1px solid #444", borderRadius: 3 }}>
            {CIUDAD_DATA.dominio}
          </div>
        </div>

        <div style={S.content}>
          {renderModule()}
        </div>

        <div style={S.navFt}>
          <button onClick={() => setCur(p => Math.max(0, p - 1))} disabled={cur === 0} style={{ fontSize: 11, padding: "7px 18px", borderRadius: 4, border: `1px solid ${PALETA.crema3}`, background: "transparent", color: "#888", cursor: cur === 0 ? "default" : "pointer", opacity: cur === 0 ? .3 : 1, fontWeight: 700 }}>← Anterior</button>
          <span style={{ fontSize: 10, color: "#aaa", fontFamily: "monospace" }}>{cur + 1} de {MODULES.length}</span>
          <button onClick={() => setCur(p => Math.min(MODULES.length - 1, p + 1))} disabled={cur === MODULES.length - 1} style={{ fontSize: 11, padding: "7px 18px", borderRadius: 4, border: "none", background: PALETA.rojo, color: "#fff", cursor: cur === MODULES.length - 1 ? "default" : "pointer", opacity: cur === MODULES.length - 1 ? .3 : 1, fontWeight: 700 }}>Siguiente →</button>
        </div>
      </div>

      <Toast msg={toast} />
    </div>
  );
}

// ============================================================
// WP AJAX HELPERS — reemplaza el estado local de promesas
// ============================================================
async function wpAjax(action, params = {}) {
  const body = new URLSearchParams({ action, nonce: window.ER_AJAX?.nonce || '', ...params });
  const res  = await fetch(window.ER_AJAX?.url || '/wp-admin/admin-ajax.php', { method: 'POST', body });
  return res.json();
}

// Mount
const erRoot = document.getElementById('er-panel-root');
if (erRoot) {
  const root = ReactDOM.createRoot(erRoot);
  root.render(<ElRufinoPanel />);
}
