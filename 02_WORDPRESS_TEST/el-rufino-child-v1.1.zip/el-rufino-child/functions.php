<?php
/**
 * El Rufino — Child Theme functions.php
 * Tema hijo flexible: funciona con Newsup, NewsMag, o cualquier tema padre de noticias.
 * Si el tema padre cambia, solo actualizar TEMPLATEPATH y revisar los hooks.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Enqueue parent + child styles ──
add_action( 'wp_enqueue_scripts', 'er_theme_enqueue' );
function er_theme_enqueue() {
    // Parent theme
    wp_enqueue_style(
        'parent-style',
        get_template_directory_uri() . '/style.css',
        [],
        wp_get_theme( get_template() )->get('Version')
    );
    // Child theme (overrides)
    wp_enqueue_style(
        'child-style',
        get_stylesheet_uri(),
        ['parent-style'],
        wp_get_theme()->get('Version')
    );
    // Google Fonts
    wp_enqueue_style(
        'er-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;800&family=Source+Serif+4:wght@400;600&family=Inter:wght@400;500;600&display=swap',
        [],
        null
    );
}

// ── Theme supports ──
add_action( 'after_setup_theme', 'er_theme_setup' );
function er_theme_setup() {
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'html5', ['search-form','comment-form','comment-list','gallery','caption'] );
    add_theme_support( 'custom-logo', [
        'height'      => 80,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    add_theme_support( 'customize-selective-refresh-widgets' );

    // Image sizes for the medium
    add_image_size( 'er-featured',   780, 440, true );
    add_image_size( 'er-card',       400, 250, true );
    add_image_size( 'er-thumbnail',  160, 100, true );
    add_image_size( 'er-wide',      1200, 500, true );

    // Navigation menus
    register_nav_menus([
        'primary'   => 'Menú principal',
        'secondary' => 'Menú secundario',
        'footer'    => 'Menú footer',
    ]);
}

// ── Disable XML-RPC (security) ──
add_filter( 'xmlrpc_enabled', '__return_false' );

// ── Remove unnecessary head tags ──
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );

// ── WhatsApp subscribe shortcode ──
// Usage: [er_wa_subscribe texto="Suscribite" link="https://wa.me/..."]
add_shortcode( 'er_wa_subscribe', 'er_wa_subscribe_shortcode' );
function er_wa_subscribe_shortcode( $atts ) {
    $atts = shortcode_atts([
        'texto' => 'Recibí las 3 noticias de Rufino cada mañana a las 7:30 AM',
        'link'  => '#',
        'btn'   => 'Suscribirse gratis →',
    ], $atts );
    return '<div class="er-wa-block">
        <h4>📲 El Rufino en WhatsApp</h4>
        <p>' . esc_html($atts['texto']) . '</p>
        <a href="' . esc_url($atts['link']) . '" target="_blank" rel="noopener">' . esc_html($atts['btn']) . '</a>
    </div>';
}

// ── "Seguimiento" label shortcode ──
// Usage: [er_seguimiento estado="en proceso"]
add_shortcode( 'er_seguimiento', 'er_seguimiento_shortcode' );
function er_seguimiento_shortcode( $atts ) {
    $atts = shortcode_atts(['estado'=>'en seguimiento'], $atts);
    $colors = [
        'cumplida'   => '#dcfce7;color:#166534',
        'incumplida' => '#fee2e2;color:#991b1b',
        'en proceso' => '#dbeafe;color:#1e40af',
        'en seguimiento' => '#fef9c3;color:#854d0e',
    ];
    $style = $colors[ strtolower($atts['estado']) ] ?? '#f3f4f6;color:#374151';
    return '<span style="display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700;text-transform:uppercase;background:' . $style . '">' . esc_html($atts['estado']) . '</span>';
}

// ── Two-cap rule reminder in editor (admin only) ──
add_action( 'admin_footer-post.php', 'er_editor_reminder' );
add_action( 'admin_footer-post-new.php', 'er_editor_reminder' );
function er_editor_reminder() { ?>
    <script>
    (function(){
        var bar = document.createElement('div');
        bar.innerHTML = '<strong>REGLA DE 2 CAPAS:</strong> ¿La nota tiene (1) lo que pasó + (2) lo que significa? Sin segunda capa, no se publica.';
        bar.style.cssText = 'position:fixed;bottom:0;left:160px;right:0;background:#c0271b;color:#fff;padding:8px 20px;font-size:12px;z-index:9999;text-align:center';
        document.body.appendChild(bar);
    })();
    </script>
<?php }

// ── Suppress PHP notices from appearing in frontend ──
// (These should be fixed properly, but this prevents user-visible errors)
if ( ! WP_DEBUG ) {
    error_reporting( E_ERROR | E_PARSE );
    @ini_set( 'display_errors', 0 );
}

// ── Security headers ──
add_action( 'send_headers', 'er_security_headers' );
function er_security_headers() {
    header( 'X-Content-Type-Options: nosniff' );
    header( 'X-Frame-Options: SAMEORIGIN' );
    header( 'Referrer-Policy: strict-origin-when-cross-origin' );
}

// ── Custom excerpt length ──
add_filter( 'excerpt_length', function() { return 30; } );
add_filter( 'excerpt_more', function() { return '...'; } );
