<?php
/**
 * Plugin Name: El Rufino UI
 * Description: Capa visual editorial para El Rufino sobre WordPress/GeneratePress. Reordena el menú, convierte la portada en home editorial y limpia elementos de demo.
 * Version: 1.0.0
 * Author: OpenAI
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ERUI_VERSION', '1.0.0');
define('ERUI_PATH', plugin_dir_path(__FILE__));
define('ERUI_URL', plugin_dir_url(__FILE__));

function erui_get_page_id_by_title($title) {
    $page = get_page_by_title($title);
    return $page ? (int) $page->ID : 0;
}

function erui_get_category_link_by_name($name) {
    $term = get_term_by('name', $name, 'category');
    return ($term && !is_wp_error($term)) ? get_category_link($term->term_id) : home_url('/');
}

function erui_activation() {
    update_option('erui_whatsapp_url', '#');

    $inicio_id = erui_get_page_id_by_title('Inicio');
    if ($inicio_id) {
        wp_update_post([
            'ID'           => $inicio_id,
            'post_content' => "[el_rufino_home]\n\n<!-- Portada editorial generada por plugin -->",
        ]);
    }

    // Reordena el menú principal si existe.
    $locations = get_theme_mod('nav_menu_locations', []);
    if (!empty($locations['primary'])) {
        $menu_id = (int) $locations['primary'];
        $order = [
            'Inicio'            => $inicio_id,
            'Actualidad'        => erui_get_page_id_by_title('Actualidad'),
            'Seguimiento'       => erui_get_page_id_by_title('Seguimiento'),
            'Poder y gestión'   => erui_get_page_id_by_title('Poder y gestión'),
            'Barrio a barrio'   => erui_get_page_id_by_title('Barrio a barrio'),
            'El campo habla'    => erui_get_page_id_by_title('El campo habla'),
            'Rufino en datos'   => erui_get_page_id_by_title('Rufino en datos'),
            'Sobre El Rufino'   => erui_get_page_id_by_title('Sobre El Rufino'),
            'Contacto'          => erui_get_page_id_by_title('Contacto'),
        ];

        $menu_items = wp_get_nav_menu_items($menu_id);
        $existing = [];
        if ($menu_items) {
            foreach ($menu_items as $item) {
                $existing[(int) $item->object_id] = $item;
            }
        }

        $position = 1;
        foreach ($order as $label => $page_id) {
            if (!$page_id) {
                continue;
            }
            if (isset($existing[$page_id])) {
                wp_update_nav_menu_item($menu_id, $existing[$page_id]->ID, [
                    'menu-item-title'     => $label,
                    'menu-item-object-id' => $page_id,
                    'menu-item-object'    => 'page',
                    'menu-item-type'      => 'post_type',
                    'menu-item-status'    => 'publish',
                    'menu-item-position'  => $position,
                ]);
            } else {
                wp_update_nav_menu_item($menu_id, 0, [
                    'menu-item-title'     => $label,
                    'menu-item-object-id' => $page_id,
                    'menu-item-object'    => 'page',
                    'menu-item-type'      => 'post_type',
                    'menu-item-status'    => 'publish',
                    'menu-item-position'  => $position,
                ]);
            }
            $position++;
        }
    }
}
register_activation_hook(__FILE__, 'erui_activation');

function erui_enqueue_assets() {
    wp_enqueue_style('erui-style', ERUI_URL . 'assets/el-rufino-ui.css', [], ERUI_VERSION);
}
add_action('wp_enqueue_scripts', 'erui_enqueue_assets');

function erui_body_classes($classes) {
    $classes[] = 'el-rufino-ui';
    if (is_front_page()) {
        $classes[] = 'el-rufino-home-active';
    }
    return $classes;
}
add_filter('body_class', 'erui_body_classes');

function erui_filter_footer_credit($copyright) {
    return '&copy; ' . esc_html(date('Y')) . ' El Rufino · Lo que pasa y lo que significa.';
}
add_filter('generate_copyright', 'erui_filter_footer_credit');

function erui_get_posts_for_category($category_name, $limit = 3) {
    $term = get_term_by('name', $category_name, 'category');
    $args = [
        'post_type'           => 'post',
        'posts_per_page'      => $limit,
        'ignore_sticky_posts' => true,
    ];
    if ($term && !is_wp_error($term)) {
        $args['cat'] = (int) $term->term_id;
    }
    return new WP_Query($args);
}

function erui_render_post_list($title, $category_name, $empty_text, $limit = 3) {
    $query = erui_get_posts_for_category($category_name, $limit);
    $link  = erui_get_category_link_by_name($category_name);
    ob_start();
    ?>
    <section class="erui-block">
        <div class="erui-block-head">
            <h2><?php echo esc_html($title); ?></h2>
            <a href="<?php echo esc_url($link); ?>">Ver sección</a>
        </div>
        <?php if ($query->have_posts()) : ?>
            <div class="erui-card-grid">
                <?php while ($query->have_posts()) : $query->the_post(); ?>
                    <article class="erui-card">
                        <div class="erui-card-meta"><?php echo esc_html(get_the_date()); ?></div>
                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <p><?php echo esc_html(wp_trim_words(get_the_excerpt() ?: get_the_content(), 24)); ?></p>
                    </article>
                <?php endwhile; ?>
            </div>
        <?php else : ?>
            <div class="erui-empty-card">
                <h3><?php echo esc_html($title); ?></h3>
                <p><?php echo esc_html($empty_text); ?></p>
            </div>
        <?php endif; wp_reset_postdata(); ?>
    </section>
    <?php
    return ob_get_clean();
}

function erui_shortcode_home() {
    $actualidad = new WP_Query([
        'post_type'           => 'post',
        'posts_per_page'      => 1,
        'ignore_sticky_posts' => true,
    ]);
    $whatsapp_url = get_option('erui_whatsapp_url', '#');

    ob_start();
    ?>
    <div class="erui-home">
        <section class="erui-hero">
            <div class="erui-hero-copy">
                <div class="erui-kicker">Nuevo medio digital local</div>
                <h1>El Rufino</h1>
                <p class="erui-tagline">Lo que pasa y lo que significa.</p>
                <p class="erui-lead">Información verificada, contexto útil y seguimiento de los temas que afectan la vida cotidiana, institucional, económica y social de Rufino.</p>
                <div class="erui-hero-actions">
                    <a class="erui-btn erui-btn-primary" href="<?php echo esc_url(get_permalink(erui_get_page_id_by_title('Actualidad')) ?: home_url('/')); ?>">Leer actualidad</a>
                    <a class="erui-btn erui-btn-secondary" href="<?php echo esc_url(get_permalink(erui_get_page_id_by_title('Seguimiento')) ?: home_url('/')); ?>">Ver seguimiento</a>
                </div>
            </div>
            <div class="erui-hero-panel">
                <div class="erui-mini-stat">
                    <span>Foco editorial</span>
                    <strong>Contexto + seguimiento</strong>
                </div>
                <div class="erui-mini-stat">
                    <span>Audiencia estratégica</span>
                    <strong>Rufino + campo + barrios</strong>
                </div>
                <div class="erui-mini-stat">
                    <span>Estado</span>
                    <strong>Entorno de armado del MVP</strong>
                </div>
            </div>
        </section>

        <section class="erui-featured">
            <div class="erui-block-head">
                <h2>Destacado principal</h2>
                <a href="<?php echo esc_url(get_permalink(erui_get_page_id_by_title('Actualidad')) ?: home_url('/')); ?>">Ir a actualidad</a>
            </div>
            <?php if ($actualidad->have_posts()) : $actualidad->the_post(); ?>
                <article class="erui-featured-card">
                    <div class="erui-card-meta"><?php echo esc_html(get_the_date()); ?></div>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php echo esc_html(wp_trim_words(get_the_excerpt() ?: get_the_content(), 40)); ?></p>
                </article>
            <?php else : ?>
                <article class="erui-featured-card erui-placeholder">
                    <div class="erui-card-meta">Módulo preparado</div>
                    <h3>Acá irá la noticia o análisis principal del día</h3>
                    <p>Este bloque está pensado para alojar la pieza más fuerte de la jornada: noticia, investigación breve, contexto o seguimiento prioritario.</p>
                </article>
            <?php endif; wp_reset_postdata(); ?>
        </section>

        <div class="erui-columns">
            <div class="erui-main-column">
                <?php echo erui_render_post_list('Últimas publicaciones', 'Actualidad', 'Todavía no hay notas cargadas en Actualidad. Este bloque mostrará las últimas publicaciones del medio.', 3); ?>
                <?php echo erui_render_post_list('Barrio a barrio', 'Barrio a barrio', 'Este módulo seguirá problemas urbanos, reclamos vecinales y evolución territorial por zona.', 2); ?>
                <?php echo erui_render_post_list('El campo habla', 'El campo habla', 'Acá irá la cobertura del agro, rutas, economía regional y voz del productor.', 2); ?>
            </div>
            <aside class="erui-side-column">
                <section class="erui-aside-box">
                    <h2>Seguimiento</h2>
                    <p>Registro visible de promesas, obras, anuncios y temas que el medio no abandona tras la publicación inicial.</p>
                    <a class="erui-text-link" href="<?php echo esc_url(get_permalink(erui_get_page_id_by_title('Seguimiento')) ?: home_url('/')); ?>">Entrar a seguimiento</a>
                </section>
                <section class="erui-aside-box">
                    <h2>Rufino en datos</h2>
                    <p>Espacio para indicadores, visualización y lectura numérica de los temas locales.</p>
                    <a class="erui-text-link" href="<?php echo esc_url(get_permalink(erui_get_page_id_by_title('Rufino en datos')) ?: home_url('/')); ?>">Ver datos</a>
                </section>
                <section class="erui-aside-box erui-wa-box">
                    <h2>Canal de WhatsApp</h2>
                    <p>Resumen diario, circulación directa y acceso sin algoritmo. Reemplazá este vínculo por el canal real cuando lo actives.</p>
                    <a class="erui-btn erui-btn-primary erui-btn-full" href="<?php echo esc_url($whatsapp_url); ?>">Sumarme</a>
                </section>
                <section class="erui-aside-box">
                    <h2>Sobre El Rufino</h2>
                    <p>Medio digital local orientado a producir información verificada, contexto útil y seguimiento de los temas que afectan la vida de la ciudad.</p>
                    <a class="erui-text-link" href="<?php echo esc_url(get_permalink(erui_get_page_id_by_title('Sobre El Rufino')) ?: home_url('/')); ?>">Conocer el proyecto</a>
                </section>
            </aside>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('el_rufino_home', 'erui_shortcode_home');

function erui_register_settings() {
    register_setting('reading', 'erui_whatsapp_url', [
        'type'              => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default'           => '#',
    ]);

    add_settings_field(
        'erui_whatsapp_url',
        'El Rufino · URL de WhatsApp',
        function () {
            $value = get_option('erui_whatsapp_url', '#');
            echo '<input type="url" class="regular-text" name="erui_whatsapp_url" value="' . esc_attr($value) . '" placeholder="https://whatsapp.com/channel/..." />';
            echo '<p class="description">Enlace del canal de WhatsApp que aparecerá en la portada editorial.</p>';
        },
        'reading'
    );
}
add_action('admin_init', 'erui_register_settings');
