/* El Rufino — Plugin JS v2.0 */
(function($){
'use strict';

// ── Modals ──
window.erOpenModal = function(id) {
    document.getElementById(id).style.display = 'flex';
};
window.erCloseModal = function(id) {
    document.getElementById(id).style.display = 'none';
};
// Close on overlay click
document.addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('er-modal-overlay')) {
        e.target.style.display = 'none';
    }
});

// ── Checklist ──
var erTotal = parseInt(document.getElementById('er-checklist-wrap')?.dataset?.total || 0);

window.erToggleCheck = function(item) {
    var key = item.dataset.key;
    var cb  = item.querySelector('.er-checkbox');
    var txt = item.querySelector('.er-check-text');
    var done = !cb.classList.contains('er-checked');

    cb.classList.toggle('er-checked', done);
    cb.textContent = done ? '✓' : '';
    item.classList.toggle('er-done', done);

    // Save to DB
    $.post(ER.ajax, {
        action: 'er_save_checklist',
        nonce: ER.nonce,
        item_key: key,
        completado: done ? 1 : 0
    });

    erUpdateProgress();
};

function erUpdateProgress() {
    var total = document.querySelectorAll('.er-check-item').length;
    var done  = document.querySelectorAll('.er-checkbox.er-checked').length;
    var pct   = total ? Math.round(done / total * 100) : 0;

    var pLabel = document.getElementById('er-pct-label');
    var pBar   = document.getElementById('er-pbar-fill');
    var pCount = document.getElementById('er-count-label');
    if (pLabel) pLabel.textContent = pct + '%';
    if (pBar)   pBar.style.width = pct + '%';
    if (pCount) pCount.textContent = done + '/' + total;
}

// ── Options ──
window.erSaveOption = function(key, value) {
    $.post(ER.ajax, {
        action: 'er_save_option',
        nonce: ER.nonce,
        option_key: key,
        option_value: value
    }, function(res) {
        if (res.success) {
            var badge = document.querySelector('.er-metric-val[data-option="' + key + '"]');
            if (badge) badge.textContent = value;
            erFlash('Guardado ✓');
        }
    });
};

function erFlash(msg) {
    var el = document.createElement('div');
    el.textContent = msg;
    el.style.cssText = 'position:fixed;top:32px;right:24px;background:#43a047;color:#fff;padding:8px 16px;border-radius:20px;font-size:12px;z-index:99999;font-family:sans-serif';
    document.body.appendChild(el);
    setTimeout(function(){ el.remove(); }, 2000);
}

// ── Categories ──
window.erCreateCategories = function() {
    $.post(ER.ajax, {
        action: 'er_create_categories',
        nonce: ER.nonce
    }, function(res) {
        var msg = document.getElementById('er-cat-msg');
        if (msg) msg.textContent = res.data.message || 'Categorías creadas.';
    });
};

// ── Promesas ──
window.erSavePromesa = function() {
    var id = document.getElementById('er-form-id').value;
    $.post(ER.ajax, {
        action: 'er_save_promesa',
        nonce: ER.nonce,
        id: id,
        codigo: document.getElementById('er-form-codigo').value,
        quien: document.getElementById('er-form-quien').value,
        fecha: document.getElementById('er-form-fecha').value,
        promesa: document.getElementById('er-form-promesa').value,
        plataforma: document.getElementById('er-form-plataforma').value,
        seg_30: document.getElementById('er-form-seg30').value,
        seg_90: document.getElementById('er-form-seg90').value,
        estado: document.getElementById('er-form-estado').value,
    }, function(res) {
        if (res.success) {
            erCloseModal('er-modal-promesa');
            location.reload();
        }
    });
};

window.erDeletePromesa = function(id) {
    if (!confirm('¿Eliminar esta promesa?')) return;
    $.post(ER.ajax, {
        action: 'er_delete_promesa',
        nonce: ER.nonce,
        id: id
    }, function(res) {
        if (res.success) location.reload();
    });
};

window.erEditPromesa = function(id) {
    var p = (typeof erPromesasData !== 'undefined') ? erPromesasData.find(function(x){ return x.id == id; }) : null;
    if (!p) return;
    document.getElementById('er-modal-title').textContent = 'Editar promesa';
    document.getElementById('er-form-id').value = p.id;
    document.getElementById('er-form-codigo').value = p.codigo;
    document.getElementById('er-form-quien').value = p.quien;
    document.getElementById('er-form-fecha').value = p.fecha;
    document.getElementById('er-form-promesa').value = p.promesa;
    document.getElementById('er-form-plataforma').value = p.plataforma;
    document.getElementById('er-form-seg30').value = p.seg_30 || '';
    document.getElementById('er-form-seg90').value = p.seg_90 || '';
    document.getElementById('er-form-estado').value = p.estado;
    erOpenModal('er-modal-promesa');
};

window.erLoadEjemplos = function() {
    var ejemplos = [
        { codigo:'PROM-001', quien:'Intendente Lattanzi', fecha:'2025-10-15', promesa:'"En 60 días comenzamos las obras de pavimentación en Barrio Norte."', plataforma:'Facebook oficial', seg_30:'Sin novedades al mes', seg_90:'', estado:'pendiente' },
        { codigo:'PROM-002', quien:'Municipalidad de Rufino', fecha:'2025-11-03', promesa:'"Incorporamos 2 móviles policiales a partir de la semana que viene."', plataforma:'Conferencia de prensa', seg_30:'Se verificó 1 móvil', seg_90:'', estado:'proceso' },
        { codigo:'PROM-003', quien:'Gobierno provincial', fecha:'2025-08-22', promesa:'"Esta semana inicia la cuadrilla de bacheo en el tramo Rufino-Carreras de la RN 33."', plataforma:'Nota en medio local', seg_30:'No se iniciaron trabajos', seg_90:'Sigue sin intervención', estado:'incumplida' },
    ];
    var pending = ejemplos.length;
    ejemplos.forEach(function(e) {
        $.post(ER.ajax, {
            action: 'er_save_promesa',
            nonce: ER.nonce,
            codigo: e.codigo, quien: e.quien, fecha: e.fecha,
            promesa: e.promesa, plataforma: e.plataforma,
            seg_30: e.seg_30, seg_90: e.seg_90, estado: e.estado,
        }, function() {
            pending--;
            if (pending === 0) location.reload();
        });
    });
};

window.erExportCSV = function() {
    if (typeof erPromesasData === 'undefined' || !erPromesasData.length) {
        alert('No hay promesas para exportar.');
        return;
    }
    var rows = [['Código','Fecha','Quién','Promesa','Plataforma','Seg.30d','Seg.90d','Estado']];
    erPromesasData.forEach(function(p) {
        rows.push([p.codigo, p.fecha, p.quien, '"' + (p.promesa||'').replace(/"/g,'""') + '"', p.plataforma, p.seg_30||'', p.seg_90||'', p.estado]);
    });
    var csv = rows.map(function(r){ return r.join(','); }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'promesas-el-rufino.csv';
    a.click();
};

// ── Context ──
window.erSaveContext = function() {
    var nombre = document.getElementById('er-ctx-nombre').value.trim();
    var cont   = document.getElementById('er-ctx-contenido').value.trim();
    if (!nombre || !cont) { alert('Completá nombre y contenido.'); return; }
    $.post(ER.ajax, {
        action: 'er_save_context',
        nonce: ER.nonce,
        nombre: nombre,
        contenido: cont
    }, function(res) {
        if (res.success) { erFlash('Contexto guardado y activado ✓'); location.reload(); }
    });
};

window.erSetActiveContext = function(id) {
    $.post(ER.ajax, {
        action: 'er_set_active_context',
        nonce: ER.nonce,
        id: id
    }, function(res) {
        if (res.success) location.reload();
    });
};

window.erCopyContext = function(id) {
    var ctx = (typeof erContextosData !== 'undefined') ? erContextosData.find(function(c){ return c.id == id; }) : null;
    if (!ctx) return;
    erCopyText(ctx.contenido);
    erFlash('Contexto copiado ✓');
};

window.erViewContext = function(id) {
    var ctx = (typeof erContextosData !== 'undefined') ? erContextosData.find(function(c){ return c.id == id; }) : null;
    if (!ctx) return;
    document.getElementById('er-ctx-view-title').textContent = ctx.nombre;
    document.getElementById('er-ctx-view-content').textContent = ctx.contenido;
    erOpenModal('er-modal-ctx-view');
};

window.erCopyFromViewer = function() {
    var content = document.getElementById('er-ctx-view-content').textContent;
    erCopyText(content);
    erFlash('Copiado al portapapeles ✓');
};

// ── Drive structure ──
window.erCopyDriveStructure = function() {
    var txt = `EL RUFINO — Estructura Google Drive\n${'='.repeat(36)}\n📁 01_SITIO_WEB\n   ├── 01a_Tema-y-plugins\n   ├── 01b_Credenciales\n   ├── 01c_Backups\n   ├── 01d_Capturas-sitio\n   └── 01e_Documentacion-tecnica\n\n📁 02_CONTENIDOS\n   ├── 02a_P01-Rufino-Real\n   ├── 02b_P02-El-campo-habla\n   ├── 02c_P03-Barrio-a-barrio\n   ├── 02d_P04-Generacion-Rufino\n   ├── 02e_P05-Poder-y-gestion\n   ├── 02f_P06-Rufino-en-datos\n   ├── 02g_Banco-de-notas\n   ├── 02h_Publicados\n   └── 02i_Borradores\n\n📁 03_IMAGENES\n📁 04_REDES_SOCIALES\n📁 05_SEGUIMIENTO_PROMESAS\n📁 06_COMERCIAL\n📁 07_EDITORIAL\n📁 08_DATOS_LOCALES\n📁 09_MULTIMEDIA`;
    erCopyText(txt);
    erFlash('Estructura copiada ✓');
};

// ── Utility ──
function erCopyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text);
    } else {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
    }
}

})(jQuery);


// ── Flash mejorado con color ──
// Sobreescribir la función para soportar color
window.erFlash = function(msg, color) {
    var bg = color === 'green' ? '#16a34a' : (color === 'red' ? '#dc2626' : '#1e40af');
    var el = document.createElement('div');
    el.textContent = msg;
    el.style.cssText = 'position:fixed;top:36px;right:20px;background:' + bg + ';color:#fff;padding:10px 18px;border-radius:20px;font-size:13px;font-weight:600;z-index:99999;font-family:sans-serif;box-shadow:0 4px 12px rgba(0,0,0,.2);transition:opacity .3s';
    document.body.appendChild(el);
    setTimeout(function(){ el.style.opacity='0'; }, 2500);
    setTimeout(function(){ el.remove(); }, 2900);
};

// ── Accordion toggle (inline display, sin depender del CSS del admin WP) ──
window.erToggleAcc = function(key) {
    var wrap = document.getElementById('er-acc-' + key);
    if (!wrap) return;
    var body    = wrap.querySelector('.er-acc-body');
    var chevron = wrap.querySelector('.er-acc-chevron');
    if (!body) return;
    var isOpen  = (body.style.display === 'block');
    if (isOpen) {
        body.style.display = 'none';
        wrap.classList.remove('er-acc-open');
        if (chevron) chevron.style.transform = '';
    } else {
        body.style.display = 'block';
        wrap.classList.add('er-acc-open');
        if (chevron) chevron.style.transform = 'rotate(180deg)';
    }
};

// ── Drive URL ──
window.erSaveDriveUrl = function() {
    var url = document.getElementById('er-drive-url-input').value.trim();
    jQuery.post(ER.ajax, {
        action: 'er_save_drive_url',
        nonce: ER.nonce,
        url: url
    }, function(res) {
        if (res.success) { erFlash('Link de Drive guardado ✓', 'green'); setTimeout(function(){ location.reload(); }, 1200); }
    });
};
