<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_fase0() {
    global $wpdb;

    $cl_rows = $wpdb->get_results("SELECT item_key, completado FROM {$wpdb->prefix}er_checklist");
    $cl_state = [];
    foreach($cl_rows as $r) $cl_state[$r->item_key] = (bool)$r->completado;

    $contexto_activo = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}er_contexto WHERE activo=1");
    $ctx_content = $contexto_activo ? $contexto_activo->contenido : '';

    $sections = [
        'A' => [
            'title'       => 'Identidad y tema',
            'agent_id'    => 'configurador_tema',
            'agent_label' => 'Agente 3 — Instrucciones de configuración visual y Customizer',
            'agent_hint'  => 'No necesitás completar nada extra. El agente genera el CSS + los valores exactos del Customizer.',
            'items' => [
                'id_logo'        => ['Logo instalado y visible en el header', 'Diseño'],
                'id_colores'     => ['Paleta configurada: rojo #c0271b + negro + blanco + crema', 'Diseño'],
                'id_tipografias' => ['Tipografías: serif para títulos, sans para cuerpo', 'Diseño'],
                'id_tema'        => ['Tema activo: limpio, rápido, responsive, compatible con plugins', 'Tema'],
                'id_header'      => ['Header con masthead rojo y nombre del medio', 'Diseño'],
                'id_footer'      => ['Footer con info del medio y links configurado', 'Diseño'],
            ],
        ],
        'B' => [
            'title'       => 'Plugins esenciales (en orden)',
            'agent_id'    => 'configurador_yoast',
            'agent_label' => 'Agente 1 — Configuración completa de Yoast SEO o Rank Math',
            'agent_hint'  => 'Usá este agente DESPUÉS de instalar el plugin SEO. Entrega los valores exactos de cada campo.',
            'items' => [
                'pl_backup'    => ['UpdraftPlus — instalar PRIMERO, backup automático diario', 'Plugin'],
                'pl_seo'       => ['Yoast SEO o Rank Math — instalar y configurar con Agente 1', 'Plugin'],
                'pl_cache'     => ['LiteSpeed Cache (recomendado para Hostinger) o WP Rocket', 'Plugin'],
                'pl_seguridad' => ['Seguridad: Wordfence o iThemes Security', 'Plugin'],
                'pl_contacto'  => ['Formulario de contacto: Contact Form 7 o WPForms', 'Plugin'],
                'pl_imagenes'  => ['Optimización de imágenes: Smush o ShortPixel', 'Plugin'],
                'pl_analytics' => ['Google Analytics 4 + Google Search Console conectados', 'Analytics'],
                'pl_antispam'  => ['Akismet anti-spam activado', 'Plugin'],
                'pl_ticker'    => ['Breaking news ticker — barra superior', 'Plugin'],
            ],
        ],
        'C' => [
            'title'       => 'Estructura editorial',
            'agent_id'    => 'generador_categorias',
            'agent_label' => 'Agente 2 — Categorías con descripciones + 3 borradores de notas por sección',
            'agent_hint'  => 'No necesitás completar nada extra. También podés usar el botón para crear las categorías automáticamente.',
            'action_btn'  => ['⚡ Crear categorías automáticamente', 'erCreateCategories()', 'er-cat-msg'],
            'items' => [
                'cat_crear'    => ['Categorías editoriales creadas (o usar botón automático)', 'Infra'],
                'cat_menu'     => ['Menú de navegación configurado con todas las secciones', 'Infra'],
                'cat_home'     => ['Inicio: ticker, destacado principal, grilla pilares, bloque WA', 'Diseño'],
                'cat_sobre'    => ['Página "Sobre El Rufino" con identidad del medio', 'Infra'],
                'cat_contacto' => ['Página de contacto con formulario activo', 'Infra'],
            ],
        ],
        'D' => [
            'title'    => 'Infraestructura técnica',
            'agent_id' => null,
            'items' => [
                'tec_ssl'       => ['SSL / HTTPS activo y verificado', 'Infra'],
                'tec_sitemap'   => ['Sitemap XML generado y enviado a Search Console', 'SEO'],
                'tec_robots'    => ['robots.txt configurado correctamente', 'SEO'],
                'tec_velocidad' => ['Velocidad de carga menor a 3 segundos (verificar en PageSpeed)', 'Perf'],
                'tec_mobile'    => ['Visualización mobile verificada en Android e iOS', 'Perf'],
            ],
        ],
        'E' => [
            'title'    => 'Dominios',
            'agent_id' => null,
            'items' => [
                'dom_ar'       => ['elrufino.ar disponible en nic.ar', 'Dominio'],
                'dom_ar_reg'   => ['elrufino.ar registrado como dominio principal', 'Dominio'],
                'dom_comar'    => ['elrufino.com.ar registrado (defensivo, redirección 301)', 'Dominio'],
                'dom_redirect' => ['Redirección configurada desde infoconectados.com.ar', 'Dominio'],
            ],
        ],
        'F' => [
            'title'    => 'Redes y canales',
            'agent_id' => 'configurador_redes',
            'agent_label' => 'Agente 9 — Bio unificada para todas las plataformas',
            'agent_hint'  => 'No necesitás completar nada extra. Entrega el texto exacto de bio, handles y links para cada red.',
            'items' => [
                'red_fb'      => ['Facebook: página @elrufino creada y configurada', 'Social'],
                'red_ig'      => ['Instagram: @elrufino creada y configurada', 'Social'],
                'red_tk'      => ['TikTok: @elrufino creada y configurada', 'Social'],
                'red_wa'      => ['Canal WhatsApp Broadcast con descripción y horario 7:30 AM', 'WA'],
                'red_bio'     => ['Foto de perfil y bio unificadas en todas las plataformas', 'Social'],
                'red_previo'  => ['Post "algo viene" publicado en redes sin revelar qué', 'Social'],
                'red_wa_lista'=> ['Lista pre-suscriptores WhatsApp iniciada (mínimo 20 contactos)', 'WA'],
            ],
        ],
        'G' => [
            'title'       => 'Contenidos pre-lanzamiento',
            'agent_id'    => 'planificador_semanal',
            'agent_label' => 'Agente 4 — Calendario editorial completo para la semana de lanzamiento',
            'agent_hint'  => 'No necesitás completar nada extra. Generá el primer banco de contenidos antes de publicar.',
            'items' => [
                'cont_plantillas' => ['Plantillas visuales: noticia, infografía, Reel, story IG, resumen WA', 'Diseño'],
                'cont_wa_tpl'     => ['Plantilla resumen matutino WhatsApp definida y testeada', 'WA'],
                'cont_tablero'    => ['Tablero editorial: Trello / Notion / Google Sheets', 'Herr.'],
                'cont_protocolo'  => ['Protocolo de publicación sensible redactado', 'Editorial'],
                'cont_banco'      => ['Banco de 10 contenidos listos antes del lanzamiento público', 'Contenido'],
            ],
        ],
    ];

    $total = 0; $done = 0;
    foreach($sections as $sec) {
        foreach($sec['items'] as $key => $item) {
            $total++;
            if(!empty($cl_state[$key])) $done++;
        }
    }
    $pct = $total ? round($done/$total*100) : 0;

    $tag_colors = [
        'Plugin'=>'blue','Diseño'=>'purple','Infra'=>'gray','SEO'=>'green',
        'Analytics'=>'teal','Perf'=>'orange','Dominio'=>'amber','Social'=>'pink',
        'WA'=>'green','Herr.'=>'gray','Editorial'=>'red','Contenido'=>'teal','Tema'=>'purple',
    ];

    $agents_raw = er_get_agent_definitions();
    $agents_map = [];
    foreach($agents_raw as $a) $agents_map[$a['id']] = $a;
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-fase-0'); ?></div>
        <div class="er-body">

            <!-- Barra de progreso global -->
            <div class="er-f0-progress-bar">
                <div class="er-f0-pb-top">
                    <span class="er-f0-pb-label">Fase 0 — Progreso</span>
                    <span class="er-f0-pb-pct" id="er-pct-label"><?php echo $pct; ?>%</span>
                    <span class="er-f0-pb-count" id="er-count-label"><?php echo $done; ?>/<?php echo $total; ?> completadas</span>
                </div>
                <div class="er-pbar er-pbar-lg">
                    <div class="er-pfill" id="er-pbar-fill" style="width:<?php echo $pct; ?>%"></div>
                </div>
            </div>

            <?php if(!$contexto_activo): ?>
            <div class="er-notice er-notice-warn">
                <strong>Sin contexto activo.</strong> Los botones de agente copiarán el prompt sin el contexto del medio.
                <a href="<?php echo admin_url('admin.php?page=el-rufino-contexto'); ?>">Subir contexto →</a>
            </div>
            <?php endif; ?>

            <div id="er-checklist-wrap" data-total="<?php echo $total; ?>">
            <?php foreach($sections as $sec_key => $sec):
                $sec_done = 0; $sec_total = count($sec['items']);
                foreach($sec['items'] as $key => $item) if(!empty($cl_state[$key])) $sec_done++;
                $is_complete = ($sec_done === $sec_total && $sec_total > 0);
                $has_agent   = !empty($sec['agent_id']) && isset($agents_map[$sec['agent_id']]);
            ?>
            <div class="er-accordion" id="er-acc-<?php echo $sec_key; ?>">

                <!-- Header del acordeón -->
                <div class="er-acc-header" onclick="erToggleAcc('<?php echo $sec_key; ?>')">
                    <span class="er-acc-letter <?php echo $is_complete ? 'er-acc-done' : ''; ?>"><?php echo $sec_key; ?></span>
                    <span class="er-acc-title"><?php echo esc_html($sec['title']); ?></span>
                    <?php if($has_agent): ?>
                    <span class="er-acc-has-agent">IA</span>
                    <?php endif; ?>
                    <span class="er-acc-count <?php echo $is_complete ? 'er-acc-count-done' : ($sec_done > 0 ? 'er-acc-count-partial' : ''); ?>">
                        <?php echo $sec_done; ?>/<?php echo $sec_total; ?>
                    </span>
                    <span class="er-acc-chevron">▼</span>
                </div>

                <!-- Cuerpo del acordeón (CERRADO por defecto — inline display:none garantizado) -->
                <div class="er-acc-body" style="display:none">

                    <?php if($has_agent):
                        $agent = $agents_map[$sec['agent_id']]; ?>
                    <div class="er-acc-agent-row">
                        <span class="er-acc-agent-icon"><?php echo $agent['icon']; ?></span>
                        <div class="er-acc-agent-info">
                            <strong><?php echo esc_html($sec['agent_label'] ?? $agent['nombre']); ?></strong>
                            <span><?php echo esc_html($sec['agent_hint'] ?? $agent['descripcion']); ?></span>
                        </div>
                        <button class="er-btn er-btn-primary er-btn-sm er-copy-prompt-btn"
                                onclick="erF0CopyAgent('<?php echo esc_js($agent['id']); ?>', this)">
                            Copiar prompt
                        </button>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($sec['action_btn'])): [$btn_label, $btn_onclick, $msg_id] = $sec['action_btn']; ?>
                    <div class="er-acc-action-row">
                        <button class="er-btn er-btn-secondary er-btn-sm" onclick="<?php echo esc_js($btn_onclick); ?>">
                            <?php echo esc_html($btn_label); ?>
                        </button>
                        <?php if($msg_id): ?><span id="<?php echo esc_attr($msg_id); ?>" class="er-acc-action-msg"></span><?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php foreach($sec['items'] as $key => $item):
                        $is_done = !empty($cl_state[$key]);
                        $color   = $tag_colors[$item[1]] ?? 'gray';
                    ?>
                    <div class="er-check-item <?php echo $is_done ? 'er-done' : ''; ?>"
                         data-key="<?php echo esc_attr($key); ?>"
                         onclick="erToggleCheck(this)">
                        <div class="er-checkbox <?php echo $is_done ? 'er-checked' : ''; ?>">
                            <?php if($is_done): ?>✓<?php endif; ?>
                        </div>
                        <span class="er-check-text"><?php echo esc_html($item[0]); ?></span>
                        <span class="er-check-tag er-tag-color-<?php echo $color; ?>"><?php echo esc_html($item[1]); ?></span>
                    </div>
                    <?php endforeach; ?>

                </div>
            </div>
            <?php endforeach; ?>
            </div>

        </div>
    </div>

    <script>
    var erF0Context = <?php echo json_encode($ctx_content); ?>;
    var erF0Agents  = <?php echo json_encode($agents_map); ?>;

    /* Acordeón — usa display directo en el DOM, no clases CSS, 
       para evitar que el CSS del admin de WP lo sobreescriba */
    window.erToggleAcc = function(key) {
        var wrap = document.getElementById('er-acc-' + key);
        if (!wrap) return;
        var body    = wrap.querySelector('.er-acc-body');
        var chevron = wrap.querySelector('.er-acc-chevron');
        var isOpen  = (body.style.display !== 'none' && body.style.display !== '');
        if (isOpen) {
            body.style.display = 'none';
            wrap.classList.remove('er-acc-open');
            if (chevron) chevron.style.transform = '';
        } else {
            body.style.display = 'block';
            wrap.classList.add('er-acc-open');
            if (chevron) chevron.style.transform = 'rotate(180deg)';
        }
    };

    /* Copiar prompt del agente directamente al portapapeles */
    window.erF0CopyAgent = function(agentId, btn) {
        var agent = erF0Agents[agentId];
        if (!agent) return;
        var ctx = erF0Context || '[SIN CONTEXTO — subir contexto en la pestaña Contexto]';
        var prompt = agent.prompt_template.replace('{{CONTEXTO}}', ctx);

        // Copiar al portapapeles
        var copied = false;
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(prompt).then(function(){});
            copied = true;
        } else {
            var ta = document.createElement('textarea');
            ta.value = prompt;
            ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
            document.body.appendChild(ta);
            ta.select();
            try { document.execCommand('copy'); copied = true; } catch(e) {}
            ta.remove();
        }

        if (copied) {
            var orig = btn.textContent;
            btn.textContent = '✓ Copiado';
            btn.style.background = '#16a34a';
            // Flash visible en la parte superior
            erFlash('Prompt copiado — pegalo en Claude o GPT-4 y enviá sin modificar', 'green');
            setTimeout(function(){ btn.textContent = orig; btn.style.background = ''; }, 3500);
        }
    };
    </script>
    <?php
}
