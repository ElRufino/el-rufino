<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_agentes() {
    global $wpdb;
    $contexto_activo = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}er_contexto WHERE activo=1");
    $agents = er_get_agent_definitions();

    // Group by category
    $groups = [
        'fase0'     => ['label'=>'Fase 0 — Construcción técnica', 'color'=>'blue',   'agents'=>[]],
        'editorial' => ['label'=>'Editorial — Contenido',          'color'=>'red',    'agents'=>[]],
        'redes'     => ['label'=>'Redes y distribución',           'color'=>'green',  'agents'=>[]],
    ];
    foreach($agents as $a) {
        $g = $a['group'] ?? 'editorial';
        $groups[$g]['agents'][] = $a;
    }
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-agentes-ia'); ?></div>
        <div class="er-body">

            <div class="er-agents-intro">
                <div class="er-agents-intro-text">
                    <strong>Cómo usar los agentes</strong>
                    <span>Hacé clic en "Copiar prompt" → pegalo en Claude o GPT-4 → el agente entrega el resultado → traelo de vuelta y aplicalo.</span>
                </div>
                <?php if(!$contexto_activo): ?>
                <a href="<?php echo admin_url('admin.php?page=el-rufino-contexto'); ?>" class="er-btn er-btn-secondary er-btn-sm">
                    ⚠ Subir contexto primero →
                </a>
                <?php else: ?>
                <span class="er-agents-ctx-ok">✓ Contexto activo: <?php echo esc_html($contexto_activo->nombre); ?></span>
                <?php endif; ?>
            </div>

            <?php foreach($groups as $gkey => $group):
                if(empty($group['agents'])) continue; ?>
            <div class="er-section-title"><?php echo esc_html($group['label']); ?></div>
            <div class="er-agents-grid">
            <?php foreach($group['agents'] as $agent): ?>
                <div class="er-agent-card">
                    <div class="er-agent-head">
                        <span class="er-agent-icon"><?php echo $agent['icon']; ?></span>
                        <div class="er-agent-meta">
                            <span class="er-agent-name"><?php echo esc_html($agent['nombre']); ?></span>
                            <span class="er-agent-role"><?php echo esc_html($agent['rol']); ?></span>
                        </div>
                        <?php if(!empty($agent['badge'])): ?>
                        <span class="er-agent-badge er-agent-badge-<?php echo $agent['badge_color'] ?? 'gray'; ?>">
                            <?php echo esc_html($agent['badge']); ?>
                        </span>
                        <?php endif; ?>
                    </div>

                    <p class="er-agent-desc"><?php echo esc_html($agent['descripcion']); ?></p>

                    <div class="er-agent-delivers">
                        <span class="er-agent-delivers-label">Entrega:</span>
                        <?php echo esc_html($agent['entrega']); ?>
                    </div>

                    <?php if(!empty($agent['completar'])): ?>
                    <div class="er-agent-completar">
                        <span class="er-agent-completar-label">Antes de pegar, completar:</span>
                        <?php echo esc_html($agent['completar']); ?>
                    </div>
                    <?php else: ?>
                    <div class="er-agent-completar er-agent-completar-ok">
                        <span>✓ Sin campos extra — prompt completo</span>
                    </div>
                    <?php endif; ?>

                    <button class="er-btn er-btn-primary er-btn-full er-copy-prompt-btn"
                            onclick="erCopyAgentPrompt('<?php echo esc_js($agent['id']); ?>', this)">
                        Copiar prompt →
                    </button>
                </div>
            <?php endforeach; ?>
            </div>
            <?php endforeach; ?>

            <!-- Modal para prompt largo -->
            <div class="er-modal-overlay" id="er-modal-prompt" style="display:none">
                <div class="er-modal er-modal-large">
                    <h3 id="er-prompt-title"></h3>
                    <p style="font-size:12px;color:var(--er-text2);margin-bottom:8px">Copiá este prompt completo y pegalo en Claude o GPT-4:</p>
                    <textarea id="er-prompt-content" rows="16" style="width:100%;font-size:12px;font-family:monospace;padding:10px;border:1px solid var(--er-border);border-radius:6px;background:var(--er-bg2);color:var(--er-text);resize:vertical"></textarea>
                    <div class="er-modal-footer">
                        <button class="er-btn er-btn-secondary" onclick="erCloseModal('er-modal-prompt')">Cerrar</button>
                        <button class="er-btn er-btn-primary" onclick="erCopyFromModal()">✓ Copiar al portapapeles</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    var erContextoActivo = <?php echo json_encode($contexto_activo ? $contexto_activo->contenido : ''); ?>;
    var erAgents = <?php echo json_encode(array_values($agents)); ?>;

    window.erCopyAgentPrompt = function(agentId, btn) {
        var agent = erAgents.find(function(a){ return a.id === agentId; });
        if (!agent) return;
        var ctx = erContextoActivo || '[SIN CONTEXTO — subir contexto en la pestaña Contexto]';
        var prompt = agent.prompt_template.replace('{{CONTEXTO}}', ctx);
        document.getElementById('er-prompt-title').textContent = agent.nombre;
        document.getElementById('er-prompt-content').value = prompt;
        erOpenModal('er-modal-prompt');
    };

    window.erCopyFromModal = function() {
        var ta = document.getElementById('er-prompt-content');
        ta.select();
        document.execCommand('copy');
        var btn = document.querySelector('#er-modal-prompt .er-btn-primary');
        var orig = btn.textContent;
        btn.textContent = '✓ Copiado';
        btn.style.background = '#16a34a';
        erFlash('Prompt copiado — pegalo en Claude o GPT-4', 'green');
        setTimeout(function(){ btn.textContent = orig; btn.style.background = ''; }, 3000);
    };
    </script>
    <?php
}

function er_get_agent_definitions() {
    return [
        // ── FASE 0 ──
        [
            'id'    => 'configurador_tema',
            'group' => 'fase0',
            'icon'  => '🎨',
            'badge' => 'Fase 0',
            'badge_color' => 'blue',
            'nombre'      => 'Configurador de tema visual',
            'rol'         => 'Desarrollador WordPress especializado en medios',
            'descripcion' => 'Genera el tema hijo completo para Astra (o el padre que uses): style.css, functions.php, CSS editorial e instrucciones paso a paso del Customizer.',
            'entrega'     => 'Código listo para instalar + instrucciones exactas del Customizer.',
            'completar'   => null,
            'prompt_template' => "Sos un desarrollador WordPress especializado en medios de comunicación digitales.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nIdentidad visual:\n- Color principal: #c0271b (rojo)\n- Colores de soporte: negro (#1a1a1a), blanco (#ffffff), crema (#f5f0e8)\n- Tipografía títulos: Playfair Display (serif)\n- Tipografía cuerpo: Source Sans 3 (sans-serif)\n- Header: masthead rojo con nombre en blanco\n- Tema padre: Astra (o indicar el que corresponda)\n\nEntregá:\n1. style.css del tema hijo completo con cabecera WordPress válida\n2. functions.php con: enqueue del padre + tipografías Google Fonts + menús + tamaños de imagen\n3. CSS editorial para: header rojo, ticker, grilla de artículos, bloque WhatsApp, footer, cards, responsive mobile-first\n4. Instrucciones exactas del Customizer (Apariencia > Personalizar): valores a ingresar en cada sección\n\nEl sitio tiene 70%+ de tráfico mobile. Priorizar velocidad y legibilidad. Objetivo de carga: menos de 3 segundos.",
        ],
        [
            'id'    => 'configurador_yoast',
            'group' => 'fase0',
            'icon'  => '⚙',
            'badge' => 'Fase 0',
            'badge_color' => 'blue',
            'nombre'      => 'Configurador SEO',
            'rol'         => 'Especialista en Yoast SEO / Rank Math para medios',
            'descripcion' => 'Genera la configuración completa y óptima del plugin SEO activo: título, meta, Open Graph, Schema, indexación, sitemap y keywords semilla por sección editorial.',
            'entrega'     => 'Lista de valores exactos para copiar en cada campo del plugin SEO.',
            'completar'   => null,
            'prompt_template' => "Sos un experto en SEO técnico y configuración de WordPress para medios digitales latinoamericanos.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nEntregá la configuración completa para Yoast SEO (o Rank Math):\n\n1. Título del sitio y descripción meta\n2. Open Graph para Facebook e Instagram\n3. Schema.org: NewsMediaOrganization, nombre, URL, logo\n4. Twitter/X card settings\n5. Qué indexar y qué no\n6. Estructura de breadcrumbs\n7. Configuración del sitemap XML\n8. Redirecciones recomendadas\n9. Keywords semilla por sección editorial\n\nSé concreto: valores exactos para copiar en cada campo, no explicaciones generales.",
        ],
        [
            'id'    => 'generador_categorias',
            'group' => 'fase0',
            'icon'  => '🗂',
            'badge' => 'Fase 0',
            'badge_color' => 'blue',
            'nombre'      => 'Generador de categorías y entradas',
            'rol'         => 'Arquitecto de contenido editorial',
            'descripcion' => 'Genera la arquitectura editorial completa: categorías con slugs y descripciones, 3 borradores de notas por sección y 5 entradas evergreen para el banco de contenidos.',
            'entrega'     => 'Categorías con slugs + 3 borradores por sección + 5 notas evergreen.',
            'completar'   => null,
            'prompt_template' => "Sos un editor digital especializado en medios locales argentinos.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nEntregá:\n\n1. CATEGORÍAS (todas las definidas en el contexto más las que sugieran agregar):\n   - Nombre · Slug · Descripción (2-3 oraciones) · Categoría padre si corresponde\n\n2. ENTRADAS BASE (3 por categoría):\n   - Título (regla de 2 capas: lo que pasó + lo que significa)\n   - Bajada (2-3 oraciones)\n   - Esquema del contenido (bullets)\n   - Tags sugeridos\n   - Por qué esta nota es diferente a lo que ya existe en Rufino\n\n3. ENTRADAS EVERGREEN (5 notas sin fecha de vencimiento):\n   - Que funcionen como puertas de entrada al medio para nuevos lectores\n\nTono: directo, verificado, humano. Sin segunda capa = no se incluye.",
        ],
        [
            'id'    => 'configurador_redes',
            'group' => 'fase0',
            'icon'  => '📱',
            'badge' => 'Fase 0',
            'badge_color' => 'blue',
            'nombre'      => 'Bio unificada para redes',
            'rol'         => 'Estratega de identidad digital',
            'descripcion' => 'Genera la bio exacta para cada plataforma (FB, IG, TikTok, WhatsApp), los handles recomendados, el texto de presentación del canal WA y los links a usar en cada red.',
            'entrega'     => 'Texto de bio listo para copiar en cada plataforma + descripción del canal WhatsApp.',
            'completar'   => null,
            'prompt_template' => "Sos especialista en identidad digital para medios de comunicación locales.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nEntregá:\n\n1. FACEBOOK — Página:\n   - Nombre exacto de la página\n   - Handle recomendado (@)\n   - Descripción corta (255 caracteres)\n   - Categoría de página recomendada\n   - Texto del \"About\" (historia del medio)\n\n2. INSTAGRAM:\n   - Handle (@)\n   - Bio (150 caracteres, incluyendo emojis estratégicos)\n   - Link en bio: qué usar y cómo\n\n3. TIKTOK:\n   - Handle (@)\n   - Bio (80 caracteres)\n   - Enlace de perfil\n\n4. WHATSAPP CANAL BROADCAST:\n   - Nombre exacto del canal\n   - Descripción del canal (hasta 139 caracteres)\n   - Mensaje de bienvenida al suscribirse\n\n5. Checklist de verificación: qué revisar antes de publicar el primer post en cada red\n\nEl objetivo es que la identidad sea coherente, reconocible y nativa en cada plataforma.",
        ],

        // ── EDITORIAL ──
        [
            'id'    => 'planificador_semanal',
            'group' => 'editorial',
            'icon'  => '📅',
            'nombre'      => 'Planificador editorial semanal',
            'rol'         => 'Editor de planificación de contenidos',
            'descripcion' => 'Genera el calendario editorial para la próxima semana: 7 días, 3–5 piezas por día, con títulos en dos capas, plataforma, formato, audiencia y fuentes sugeridas.',
            'entrega'     => 'Tabla de 7 días lista para copiar al tablero editorial.',
            'completar'   => null,
            'prompt_template' => "Sos el editor de planificación de El Rufino.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nGenerá el calendario editorial para la próxima semana.\n\nPor cada pieza:\n- Día y fecha · Plataforma · Pilar (P01–P06)\n- Título completo con la regla de 2 capas\n- Capa 1: el hecho · Capa 2: lo que significa\n- Formato: nota larga / hilo FB / Reel / TikTok / infografía / resumen WA\n- Audiencia target\n- Fuentes sugeridas\n- Tiempo de producción estimado\n\nReglas:\n- Lunes: P01 + P06 · Martes: P02 · Miércoles: TikTok · Jueves: P05 · Viernes: P03\n- Mínimo 1 nota larga por semana\n- Resumen WA todos los días a las 7:30 AM\n- Sin segunda capa = no va al calendario",
        ],
        [
            'id'    => 'redactor_nota',
            'group' => 'editorial',
            'icon'  => '✍',
            'nombre'      => 'Redactor de nota periodística',
            'rol'         => 'Periodista de El Rufino',
            'descripcion' => 'Redacta una nota completa en el tono editorial del medio. Aplica las dos capas obligatorias, estructura título–bajada–cuerpo–cierre, y agrega tags y categoría.',
            'entrega'     => 'Nota completa (600–1000 palabras) lista para publicar.',
            'completar'   => 'El hecho concreto: qué pasó, quién, cuándo, dónde y qué datos tenés.',
            'prompt_template' => "Sos el periodista principal de El Rufino.\n\nContexto del medio y tono editorial:\n---\n{{CONTEXTO}}\n---\n\nTEMA A CUBRIR:\n[COMPLETAR: describí el hecho concreto, quién, cuándo, dónde y cualquier dato o fuente disponible]\n\nLa nota debe:\n1. Aplicar la REGLA DE LAS DOS CAPAS:\n   - Capa 1: Lo que pasó (el hecho verificado)\n   - Capa 2: Lo que significa / el contexto que falta\n\n2. Estructura: Título → Bajada (2-3 oraciones) → Cuerpo (600-1000 palabras) → Cierre\n\n3. Tono: directo sin ser agresivo / verificado / local sin ser localista / humano sin ser amarillista\n\n4. NUNCA: burocrático · sensacionalista · comunicado sin contexto\n\n5. Si algo no está confirmado: \"Según...\" o \"Hasta ahora lo que se sabe es...\"\n\nAl final: tags sugeridos, categoría asignada y nota al editor sobre el seguimiento.",
        ],
        [
            'id'    => 'seguimiento_promesas',
            'group' => 'editorial',
            'icon'  => '🔍',
            'nombre'      => 'Nota de seguimiento de promesas',
            'rol'         => 'Periodista de accountability',
            'descripcion' => 'Toma el registro de promesas y genera la nota "¿Qué pasó con lo que prometieron?", el hilo de Facebook y el resumen para WhatsApp. El diferenciador más potente del medio.',
            'entrega'     => 'Nota para el sitio + hilo FB + resumen WA.',
            'completar'   => 'Las promesas del registro: código, quién las hizo, fecha y estado actual.',
            'prompt_template' => "Sos el periodista de accountability de El Rufino.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nRegistro de promesas:\n[COMPLETAR: pegá las promesas con código, quién, fecha y estado actual]\n\nRedactá:\n\n1. NOTA PRINCIPAL (600–800 palabras):\n   - Título: \"¿Qué pasó con [promesa]? [Tiempo] después, la respuesta\"\n   - Por cada promesa: qué se prometió / fecha / qué pasó realmente\n   - Protocolo: \"Según la versión oficial...\" cuando no está verificado\n   - Cierre con pregunta abierta al lector\n\n2. HILO DE FACEBOOK (5–7 posts):\n   - Post 1: hook · Posts 2–5: una promesa por post · Post final: \"¿Qué querés que sigamos?\"\n\n3. RESUMEN WHATSAPP (máx 3 líneas):\n   - Para el resumen matutino 7:30 AM\n\nTono: verificador, no opositor. Registro objetivo, no ataque.",
        ],
        [
            'id'    => 'guionista_tiktok',
            'group' => 'editorial',
            'icon'  => '🎬',
            'nombre'      => 'Guionista TikTok / Reels',
            'rol'         => 'Creador de contenido para redes sociales',
            'descripcion' => 'Genera guiones de 60–90 segundos para TikTok e Instagram Reels con hook, desarrollo y CTA. Voz auténtica rufineña, sin formalidad corporativa.',
            'entrega'     => 'Guion completo con texto a cámara, indicaciones visuales, texto en pantalla y hashtags.',
            'completar'   => 'El dato o historia local que querés contar en el video.',
            'prompt_template' => "Sos el creador de contenido de El Rufino para TikTok e Instagram Reels.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nTEMA DEL VIDEO:\n[COMPLETAR: el dato o historia local que querés contar]\n\nHOOK (0–5 seg): primera frase que detiene el scroll.\nDESARROLLO (5–70 seg): texto a cámara exacto + indicaciones entre [corchetes]\nCIERRE (70–90 seg): llamada a la acción\n\nReglas:\n- Voz auténtica, como habla un rufineño\n- Sin \"hola chicos\" ni lenguaje corporativo\n- TikTok en Rufino es territorio virgen\n- 5–7 hashtags (mezcla local + temático)\n\nEntregá también: miniatura sugerida y mejor horario de publicación.",
        ],

        // ── REDES ──
        [
            'id'    => 'redactor_wa',
            'group' => 'redes',
            'icon'  => '💬',
            'badge' => 'Prioridad',
            'badge_color' => 'green',
            'nombre'      => 'Redactor de resumen matutino WhatsApp',
            'rol'         => 'Editor de distribución — Canal WA 7:30 AM',
            'descripcion' => 'Genera el mensaje diario de WhatsApp con las 3 noticias más importantes. Formato exacto para copiar y enviar. Incluye versión corta para días con poco tiempo de producción.',
            'entrega'     => 'Mensaje WA 7:30 AM listo para copiar y enviar. Variante larga y corta.',
            'completar'   => 'Las 3 noticias del día: titular + 1 línea de contexto cada una.',
            'prompt_template' => "Sos el editor de distribución de El Rufino, a cargo del canal de WhatsApp broadcast.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nNOTICIAS DEL DÍA:\n[COMPLETAR: las 3 noticias más importantes de hoy con: 1) Titular 2) 1 línea de contexto]\n\nRedactá:\n\n1. VERSIÓN COMPLETA del resumen matutino 7:30 AM:\n   Estructura:\n   - Saludo: \"Buenos días Rufino.\"\n   - Intro de 1 oración con el tema dominante del día\n   - Las 3 noticias numeradas: titular + 1 oración de contexto\n   - CTA: \"→ Leé todo en elrufino.ar\"\n   - Máximo 300 caracteres por noticia\n   - Total: no más de 5 oraciones + CTA\n\n2. VERSIÓN RÁPIDA (para días con poco tiempo):\n   - Solo titular + 1 dato + link\n   - Menos de 160 caracteres en total\n\nTono: informativo, claro, sin alarmar. La apertura alta (>60%) se sostiene con consistencia y utilidad, no con titulares alarmistas.",
        ],
        [
            'id'    => 'hilo_facebook',
            'group' => 'redes',
            'icon'  => '📢',
            'nombre'      => 'Generador de hilo de Facebook',
            'rol'         => 'Editor de redes sociales',
            'descripcion' => 'Convierte una nota del sitio en un hilo de Facebook de 5–7 posts optimizado para engagement. Incluye el primer post con hook, desarrollo, y post final con pregunta al lector.',
            'entrega'     => 'Hilo de 5–7 posts listos para publicar en Facebook con timing sugerido.',
            'completar'   => 'La nota completa o el tema a desarrollar en el hilo.',
            'prompt_template' => "Sos el editor de redes sociales de El Rufino.\n\nContexto del medio:\n---\n{{CONTEXTO}}\n---\n\nNOTA O TEMA:\n[COMPLETAR: pegá la nota completa o describí el tema a desarrollar]\n\nConvertí esto en un hilo de Facebook de 5–7 posts.\n\nEstructura:\n- Post 1 (HOOK): la frase que para el scroll. Datos concretos, pregunta directa o revelación. Máximo 3 oraciones. Termina con \"Hilo 🧵\"\n- Posts 2–5 (DESARROLLO): un punto por post. Cada uno debe poder leerse solo. Usar números, datos o citas cuando hay.\n- Post 6 (CONTEXTO): la segunda capa — lo que significa, el trasfondo.\n- Post 7 (CTA): \"¿Qué pensás? / ¿Lo sabías? / Mandáselo a alguien de Rufino que tenga que saber esto.\"\n\nReglas:\n- Cada post: máximo 280 palabras\n- Evitar el lenguaje de comunicado oficial\n- Agregar emojis como marcadores visuales, no como decoración\n- Incluir el link al sitio en el último post\n- Horario óptimo de publicación: 8AM, 12PM o 7PM",
        ],
    ];
}
