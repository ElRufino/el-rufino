<?php get_header();
$term=$queried=is_tax('cat_entrevista')?get_queried_object():null;
$slug=$term?$term->slug:'';
?>
<main>
<div class="er-container">
<div class="er-main">
  <div>
    <?php if($term): ?><div class="er-section-label"><?php echo esc_html(er_cat_nombre($slug)); ?></div><?php endif; ?>
    <div class="er-grid">
    <?php if(have_posts()): while(have_posts()): the_post();
      $pid=get_the_ID();
      $cats=get_the_terms($pid,'cat_entrevista');$cat=$cats?$cats[0]:null;$cslug=$cat?$cat->slug:'politica';
      $audio=get_post_meta($pid,'er_audio',true);$quien=get_post_meta($pid,'er_nombre',true);
    ?>
    <div class="er-grid-card">
      <div class="er-card-img">
        <?php if(has_post_thumbnail()) the_post_thumbnail('er-strip',['class'=>'er-post-thumb','loading'=>'lazy']);
        else: ?><div class="er-post-thumb" style="height:125px;background:#f5f5f5;display:flex;align-items:center;justify-content:center"><span style="font-family:var(--f-cond);font-size:.6rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:<?php echo er_cat_color($cslug);?>"><?php echo esc_html(er_cat_nombre($cslug));?></span></div><?php endif; ?>
        <?php echo er_badge($pid); ?>
      </div>
      <span class="er-card-cat" style="color:<?php echo er_cat_color($cslug);?>"><?php echo esc_html(er_cat_nombre($cslug));?></span>
      <div class="er-card-titulo" style="font-size:.83rem;margin:.3rem 0"><a href="<?php the_permalink();?>"><?php the_title();?></a></div>
      <?php if($quien): ?><div class="er-card-quien"><?php echo esc_html($quien);?></div><?php endif; ?>
      <div class="er-card-meta"><?php echo esc_html(get_post_meta($pid,'er_fecha',true));?></div>
      <?php if($audio): ?><audio controls src="<?php echo esc_url($audio);?>" preload="none"></audio><?php endif; ?>
    </div>
    <?php endwhile;
    else: ?><div class="er-no-results">Sin entrevistas en esta categoría</div><?php endif; ?>
    </div>
    <?php the_posts_pagination(['mid_size'=>2,'prev_text'=>'← Anterior','next_text'=>'Siguiente →']); ?>
  </div>
  <aside class="er-sidebar"><?php get_sidebar(); ?></aside>
</div>
</div>
</main>
<?php get_footer(); ?>
