<?php
/**
 * single.php — vista de nota individual (posts estándar)
 */
get_header(); ?>
<main>
<div class="er-container">
<div class="er-main">
  <div>
  <?php while (have_posts()): the_post();
    $cats   = get_the_category();
    $cat    = $cats ? $cats[0] : null;
    $color  = $cat ? er_get_cat_color($cat->slug) : '#c8102e';
  ?>
  <article class="er-single">
    <?php if ($cat): ?>
    <div class="er-single-kicker" style="color:<?php echo $color; ?>">
      <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>" style="color:inherit;text-decoration:none"><?php echo esc_html($cat->name); ?></a>
    </div>
    <?php endif; ?>
    <h1 class="er-single-titulo"><?php the_title(); ?></h1>
    <div class="er-single-meta">
      <span><?php echo get_the_date('d \d\e F \d\e Y'); ?></span>
      <span class="er-nota-autor"><?php the_author(); ?></span>
    </div>
    <?php if (has_post_thumbnail()): ?>
    <div style="margin-bottom:1.5rem;border-radius:4px;overflow:hidden">
      <?php the_post_thumbnail('er-hero',['style'=>'width:100%;height:auto']); ?>
    </div>
    <?php endif; ?>
    <div class="er-single-body"><?php the_content(); ?></div>
  </article>
  <!-- AD SLOT 4 -->
  <div class="er-ad-slot" style="height:250px;margin:2rem 0"><?php echo do_shortcode('[er_slot id="4"]'); ?></div>
  <?php endwhile; ?>
  </div>
  <aside class="er-sidebar"><?php get_sidebar(); ?></aside>
</div>
</div>
</main>
<?php get_footer(); ?>
