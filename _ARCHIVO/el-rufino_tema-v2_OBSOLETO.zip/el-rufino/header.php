<?php
/**
 * header.php — El Rufino
 * Respeta las categorías editoriales reales del sitio
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ═══ TOPBAR ═══ -->
<div class="er-topbar">
  <div class="er-topbar-inner">
    <div class="er-topbar-left">
      <div class="er-topbar-item"><span id="er-fecha"></span></div>
      <div class="er-topbar-item" style="color:var(--gris-4)">Rufino · Santa Fe</div>
    </div>
    <div class="er-topbar-right">
      <span style="font-family:var(--f-cond);font-size:.6rem;letter-spacing:.06em;color:var(--gris-5)">elrufino.com.ar</span>
      <?php if (current_user_can('manage_options')): ?>
      <a href="<?php echo esc_url(admin_url('admin.php?page=vdi-setup')); ?>" class="er-admin-btn">⚙ Admin</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ═══ AD SLOT 1 ═══ -->
<div class="er-ad-slot er-ad-top">
  <?php echo do_shortcode('[er_slot id="1"]'); ?>
</div>

<!-- ═══ HEADER ═══ -->
<header class="er-header">
  <div class="er-header-inner">
    <div class="er-header-left">
      <div class="er-header-sub">Rufino · Santa Fe · Argentina</div>
      <div class="er-header-meta" style="font-style:italic;color:var(--gris-3);font-size:.68rem">Lo que pasa y lo que significa.</div>
    </div>
    <div class="er-logo">
      <a href="<?php echo esc_url(home_url('/')); ?>" title="El Rufino — Inicio">
        <span class="er-logo-el">el</span>
        <span class="er-logo-rufino">Rufino</span>
        <div class="er-logo-tagline">Periódico Digital del Sur Santafesino</div>
      </a>
    </div>
    <div class="er-header-right">
      <div class="er-ad-slot er-ad-hdr-r">
        <?php echo do_shortcode('[er_slot id="2"]'); ?>
      </div>
    </div>
  </div>
</header>

<!-- ═══ TICKER ═══ -->
<div class="er-ticker">
  <div class="er-ticker-label">HOY</div>
  <div class="er-ticker-track">
    <div class="er-ticker-content">
      <?php
      // Ticker dinámico con los últimos 8 posts
      $ticker_posts = get_posts(['post_type'=>'post','numberposts'=>8,'orderby'=>'date','order'=>'DESC']);
      $items = [];
      foreach ($ticker_posts as $tp) {
          $items[] = $tp->post_title;
      }
      // Fallback si no hay posts
      if (empty($items)) {
          $items = [
              'El Rufino — Información verificada y contexto útil para Rufino',
              'Noticias de Rufino y el sur santafesino',
              'Archivo de entrevistas radiales 2007–2012 disponible',
              'elrufino.com.ar · Lo que pasa y lo que significa',
          ];
      }
      // Duplicar para loop continuo
      $all_items = array_merge($items, $items);
      foreach ($all_items as $item): ?>
      <span class="er-ticker-item"><?php echo esc_html($item); ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ═══ NAVBAR STICKY ═══ -->
<nav class="er-navbar" role="navigation" aria-label="Navegación principal">
  <div class="er-navbar-inner">
    <div class="er-nav-links">

      <!-- Inicio -->
      <a href="<?php echo esc_url(home_url('/')); ?>"
         class="er-nav-link <?php echo (is_front_page() && !is_category() && !is_tax()) ? 'active' : ''; ?>">
        Inicio
      </a>

      <?php
      /*
       * Navbar: usa el menú de WordPress si existe (registrado como 'er-principal')
       * Si no hay menú registrado, cae en las categorías de posts nativas.
       */
      $menu_obj = wp_get_nav_menu_object('er-principal');
      if (!$menu_obj) {
          // Intentar con el primer menú disponible asignado a cualquier location
          $locs = get_nav_menu_locations();
          foreach ($locs as $loc_id) {
              $menu_obj = wp_get_nav_menu_object($loc_id);
              if ($menu_obj) break;
          }
      }

      if ($menu_obj) :
          // Usar el menú registrado de WordPress
          $menu_items = wp_get_nav_menu_items($menu_obj->term_id);
          if ($menu_items):
            foreach ($menu_items as $item):
              // Saltar "Inicio" / "Home" para no duplicar
              if (in_array(strtolower($item->title), ['inicio','home'])) continue;
              $active = '';
              if (is_category() && get_queried_object_id() == $item->object_id) $active = 'active';
              if (is_single() && in_category($item->object_id)) $active = 'active';
              // Para páginas
              if (is_page() && get_the_ID() == $item->object_id) $active = 'active';
          ?>
          <a href="<?php echo esc_url($item->url); ?>"
             class="er-nav-link <?php echo $active; ?>">
            <?php echo esc_html($item->title); ?>
          </a>
          <?php endforeach;
          endif;

      else :
          // Fallback: categorías nativas de WordPress
          $cats = get_categories([
              'hide_empty' => false,
              'exclude'    => get_option('default_category'),
              'number'     => 8,
              'orderby'    => 'menu_order',
              'order'      => 'ASC',
          ]);
          $queried_cat = is_category() ? get_queried_object() : null;
          foreach ($cats as $cat):
              $active = ($queried_cat && $queried_cat->term_id === $cat->term_id) ? 'active' : '';
          ?>
          <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>"
             class="er-nav-link <?php echo $active; ?>">
            <?php echo esc_html($cat->name); ?>
          </a>
          <?php endforeach;
      endif; ?>

      <!-- Archivo de entrevistas — siempre último -->
      <?php if (post_type_exists('entrevista')): ?>
      <a href="<?php echo esc_url(get_post_type_archive_link('entrevista') ?: home_url('/entrevistas/')); ?>"
         class="er-nav-link <?php echo (is_post_type_archive('entrevista') || is_singular('entrevista') || is_tax('cat_entrevista')) ? 'active' : ''; ?>"
         style="border-left:1px solid var(--linea);margin-left:.25rem;padding-left:1rem;color:var(--rojo)">
        Archivo
      </a>
      <?php endif; ?>

    </div>
    <div style="flex-shrink:0;padding:0 .5rem;cursor:pointer;font-size:.9rem;color:var(--gris-4)" id="er-search-toggle">🔍</div>
  </div>
  <div id="er-search-bar" style="display:none;padding:.4rem 1.25rem;border-top:1px solid var(--linea);background:var(--gris-7)">
    <?php get_search_form(); ?>
  </div>
</nav>
