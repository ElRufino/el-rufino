<?php get_header(); ?>
<main>
<div class="er-container" style="padding-top:0">
  <?php while(have_posts()): the_post();
    $pid=get_the_ID();
    $cats=get_the_terms($pid,'cat_entrevista');$cat=$cats?$cats[0]:null;$slug=$cat?$cat->slug:'politica';
    $quien=get_post_meta($pid,'er_nombre',true);$cargo=get_post_meta($pid,'er_cargo',true);
    $fecha=get_post_meta($pid,'er_fecha',true);$id_doc=get_post_meta($pid,'er_id_doc',true);
    $audio=get_post_meta($pid,'er_audio',true);
  ?>
  <div class="er-single">
    <div class="er-single-kicker"><?php echo esc_html(er_cat_nombre($slug)); ?><?php if($id_doc): ?> · <?php echo esc_html($id_doc); ?><?php endif; ?></div>
    <h1 class="er-single-titulo"><?php the_title(); ?></h1>
    <?php if($quien): ?><div class="er-single-quien"><?php echo esc_html($quien.($cargo?' — '.$cargo:'')); ?></div><?php endif; ?>
    <div class="er-single-meta">
      <?php if($fecha): ?><span><?php echo esc_html($fecha); ?></span><?php endif; ?>
      <?php echo er_badge($pid); ?>
    </div>
    <?php if($audio): ?>
    <div class="er-single-audio">
      <div class="er-single-audio-lbl">🎧 Escuchar entrevista completa</div>
      <audio controls src="<?php echo esc_url($audio); ?>" preload="metadata" style="width:100%"></audio>
    </div>
    <?php endif; ?>
    <div class="er-single-body"><?php the_content(); ?></div>
  </div>
  <!-- AD SLOT 4 -->
  <div class="er-ad-slot" style="height:250px;max-width:820px;margin:2rem auto"><?php echo do_shortcode('[er_slot id="4"]'); ?></div>
  <?php endwhile; ?>
</div>
</main>
<?php get_footer(); ?>
