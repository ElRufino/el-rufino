<?php
/**
 * category.php — archivo de categoría para posts estándar
 */
get_header();
$cat    = get_queried_object();
$color  = $cat ? er_get_cat_color($cat->slug) : '#c8102e';
?>
<main>
<div class="er-container">
<div class="er-main">
  <div>
    <div class="er-section-label" style="color:<?php echo $color; ?>"><?php echo esc_html($cat ? $cat->name : 'Categoría'); ?></div>
    <div class="er-notas-3" style="margin-bottom:2rem">
    <?php if (have_posts()): while (have_posts()): the_post();
      $pid_c = get_the_ID();
    ?>
    <div class="er-nota-item">
      <div class="er-nota-img-sec">
        <?php if (has_post_thumbnail()): the_post_thumbnail('er-card',['loading'=>'lazy']);
        else: echo '<div class="er-nota-img-placeholder"><span class="ph-cat" style="color:'.esc_attr($color).'">El Rufino</span></div>'; endif; ?>
      </div>
      <div class="er-nota-body">
        <div class="er-nota-titulo er-nota-titulo-sm"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
        <div class="er-nota-meta"><?php echo get_the_date('d/m/Y'); ?></div>
      </div>
    </div>
    <?php endwhile;
    else: ?><div class="er-no-results">Sin notas en esta sección.</div><?php endif; ?>
    </div>
    <?php the_posts_pagination(['prev_text'=>'← Anterior','next_text'=>'Siguiente →']); ?>
  </div>
  <aside class="er-sidebar"><?php get_sidebar(); ?></aside>
</div>
</div>
</main>
<?php get_footer(); ?>
