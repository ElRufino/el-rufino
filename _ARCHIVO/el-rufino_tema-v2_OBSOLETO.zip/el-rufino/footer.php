<?php
/**
 * footer.php — El Rufino
 */
?>

<!-- ═══ AD SLOT 11 — LEADERBOARD PIE ═══ -->
<div class="er-ad-slot er-ad-footer">
  <?php echo do_shortcode('[er_slot id="11"]'); ?>
</div>

<footer class="er-footer">
  <div class="er-footer-inner">
    <div class="er-footer-grid">
      <div>
        <div class="er-footer-logo">El <span>Rufino</span></div>
        <div class="er-footer-desc">
          Periódico digital de Rufino y el sur santafesino. Noticias locales, archivo de entrevistas radiales 2007–2012 y memoria del territorio.
        </div>
      </div>
      <div>
        <div class="er-footer-heading">Secciones</div>
        <div class="er-footer-links">
          <?php
          $cats = get_terms(['taxonomy'=>'cat_entrevista','hide_empty'=>false,'number'=>8]);
          if (!is_wp_error($cats)):
            foreach ($cats as $cat):
          ?>
          <a href="<?php echo esc_url(get_term_link($cat)); ?>"><?php echo esc_html(er_cat_nombre($cat->slug)); ?></a>
          <?php endforeach; endif; ?>
        </div>
      </div>
      <div>
        <div class="er-footer-heading">Institucional</div>
        <div class="er-footer-links">
          <a href="<?php echo esc_url(home_url('/acerca')); ?>">Acerca de El Rufino</a>
          <a href="<?php echo esc_url(home_url('/criterio-archivistico')); ?>">Criterio archivístico</a>
          <a href="<?php echo esc_url(home_url('/publicidad')); ?>">Publicidad · 11 espacios</a>
          <a href="<?php echo esc_url(home_url('/contacto')); ?>">Contacto</a>
          <?php if (current_user_can('manage_options')): ?>
          <a href="<?php echo esc_url(admin_url()); ?>">Panel administrador</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="er-footer-bottom">
      <span>© <?php echo date('Y'); ?> El Rufino · elrufino.com.ar · Rufino, Santa Fe, Argentina</span>
      <span class="er-footer-issn"><?php echo (int)(wp_count_posts('entrevista')->publish??0); ?> entrevistas en el archivo · Sede: Rufino, Pcia. de Santa Fe</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
