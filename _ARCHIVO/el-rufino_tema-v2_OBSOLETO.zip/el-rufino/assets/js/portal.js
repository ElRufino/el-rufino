document.addEventListener('DOMContentLoaded', function() {
  var el = document.getElementById('er-fecha');
  if (el) {
    var d=new Date(),dias=['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'],meses=['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
    el.textContent=dias[d.getDay()]+' '+d.getDate()+' de '+meses[d.getMonth()]+' de '+d.getFullYear();
  }
  var sb=document.getElementById('er-search-bar');
  if(sb){sb.style.display='none';document.querySelectorAll('[onclick*="er-search-bar"]').forEach(function(btn){btn.removeAttribute('onclick');btn.addEventListener('click',function(e){e.stopPropagation();sb.style.display=sb.style.display==='none'?'block':'none';});});document.addEventListener('click',function(){sb.style.display='none';});}
});
