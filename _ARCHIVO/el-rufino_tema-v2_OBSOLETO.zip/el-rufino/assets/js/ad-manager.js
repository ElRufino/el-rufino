(function(){
  document.addEventListener('click',function(e){
    var el=e.target.closest('[data-aviso-id]');
    if(!el||!window.ER) return;
    e.preventDefault();
    var id=el.getAttribute('data-aviso-id'),url=el.getAttribute('data-url')||'#';
    var fd=new FormData();fd.append('action','er_clic');fd.append('aviso_id',id);fd.append('nonce',ER.nonce);
    fetch(ER.ajaxUrl,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(d){if(d.success){var b=el.querySelector('.er-ad-clics');if(b)b.textContent='👆'+d.data.clics;}});
    if(url&&url!=='#') window.open(url,'_blank','noopener');
  });
})();
