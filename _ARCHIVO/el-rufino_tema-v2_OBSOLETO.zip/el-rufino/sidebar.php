<?php
// sidebar.php — usado en category.php, archive-entrevista.php, single.php
?>
<div class="er-ad-slot er-ad-sidebar"><?php echo do_shortcode('[er_slot id="3"]'); ?></div>

<div class="er-widget">
  <div class="er-widget-titulo">Secciones</div>
  <?php $scats=get_categories(['hide_empty'=>true,'exclude'=>get_option('default_category'),'number'=>8]);
  foreach ($scats as $sc):
    $sc_c = er_get_cat_color($sc->slug);
  ?>
  <div class="er-stat-row">
    <a href="<?php echo esc_url(get_category_link($sc->term_id)); ?>" style="font-family:var(--f-cond);font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:<?php echo $sc_c; ?>;text-decoration:none"><?php echo esc_html($sc->name); ?></a>
    <span style="font-family:var(--f-cond);font-size:.6rem;color:var(--gris-4)"><?php echo $sc->count; ?></span>
  </div>
  <?php endforeach; ?>
  <?php if (post_type_exists('entrevista')): ?>
  <div class="er-stat-row" style="margin-top:.4rem">
    <a href="<?php echo esc_url(get_post_type_archive_link('entrevista')?:home_url('/entrevistas/')); ?>" style="font-family:var(--f-cond);font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--rojo);text-decoration:none">📻 Archivo</a>
  </div>
  <?php endif; ?>
</div>

<div class="er-ad-slot er-ad-sidebar" style="position:sticky;top:52px"><?php echo do_shortcode('[er_slot id="7"]'); ?></div>

<div class="er-widget">
  <div class="er-widget-titulo">Canal WhatsApp</div>
  <div style="font-size:.8rem;color:var(--gris-2);line-height:1.6;margin-bottom:.75rem">Resumen diario directo a tu celular, sin algoritmo.</div>
  <a href="#" style="font-family:var(--f-cond);font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;background:#25D366;color:#fff;padding:.45rem 1rem;border-radius:3px;text-decoration:none;display:inline-block">📱 Sumarme</a>
</div>
