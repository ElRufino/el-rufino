<?php
/**
 * index.php — El Rufino
 * Homepage editorial que respeta las categorías reales del sitio.
 * 
 * Estructura:
 * 1. Hero principal (nota más reciente destacada)
 * 2. Bloque por cada categoría editorial con contenido
 * 3. Banda de acceso al archivo de entrevistas
 * 4. Últimas noticias (lista numerada)
 */
get_header();

/* ── HELPERS ── */
function er_get_cat_color($cat_slug) {
    // Si la categoría tiene color asignado por el tema, usarlo
    // Colores editoriales por slug (los del sitio real)
    $map = [
        'actualidad'      => '#c8102e',
        'seguimiento'     => '#1d4ed8',
        'poder-y-gestion' => '#7c3aed',
        'poder_y_gestion' => '#7c3aed',
        'barrio-a-barrio' => '#16a34a',
        'barrio_a_barrio' => '#16a34a',
        'el-campo-habla'  => '#a16207',
        'el_campo_habla'  => '#a16207',
        'rufino-en-datos' => '#0891b2',
        'rufino_en_datos' => '#0891b2',
        // Categorías del CPT
        'politica'        => '#c8102e',
        'salud'           => '#16a34a',
        'agro'            => '#a16207',
        'sindical'        => '#1d4ed8',
        'educacion'       => '#7c3aed',
        'cultura'         => '#db2777',
        'social'          => '#0891b2',
        'economia'        => '#ea580c',
    ];
    return $map[$cat_slug] ?? '#c8102e';
}

function er_nota_placeholder($color = '#c8102e') {
    return '<div class="er-nota-img-placeholder"><span class="ph-cat" style="color:'.esc_attr($color).'">El Rufino</span></div>';
}
?>

<main>
<div class="er-container">
<div class="er-main">

  <!-- ════════ COLUMNA PRINCIPAL ════════ -->
  <div>

    <!-- ══ HERO: LAS 3 NOTAS MÁS RECIENTES ══ -->
    <?php
    $hero_query = new WP_Query([
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'posts_per_page' => 3,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);

    if ($hero_query->have_posts()):
        $hero_posts = [];
        while ($hero_query->have_posts()) {
            $hero_query->the_post();
            $hero_posts[] = [
                'id'       => get_the_ID(),
                'title'    => get_the_title(),
                'link'     => get_permalink(),
                'excerpt'  => get_the_excerpt(),
                'date'     => get_the_date('d/m/Y'),
                'author'   => get_the_author(),
                'cat'      => get_the_category(),
                'has_img'  => has_post_thumbnail(),
            ];
        }
        wp_reset_postdata();

        $p1 = $hero_posts[0] ?? null;
        $p2 = $hero_posts[1] ?? null;
        $p3 = $hero_posts[2] ?? null;

        // Color de la cat del post principal
        $cat1 = $p1 && $p1['cat'] ? $p1['cat'][0] : null;
        $color1 = $cat1 ? er_get_cat_color($cat1->slug) : '#c8102e';
    ?>

    <div class="er-hero-wrap">

      <!-- NOTA PRINCIPAL -->
      <?php if ($p1): ?>
      <div class="er-hero-principal">
        <div class="er-nota-img-hero">
          <?php if ($p1['has_img']): set_query_var('post_id', $p1['id']); ?>
            <?php echo get_the_post_thumbnail($p1['id'], 'er-hero', ['loading'=>'eager']); ?>
          <?php else: echo er_nota_placeholder($color1); endif; ?>
        </div>
        <div class="er-nota-body-hero">
          <?php if ($cat1): ?>
          <span class="er-nota-seccion" style="color:<?php echo $color1; ?>"><?php echo esc_html($cat1->name); ?></span>
          <?php endif; ?>
          <div class="er-nota-titulo er-nota-titulo-hero">
            <a href="<?php echo esc_url($p1['link']); ?>"><?php echo esc_html($p1['title']); ?></a>
          </div>
          <div class="er-nota-extracto"><?php echo wp_trim_words($p1['excerpt'], 28); ?></div>
          <div class="er-nota-meta">
            <span><?php echo esc_html($p1['date']); ?></span>
            <?php if ($p1['author']): ?><span class="er-nota-autor"><?php echo esc_html($p1['author']); ?></span><?php endif; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <!-- NOTAS SECUNDARIAS -->
      <div class="er-hero-secundarias">
        <?php foreach ([$p2, $p3] as $pn):
          if (!$pn) continue;
          $catn = $pn['cat'] ? $pn['cat'][0] : null;
          $colorn = $catn ? er_get_cat_color($catn->slug) : '#c8102e';
        ?>
        <div class="er-hero-sec-item">
          <div class="er-nota-img-sec">
            <?php if ($pn['has_img']): echo get_the_post_thumbnail($pn['id'], 'er-card', ['loading'=>'eager']);
            else: echo er_nota_placeholder($colorn); endif; ?>
          </div>
          <div class="er-nota-body">
            <?php if ($catn): ?>
            <span class="er-nota-seccion" style="color:<?php echo $colorn; ?>"><?php echo esc_html($catn->name); ?></span>
            <?php endif; ?>
            <div class="er-nota-titulo er-nota-titulo-sec">
              <a href="<?php echo esc_url($pn['link']); ?>"><?php echo esc_html($pn['title']); ?></a>
            </div>
            <div class="er-nota-meta"><span><?php echo esc_html($pn['date']); ?></span></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

    </div>
    <?php endif; ?>

    <!-- AD SLOT 5 — LEADERBOARD INTERMEDIO -->
    <div class="er-ad-slot er-ad-mid">
      <?php echo do_shortcode('[er_slot id="5"]'); ?>
    </div>

    <?php
    /*
     * BLOQUES POR CATEGORÍA
     * Para cada categoría con posts, mostramos un bloque con 3 notas.
     * Excluimos "Sin categoría" y categorías sin contenido.
     */
    $editorial_cats = get_categories([
        'hide_empty' => true,
        'number'     => 6,
        'exclude'    => get_option('default_category'),
        'orderby'    => 'menu_order',
        'order'      => 'ASC',
    ]);

    $bloque_count = 0;
    foreach ($editorial_cats as $ecat):
        $bloque_posts = new WP_Query([
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 3,
            'cat'            => $ecat->term_id,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);
        if (!$bloque_posts->have_posts()) { wp_reset_postdata(); continue; }
        $bloque_count++;
        $cat_color = er_get_cat_color($ecat->slug);
    ?>

    <div class="er-bloque-seccion">
      <div class="er-bloque-seccion-hdr">
        <span class="er-bloque-seccion-nombre" style="border-bottom:3px solid <?php echo $cat_color; ?>;padding-bottom:.35rem"><?php echo esc_html($ecat->name); ?></span>
        <a href="<?php echo esc_url(get_category_link($ecat->term_id)); ?>" class="er-bloque-seccion-ver">Ver todo →</a>
      </div>

      <div class="er-notas-3">
      <?php while ($bloque_posts->have_posts()): $bloque_posts->the_post();
        $pid_b = get_the_ID();
      ?>
      <div class="er-nota-item">
        <div class="er-nota-img-sec">
          <?php if (has_post_thumbnail()): the_post_thumbnail('er-card',['loading'=>'lazy']);
          else: echo er_nota_placeholder($cat_color); endif; ?>
        </div>
        <div class="er-nota-body">
          <div class="er-nota-titulo er-nota-titulo-sm">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
          </div>
          <div class="er-nota-meta"><?php echo get_the_date('d/m/Y'); ?></div>
        </div>
      </div>
      <?php endwhile; wp_reset_postdata(); ?>
      </div>
    </div>

    <?php
    // Insertar ad slot 6 después del segundo bloque
    if ($bloque_count === 2):
    ?>
    <div class="er-ad-slot er-ad-banner">
      <?php echo do_shortcode('[er_slot id="6"]'); ?>
    </div>
    <?php endif;

    endforeach; // fin foreach $editorial_cats
    ?>

    <!-- ══ BANDA ARCHIVO DE ENTREVISTAS ══ -->
    <?php if (post_type_exists('entrevista')): ?>
    <?php $n_ent = (int)(wp_count_posts('entrevista')->publish ?? 0); ?>
    <div class="er-archivo-band">
      <div class="er-archivo-band-txt">
        <strong>📻 Archivo de entrevistas radiales 2007–2012</strong>
        <?php echo $n_ent > 0 ? $n_ent . ' entrevistas del sur santafesino disponibles en línea.' : 'Corpus documental de Rufino y la región, en proceso de digitalización.'; ?>
        Política, salud, agro, sindical, educación, cultura, social y economía.
      </div>
      <a href="<?php echo esc_url(get_post_type_archive_link('entrevista') ?: home_url('/entrevistas/')); ?>" class="er-archivo-band-btn">
        Explorar el archivo →
      </a>
    </div>
    <?php endif; ?>

    <!-- AD SLOT 9 -->
    <div class="er-ad-slot er-ad-final">
      <?php echo do_shortcode('[er_slot id="9"]'); ?>
    </div>

    <!-- ══ ÚLTIMAS NOTAS — LISTA NUMERADA ══ -->
    <?php
    $ultimas = new WP_Query([
        'post_type'      => 'post',
        'post_status'    => 'publish',
        'posts_per_page' => 8,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'offset'         => 3, // saltar las 3 del hero
    ]);
    if ($ultimas->have_posts()):
    ?>
    <div class="er-section-label">Últimas noticias</div>
    <div class="er-lista-notas">
    <?php $ln = 1; while ($ultimas->have_posts()): $ultimas->the_post();
      $pid_u = get_the_ID();
      $cats_u = get_the_category();
      $cat_u  = $cats_u ? $cats_u[0] : null;
      $color_u = $cat_u ? er_get_cat_color($cat_u->slug) : '#c8102e';
    ?>
    <div class="er-lista-item">
      <div class="er-lista-num"><?php echo $ln++; ?></div>
      <?php if (has_post_thumbnail()): ?>
      <div class="er-lista-thumb"><?php the_post_thumbnail('er-thumb',['loading'=>'lazy']); ?></div>
      <?php endif; ?>
      <div class="er-lista-body">
        <div class="er-lista-titulo"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
        <div class="er-lista-meta">
          <?php if ($cat_u): ?><span style="color:<?php echo $color_u; ?>;font-weight:700"><?php echo esc_html($cat_u->name); ?></span> · <?php endif; ?>
          <?php echo get_the_date('d/m/Y'); ?>
        </div>
      </div>
    </div>
    <?php endwhile; wp_reset_postdata(); ?>
    </div>

    <!-- PAGINACIÓN -->
    <div style="text-align:center;margin:1.5rem 0">
      <a href="<?php echo esc_url(get_pagenum_link(2)); ?>" style="font-family:var(--f-cond);font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;background:var(--negro);color:var(--blanco);padding:.55rem 1.5rem;border-radius:3px;text-decoration:none;transition:background .15s" onmouseover="this.style.background='var(--rojo)'" onmouseout="this.style.background='var(--negro)'">
        Ver más noticias →
      </a>
    </div>
    <?php endif; ?>

  </div><!-- /columna principal -->

  <!-- ════════ SIDEBAR ════════ -->
  <aside class="er-sidebar">

    <!-- AD SLOT 3 -->
    <div class="er-ad-slot er-ad-sidebar">
      <?php echo do_shortcode('[er_slot id="3"]'); ?>
    </div>

    <!-- WIDGET: SECCIONES DEL SITIO -->
    <div class="er-widget">
      <div class="er-widget-titulo">Secciones</div>
      <?php
      $sidebar_cats = get_categories(['hide_empty'=>true,'exclude'=>get_option('default_category'),'number'=>8,'orderby'=>'menu_order']);
      foreach ($sidebar_cats as $sc):
        $sc_color = er_get_cat_color($sc->slug);
      ?>
      <div class="er-stat-row">
        <a href="<?php echo esc_url(get_category_link($sc->term_id)); ?>"
           style="font-family:var(--f-cond);font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:<?php echo $sc_color; ?>;text-decoration:none">
          <?php echo esc_html($sc->name); ?>
        </a>
        <span style="font-family:var(--f-cond);font-size:.6rem;color:var(--gris-4)"><?php echo $sc->count; ?> notas</span>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- WIDGET: LO MÁS VISTO (comentado = más visitado) -->
    <div class="er-widget">
      <div class="er-widget-titulo">Lo más leído</div>
      <?php
      $mas_leidos = new WP_Query([
          'post_type'      => 'post',
          'posts_per_page' => 6,
          'orderby'        => 'comment_count',
          'order'          => 'DESC',
      ]);
      $ml = 1;
      while ($mas_leidos->have_posts()): $mas_leidos->the_post();
        $ml_cats = get_the_category();
        $ml_cat  = $ml_cats ? $ml_cats[0] : null;
        $ml_color = $ml_cat ? er_get_cat_color($ml_cat->slug) : '#c8102e';
      ?>
      <div class="er-top-item">
        <div class="er-top-n"><?php echo $ml++; ?></div>
        <div>
          <div class="er-top-titulo"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
          <?php if ($ml_cat): ?><div class="er-top-meta" style="color:<?php echo $ml_color; ?>"><?php echo esc_html($ml_cat->name); ?></div><?php endif; ?>
        </div>
      </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>

    <!-- AD SLOT 7 -->
    <div class="er-ad-slot er-ad-sidebar" style="position:sticky;top:52px">
      <?php echo do_shortcode('[er_slot id="7"]'); ?>
    </div>

    <!-- WIDGET: CANAL WHATSAPP (respeta el elemento del sitio original) -->
    <div class="er-widget">
      <div class="er-widget-titulo">Canal de WhatsApp</div>
      <div style="font-size:.82rem;color:var(--gris-2);line-height:1.65;margin-bottom:.85rem">
        Resumen diario, circulación directa y acceso sin algoritmo. Sumate al canal para recibir una selección útil de temas de Rufino.
      </div>
      <a href="#" style="font-family:var(--f-cond);font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;background:#25D366;color:#fff;padding:.5rem 1.1rem;border-radius:3px;text-decoration:none;display:inline-block">
        📱 Sumarme
      </a>
    </div>

    <!-- WIDGET: COLUMNA EDITORIAL -->
    <div class="er-widget">
      <div class="er-widget-titulo">El Rufino</div>
      <div class="er-columna">
        "Información verificada, contexto útil y seguimiento de los temas que afectan la vida cotidiana, institucional, económica y social de Rufino."
      </div>
      <div class="er-columna-firma">— Equipo editorial · elrufino.com.ar</div>
    </div>

    <!-- AD SLOT 8 -->
    <div class="er-ad-slot er-ad-sidebar">
      <?php echo do_shortcode('[er_slot id="8"]'); ?>
    </div>

  </aside>

</div><!-- /er-main -->
</div><!-- /er-container -->
</main>

<?php get_footer(); ?>
