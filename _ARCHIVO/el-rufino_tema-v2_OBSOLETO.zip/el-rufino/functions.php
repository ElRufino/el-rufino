<?php
/**
 * El Rufino — functions.php
 * Tema hijo de Hello Elementor
 * elrufino.com.ar
 */

defined('ABSPATH') || exit;

/* ══════════════════════════════════════
   1. ENQUEUE — HELLO ELEMENTOR COMPATIBLE
══════════════════════════════════════ */
add_action('wp_enqueue_scripts', function() {
    // Estilos del padre Hello Elementor
    wp_enqueue_style(
        'hello-elementor-parent',
        get_template_directory_uri() . '/style.css'
    );
    // Google Fonts
    wp_enqueue_style(
        'er-fonts',
        'https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Barlow:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Barlow+Condensed:wght@400;500;600;700;800&display=swap',
        [],
        null
    );
    // CSS del portal
    wp_enqueue_style(
        'er-portal',
        get_stylesheet_directory_uri() . '/assets/css/portal.css',
        ['hello-elementor-parent'],
        '1.0.0'
    );
    // JS
    wp_enqueue_script(
        'er-portal',
        get_stylesheet_directory_uri() . '/assets/js/portal.js',
        [],
        '1.0.0',
        true
    );
    wp_enqueue_script(
        'er-ads',
        get_stylesheet_directory_uri() . '/assets/js/ad-manager.js',
        ['er-portal'],
        '1.0.0',
        true
    );
    wp_localize_script('er-portal', 'ER', [
        'ajaxUrl'  => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('er_nonce'),
        'homeUrl'  => home_url(),
        'themeUrl' => get_stylesheet_directory_uri(),
        'siteName' => get_bloginfo('name'),
    ]);
}, 20);

/* ══════════════════════════════════════
   2. SOPORTE DE TEMA
══════════════════════════════════════ */
add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','gallery','caption']);
    add_image_size('er-hero',  800, 560, true);
    add_image_size('er-card',  400, 280, true);
    add_image_size('er-strip', 200, 140, true);
    add_image_size('er-thumb', 120, 90,  true);
});

/* ══════════════════════════════════════
   3. CPT: ENTREVISTA
══════════════════════════════════════ */
add_action('init', function() {
    register_post_type('entrevista', [
        'labels' => [
            'name'          => 'Entrevistas',
            'singular_name' => 'Entrevista',
            'add_new_item'  => 'Agregar entrevista',
            'edit_item'     => 'Editar entrevista',
            'all_items'     => 'Todas las entrevistas',
            'menu_name'     => 'Entrevistas',
        ],
        'public'         => true,
        'has_archive'    => true,
        'menu_icon'      => 'dashicons-microphone',
        'menu_position'  => 5,
        'supports'       => ['title','editor','thumbnail','excerpt','custom-fields'],
        'rewrite'        => ['slug' => 'entrevistas'],
        'show_in_rest'   => true,
    ]);

    register_taxonomy('cat_entrevista', 'entrevista', [
        'labels' => [
            'name'          => 'Categorías',
            'singular_name' => 'Categoría',
            'add_new_item'  => 'Agregar categoría',
            'edit_item'     => 'Editar categoría',
        ],
        'hierarchical' => true,
        'public'       => true,
        'rewrite'      => ['slug' => 'categoria'],
        'show_in_rest' => true,
    ]);
}, 5);

/* ══════════════════════════════════════
   4. CPT: AVISO PUBLICITARIO
══════════════════════════════════════ */
add_action('init', function() {
    register_post_type('aviso_pub', [
        'labels' => [
            'name'          => 'Avisos Publicitarios',
            'singular_name' => 'Aviso',
            'add_new_item'  => 'Nuevo aviso',
            'edit_item'     => 'Editar aviso',
            'all_items'     => 'Todos los avisos',
            'menu_name'     => 'Avisos',
        ],
        'public'        => false,
        'show_ui'       => true,
        'menu_icon'     => 'dashicons-megaphone',
        'menu_position' => 6,
        'supports'      => ['title'],
        'show_in_rest'  => true,
    ]);
}, 5);

/* ══════════════════════════════════════
   5. META BOXES — ENTREVISTA
══════════════════════════════════════ */
add_action('add_meta_boxes', function() {
    add_meta_box('er_datos', 'Datos archivísticos', 'er_meta_box', 'entrevista', 'normal', 'high');
});
function er_meta_box($post) {
    wp_nonce_field('er_meta', 'er_meta_nonce');
    $f = [
        'er_id_doc'   => ['ID Documental',      'text',  'ENT-001'],
        'er_nombre'   => ['Entrevistado/a',      'text',  'Nombre completo'],
        'er_cargo'    => ['Cargo / Institución', 'text',  ''],
        'er_fecha'    => ['Fecha de grabación',  'date',  ''],
        'er_anio'     => ['Año',                 'number','2007'],
        'er_audio'    => ['URL del audio (MP3)', 'url',   'https://...'],
    ];
    echo '<table class="form-table">';
    foreach ($f as $k => [$l,$t,$p]) {
        $v = get_post_meta($post->ID,$k,true);
        echo "<tr><th><label for='$k'>$l</label></th><td><input type='$t' name='$k' id='$k' value='".esc_attr($v)."' placeholder='".esc_attr($p)."' class='regular-text'></td></tr>";
    }
    // Estado
    $est = get_post_meta($post->ID,'er_estado',true)?:'pendiente';
    echo "<tr><th>Estado archivístico</th><td><select name='er_estado'>";
    foreach(['revisado'=>'Revisado','pendiente'=>'Pendiente','digitalizar'=>'Digitalizar'] as $val=>$lbl) {
        echo "<option value='$val'".($est===$val?' selected':'').">$lbl</option>";
    }
    echo "</select></td></tr>";
    // Destacada
    $dest = get_post_meta($post->ID,'er_destacada',true);
    echo "<tr><th>Destacada en portada</th><td><label><input type='checkbox' name='er_destacada' value='1'".($dest?' checked':'')."> Mostrar en el hero grid de portada</label></td></tr>";
    echo '</table>';
}
add_action('save_post', function($id) {
    if (!isset($_POST['er_meta_nonce'])||!wp_verify_nonce($_POST['er_meta_nonce'],'er_meta')) return;
    if (defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE) return;
    foreach(['er_id_doc','er_nombre','er_cargo','er_fecha','er_anio','er_audio','er_estado'] as $f) {
        if (isset($_POST[$f])) update_post_meta($id,$f,sanitize_text_field($_POST[$f]));
    }
    update_post_meta($id,'er_destacada',isset($_POST['er_destacada'])?1:0);
});

/* ══════════════════════════════════════
   6. META BOXES — AVISO PUBLICITARIO
══════════════════════════════════════ */
add_action('add_meta_boxes', function() {
    add_meta_box('er_aviso','Datos del aviso','er_aviso_meta','aviso_pub','normal','high');
});
function er_aviso_meta($post) {
    wp_nonce_field('er_aviso','er_aviso_nonce');
    $pos_opts = [
        '1'=>'1 · Leaderboard Superior (970×90)',
        '2'=>'2 · Header Derecha (300×80)',
        '3'=>'3 · Box Lateral (300×250)',
        '4'=>'4 · Box In-Artículo (240×200)',
        '5'=>'5 · Leaderboard Intermedio (970×90)',
        '6'=>'6 · Banner Intertemático (728×90)',
        '7'=>'7 · Box Sidebar Sticky (300×250)',
        '8'=>'8 · Box Sidebar Inferior (300×250)',
        '9'=>'9 · Leaderboard Bloque Final (970×120)',
        '10'=>'10 · Box Grilla Final (360×250)',
        '11'=>'11 · Leaderboard Pie (970×90)',
    ];
    $pv = get_post_meta($post->ID,'er_av_pos',true);
    echo '<table class="form-table">';
    echo "<tr><th>Posición</th><td><select name='er_av_pos'><option value=''>— Seleccionar —</option>";
    foreach ($pos_opts as $k=>$v) echo "<option value='$k'".($pv===$k?' selected':'').">$v</option>";
    echo "</select></td></tr>";
    $flds = ['er_av_cliente'=>['Cliente / Empresa','text'],'er_av_contacto'=>['Contacto','text'],'er_av_url'=>['URL destino','url'],'er_av_inicio'=>['Fecha inicio','date'],'er_av_fin'=>['Fecha fin','date'],'er_av_refresco'=>['Refresco (segundos)','number'],'er_av_img'=>['URL imagen del aviso','url'],'er_av_img_def'=>['URL imagen predeterminada (al vencer)','url']];
    foreach ($flds as $k=>[$l,$t]) {
        $v=get_post_meta($post->ID,$k,true);
        echo "<tr><th>$l</th><td><input type='$t' name='$k' value='".esc_attr($v)."' class='regular-text'></td></tr>";
    }
    $clics=(int)get_post_meta($post->ID,'er_av_clics',true);
    echo "<tr><th>Clics registrados</th><td><strong>$clics</strong></td></tr>";
    echo '</table>';
}
add_action('save_post_aviso_pub', function($id) {
    if (!isset($_POST['er_aviso_nonce'])||!wp_verify_nonce($_POST['er_aviso_nonce'],'er_aviso')) return;
    foreach(['er_av_pos','er_av_cliente','er_av_contacto','er_av_url','er_av_inicio','er_av_fin','er_av_refresco','er_av_img','er_av_img_def'] as $f) {
        if (isset($_POST[$f])) update_post_meta($id,$f,sanitize_text_field($_POST[$f]));
    }
});

/* ══════════════════════════════════════
   7. AJAX: REGISTRAR CLIC EN AVISO
══════════════════════════════════════ */
add_action('wp_ajax_nopriv_er_clic', 'er_clic_cb');
add_action('wp_ajax_er_clic',        'er_clic_cb');
function er_clic_cb() {
    check_ajax_referer('er_nonce','nonce');
    $id = (int)$_POST['aviso_id'];
    if (!$id) wp_send_json_error();
    $c = (int)get_post_meta($id,'er_av_clics',true);
    update_post_meta($id,'er_av_clics',$c+1);
    wp_send_json_success(['clics'=>$c+1]);
}

/* ══════════════════════════════════════
   8. SHORTCODE: [er_slot id="N"]
══════════════════════════════════════ */
add_shortcode('er_slot', function($atts) {
    $atts = shortcode_atts(['id'=>'1'], $atts);
    $pos  = (int)$atts['id'];
    $hoy  = date('Y-m-d');
    $nombres = [
        1=>'Leaderboard Superior',2=>'Header Derecha',3=>'Box Lateral',
        4=>'Box In-Artículo',5=>'Leaderboard Intermedio',6=>'Banner Intertemático',
        7=>'Box Sidebar Sticky',8=>'Box Sidebar Inferior',9=>'Leaderboard Bloque Final',
        10=>'Box Grilla Final',11=>'Leaderboard Pie',
    ];
    $lbl = $nombres[$pos] ?? "Slot $pos";

    // Buscar aviso activo
    $avisos = get_posts([
        'post_type'=>'aviso_pub','post_status'=>'publish','numberposts'=>1,
        'meta_query'=>['relation'=>'AND',
            ['key'=>'er_av_pos',    'value'=>(string)$pos,'compare'=>'='],
            ['key'=>'er_av_inicio', 'value'=>$hoy,'compare'=>'<='],
            ['key'=>'er_av_fin',    'value'=>$hoy,'compare'=>'>='],
        ],
    ]);

    if ($avisos) {
        $av   = $avisos[0];
        $img  = get_post_meta($av->ID,'er_av_img',true);
        $url  = get_post_meta($av->ID,'er_av_url',true);
        $cli  = get_post_meta($av->ID,'er_av_cliente',true);
        $clics= (int)get_post_meta($av->ID,'er_av_clics',true);

        if ($img) {
            return '<a href="'.esc_url($url?:'#').'" target="_blank" rel="noopener" class="er-ad-link" data-aviso-id="'.$av->ID.'" data-url="'.esc_url($url).'"><img src="'.esc_url($img).'" alt="'.esc_attr($cli).'" loading="lazy"><span class="er-ad-clics">👆'.$clics.'</span></a>';
        }
        return '<div class="er-ad-fallback" data-aviso-id="'.$av->ID.'" data-url="'.esc_url($url).'"><span>📢 '.esc_html($cli).'</span><span class="ad-sub">Pos. '.$pos.' · '.esc_html($lbl).'</span></div>';
    }

    // Imagen predeterminada de aviso vencido
    $venc = get_posts(['post_type'=>'aviso_pub','post_status'=>'publish','numberposts'=>1,
        'meta_query'=>[['key'=>'er_av_pos','value'=>(string)$pos],['key'=>'er_av_img_def','compare'=>'EXISTS']],
    ]);
    if ($venc) {
        $def = get_post_meta($venc[0]->ID,'er_av_img_def',true);
        if ($def) return '<img src="'.esc_url($def).'" alt="Imagen predeterminada" style="width:100%;height:100%;object-fit:cover;opacity:.65" loading="lazy">';
    }

    // Placeholder
    return '<div class="er-ad-fallback"><span style="font-size:1.1rem">📢</span><span>Tu aviso acá</span><span class="ad-sub">Pos. '.$pos.' · '.esc_html($lbl).'</span></div>';
});

/* ══════════════════════════════════════
   9. HELPERS
══════════════════════════════════════ */
function er_cat_color($slug) {
    return [
        'politica'=>'#c8102e','salud'=>'#16a34a','agro'=>'#a16207',
        'sindical'=>'#1d4ed8','educacion'=>'#7c3aed','cultura'=>'#db2777',
        'social'=>'#0891b2','economia'=>'#ea580c',
    ][$slug] ?? '#777';
}
function er_cat_nombre($slug) {
    return [
        'politica'=>'Política','salud'=>'Salud','agro'=>'Agro',
        'sindical'=>'Sindical','educacion'=>'Educación','cultura'=>'Cultura',
        'social'=>'Social','economia'=>'Economía',
    ][$slug] ?? ucfirst($slug);
}
function er_badge($post_id) {
    $e = get_post_meta($post_id,'er_estado',true)?:'pendiente';
    $c = ['revisado'=>'er-badge-revisado','pendiente'=>'er-badge-pendiente','digitalizar'=>'er-badge-digitalizar'];
    $l = ['revisado'=>'Revisado','pendiente'=>'Pendiente','digitalizar'=>'Digitalizar'];
    return '<span class="er-card-badge '.($c[$e]??'er-badge-pendiente').'">'.($l[$e]??ucfirst($e)).'</span>';
}

/* ══════════════════════════════════════
   10. NAV MENUS
══════════════════════════════════════ */
add_action('init', function() {
    register_nav_menus(['er-principal' => 'Navegación principal El Rufino']);
});

/* ══════════════════════════════════════
   11. WIDGETS
══════════════════════════════════════ */
add_action('widgets_init', function() {
    register_sidebar([
        'name'          => 'Sidebar El Rufino',
        'id'            => 'er-sidebar',
        'before_widget' => '<div class="er-widget" id="%1$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="er-widget-titulo">',
        'after_title'   => '</div>',
    ]);
});

/* ══════════════════════════════════════
   12. PRECOMPLETAR POSICIÓN EN NUEVO AVISO
══════════════════════════════════════ */
add_action('admin_footer', function() {
    if (!isset($_GET['vdi_pos'])) return;
    $pos = intval($_GET['vdi_pos']);
    echo '<script>document.addEventListener("DOMContentLoaded",function(){var s=document.querySelector("select[name=er_av_pos]");if(s)s.value='.$pos.';});</script>';
});

/* ══════════════════════════════════════
   13. FLUSH REWRITE AL ACTIVAR
══════════════════════════════════════ */
add_action('after_switch_theme', 'flush_rewrite_rules');

/* ══════════════════════════════════════
   HELPER GLOBAL: COLOR PARA CATEGORÍAS NATIVAS
══════════════════════════════════════ */
if (!function_exists('er_get_cat_color')) {
    function er_get_cat_color($slug) {
        $map = [
            'actualidad'       => '#c8102e',
            'seguimiento'      => '#1d4ed8',
            'poder-y-gestion'  => '#7c3aed',
            'poder_y_gestion'  => '#7c3aed',
            'barrio-a-barrio'  => '#16a34a',
            'barrio_a_barrio'  => '#16a34a',
            'el-campo-habla'   => '#a16207',
            'el_campo_habla'   => '#a16207',
            'rufino-en-datos'  => '#0891b2',
            'rufino_en_datos'  => '#0891b2',
            'sobre-el-rufino'  => '#555',
            // CPT
            'politica'=>'#c8102e','salud'=>'#16a34a','agro'=>'#a16207',
            'sindical'=>'#1d4ed8','educacion'=>'#7c3aed','cultura'=>'#db2777',
            'social'=>'#0891b2','economia'=>'#ea580c',
        ];
        return $map[$slug] ?? '#c8102e';
    }
}
