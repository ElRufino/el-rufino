<?php
/**
 * Plugin Name: El Rufino Demo Content
 * Description: Crea o actualiza automáticamente un pack inicial de 5 contenidos demo para El Rufino.
 * Version: 1.0.0
 * Author: Proyecto El Rufino
 */

if (!defined('ABSPATH')) {
    exit;
}

class ElRufinoDemoContent {
    const OPTION_VERSION = 'er_demo_content_version';
    const VERSION = '1.0.0';
    const NONCE_ACTION = 'er_demo_content_seed';

    public static function init() {
        register_activation_hook(__FILE__, array(__CLASS__, 'activate'));
        add_action('admin_menu', array(__CLASS__, 'register_tools_page'));
        add_action('admin_post_er_demo_content_seed', array(__CLASS__, 'handle_manual_seed'));
        add_action('admin_notices', array(__CLASS__, 'maybe_show_notice'));
    }

    public static function activate() {
        self::seed_content();
        update_option(self::OPTION_VERSION, self::VERSION);
        set_transient('er_demo_content_activated', 1, 60);
        flush_rewrite_rules();
    }

    public static function register_tools_page() {
        add_management_page(
            'El Rufino Demo',
            'El Rufino Demo',
            'manage_options',
            'el-rufino-demo-content',
            array(__CLASS__, 'render_tools_page')
        );
    }

    public static function render_tools_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $posts = self::get_demo_posts();
        ?>
        <div class="wrap">
            <h1>El Rufino · Contenidos demo</h1>
            <p>Este módulo crea o actualiza automáticamente un pack inicial de 5 entradas demo para poblar la portada y las secciones base del medio.</p>
            <p><strong>Comportamiento:</strong> si una entrada ya existe por su slug, se actualiza; si no existe, se crea. No duplica contenidos.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field(self::NONCE_ACTION); ?>
                <input type="hidden" name="action" value="er_demo_content_seed">
                <p>
                    <button type="submit" class="button button-primary">Cargar / actualizar contenidos demo</button>
                </p>
            </form>
            <hr>
            <h2>Entradas incluidas</h2>
            <ol>
                <?php foreach ($posts as $post) : ?>
                    <li><strong><?php echo esc_html($post['title']); ?></strong> <code><?php echo esc_html($post['slug']); ?></code></li>
                <?php endforeach; ?>
            </ol>
        </div>
        <?php
    }

    public static function handle_manual_seed() {
        if (!current_user_can('manage_options')) {
            wp_die('No autorizado.');
        }
        check_admin_referer(self::NONCE_ACTION);
        self::seed_content();
        wp_safe_redirect(add_query_arg(array(
            'page' => 'el-rufino-demo-content',
            'er_demo_seeded' => '1',
        ), admin_url('tools.php')));
        exit;
    }

    public static function maybe_show_notice() {
        if (get_transient('er_demo_content_activated')) {
            delete_transient('er_demo_content_activated');
            echo '<div class="notice notice-success is-dismissible"><p><strong>El Rufino Demo Content:</strong> se creó o actualizó el pack inicial de 5 contenidos demo.</p></div>';
        }

        if (isset($_GET['page'], $_GET['er_demo_seeded']) && $_GET['page'] === 'el-rufino-demo-content') {
            echo '<div class="notice notice-success is-dismissible"><p><strong>El Rufino Demo Content:</strong> los contenidos demo fueron cargados o actualizados correctamente.</p></div>';
        }
    }

    public static function seed_content() {
        $author_id = get_current_user_id();
        if (!$author_id) {
            $users = get_users(array('role__in' => array('administrator'), 'number' => 1, 'fields' => array('ID')));
            $author_id = !empty($users) ? (int) $users[0]->ID : 1;
        }

        $categories = self::ensure_categories();
        $posts = self::get_demo_posts();

        foreach ($posts as $post) {
            $post_id = self::upsert_post($post, $author_id, $categories);
            if ($post_id) {
                update_post_meta($post_id, '_er_demo_content', 1);
                update_post_meta($post_id, '_er_demo_content_version', self::VERSION);
            }
        }
    }

    private static function ensure_categories() {
        $names = array(
            'Actualidad',
            'Poder y gestión',
            'Barrio a barrio',
            'El campo habla',
            'Rufino en datos',
        );

        $map = array();
        foreach ($names as $name) {
            $term = term_exists($name, 'category');
            if (!$term) {
                $term = wp_insert_term($name, 'category');
            }
            if (!is_wp_error($term)) {
                $term_id = is_array($term) ? (int) $term['term_id'] : (int) $term;
                $map[$name] = $term_id;
            }
        }
        return $map;
    }

    private static function upsert_post($data, $author_id, $categories) {
        $existing = get_page_by_path($data['slug'], OBJECT, 'post');

        $postarr = array(
            'post_title'   => $data['title'],
            'post_name'    => $data['slug'],
            'post_excerpt' => $data['excerpt'],
            'post_content' => $data['content'],
            'post_status'  => 'publish',
            'post_type'    => 'post',
            'post_author'  => $author_id,
        );

        if ($existing) {
            $postarr['ID'] = $existing->ID;
            $post_id = wp_update_post(wp_slash($postarr), true);
        } else {
            $post_id = wp_insert_post(wp_slash($postarr), true);
        }

        if (is_wp_error($post_id) || !$post_id) {
            return 0;
        }

        if (isset($categories[$data['category']])) {
            wp_set_post_categories($post_id, array($categories[$data['category']]));
        }

        if (!empty($data['tags'])) {
            wp_set_post_tags($post_id, $data['tags'], false);
        }

        return (int) $post_id;
    }

    private static function get_demo_posts() {
        return array(
            array(
                'title' => 'Rufino: qué temas concentran hoy la conversación pública local',
                'slug' => 'rufino-temas-conversacion-publica-local',
                'category' => 'Actualidad',
                'tags' => array('Rufino', 'actualidad', 'conversación pública', 'agenda local', 'redes'),
                'excerpt' => 'Entre reclamos por rutas, seguridad, obras y falta de oportunidades para los jóvenes, la conversación pública de Rufino muestra patrones bastante claros. Ordenarlos es el primer paso para entender qué preocupa, qué moviliza y qué se repite.',
                'content' => self::content_actualidad(),
            ),
            array(
                'title' => 'Promesas, anuncios y obras: por qué Rufino necesita un registro público de seguimiento',
                'slug' => 'rufino-registro-publico-seguimiento-promesas-obras',
                'category' => 'Poder y gestión',
                'tags' => array('seguimiento', 'promesas', 'obras', 'gestión', 'política local'),
                'excerpt' => 'En la ciudad abundan los anuncios, pero muchas veces falta una memoria ordenada de qué se prometió, cuándo se dijo y qué pasó después. Un registro público no resuelve los problemas, pero sí mejora algo clave: la capacidad de hacer seguimiento.',
                'content' => self::content_gestion(),
            ),
            array(
                'title' => 'Barrio Norte: infraestructura, memoria del reclamo y deudas que siguen abiertas',
                'slug' => 'barrio-norte-infraestructura-memoria-reclamo-rufino',
                'category' => 'Barrio a barrio',
                'tags' => array('Barrio Norte', 'infraestructura', 'reclamos', 'agua', 'obras'),
                'excerpt' => 'Hablar de Barrio Norte en Rufino no es hablar solo de una zona de la ciudad. Es hablar de una memoria de reclamos que vuelve una y otra vez: agua, calles, drenaje, mantenimiento e infraestructura urbana.',
                'content' => self::content_barrios(),
            ),
            array(
                'title' => 'Rutas, costos y producción: por qué el agro sigue siendo una audiencia desatendida',
                'slug' => 'rutas-costos-produccion-agro-audiencia-desatendida',
                'category' => 'El campo habla',
                'tags' => array('campo', 'agro', 'rutas', 'producción', 'economía regional'),
                'excerpt' => 'Rufino forma parte de un corredor productivo donde el agro no es un tema secundario. Sin embargo, en el ecosistema mediático local casi nunca aparece como audiencia central, sino como telón de fondo o como sector al que se menciona sin profundidad.',
                'content' => self::content_campo(),
            ),
            array(
                'title' => 'Rufino en números: una base mínima para leer la ciudad con más claridad',
                'slug' => 'rufino-en-numeros-base-minima-lectura-ciudad',
                'category' => 'Rufino en datos',
                'tags' => array('datos', 'Rufino', 'población', 'hogares', 'audiencia'),
                'excerpt' => 'Población, hogares, plataformas y escala urbana: antes de opinar sobre todo, conviene ordenar algunos datos básicos. No dicen todo sobre la ciudad, pero ayudan a discutir mejor.',
                'content' => self::content_datos(),
            ),
        );
    }

    private static function content_actualidad() {
        return <<<HTML
<p>Rufino tiene una conversación pública intensa, pero dispersa. Una parte ocurre en Facebook, otra en WhatsApp, otra en radios, otra en charlas cotidianas. Cuando se mira todo junto, aparecen temas dominantes que se repiten más de lo que parece.</p>
<h2>Una agenda local que vuelve sobre los mismos ejes</h2>
<p>Entre los asuntos que más se instalan están el estado de las rutas y la conectividad vial, la seguridad y los hechos policiales, los anuncios de obras y su cumplimiento real, los problemas de agua, cloacas e infraestructura, la situación del SAMCO y la salud pública, y el empleo junto con la sensación de estancamiento entre los jóvenes.</p>
<ul>
<li>Rutas y conectividad vial</li>
<li>Seguridad y hechos policiales</li>
<li>Obras anunciadas y obras efectivamente realizadas</li>
<li>Agua, cloacas e infraestructura</li>
<li>Salud pública y atención local</li>
<li>Empleo y horizonte juvenil</li>
</ul>
<h2>El problema no es solo qué se dice, sino cómo queda fragmentado</h2>
<p>La conversación suele quedar partida entre posteos sueltos, comentarios, programas de radio, capturas, reenvíos y rumores. Eso vuelve difícil sostener memoria sobre un tema, distinguir entre lo urgente y lo estructural, y saber qué hechos se repiten de verdad y cuáles son coyunturales.</p>
<h2>Por qué importa ordenar esta agenda</h2>
<p>Entender la conversación pública no es un lujo analítico. Es una herramienta para detectar qué temas se anuncian mucho y se siguen poco, qué problemas tienen raíz territorial y qué preocupaciones atraviesan a distintos sectores de la ciudad. En un medio local, ordenar es una forma de empezar a explicar.</p>
HTML;
    }

    private static function content_gestion() {
        return <<<HTML
<p>Rufino no necesita más volumen de anuncios. Necesita más trazabilidad. Cada vez que se comunica una obra, una mejora o una solución, se activa una mezcla conocida de expectativa y escepticismo. El problema no es solo político: también es informativo.</p>
<h2>Sin registro, cada promesa vuelve a empezar de cero</h2>
<p>Cuando no existe una memoria ordenada, cada anuncio parece nuevo aunque tenga antecedentes, modificaciones o demoras acumuladas. Eso debilita la conversación pública y también debilita la capacidad de control ciudadano.</p>
<h2>Qué debería registrar un seguimiento básico</h2>
<ul>
<li>Fecha del anuncio</li>
<li>Autoridad o actor que lo hizo</li>
<li>Qué se prometió exactamente</li>
<li>Plazo o etapa declarada</li>
<li>Estado actual</li>
<li>Última revisión</li>
</ul>
<h2>Qué cambia para un medio local</h2>
<p>Un registro público modifica la lógica de cobertura. En lugar de publicar un anuncio y seguir de largo, el medio puede volver sobre el mismo tema con preguntas simples pero decisivas: ¿hubo avance?, ¿se frenó?, ¿cambió el plazo?, ¿se reformuló?, ¿quedó en nada?</p>
<p>El seguimiento no reemplaza la gestión, pero sí mejora la calidad de la conversación pública. Y para un medio local, puede transformarse en una marca de identidad.</p>
HTML;
    }

    private static function content_barrios() {
        return <<<HTML
<p>Hablar de Barrio Norte en Rufino no es hablar solo de una zona de la ciudad. Es hablar de una memoria de reclamos que vuelve una y otra vez: agua, calles, drenaje, mantenimiento e infraestructura urbana.</p>
<h2>Los problemas no se distribuyen igual en toda la ciudad</h2>
<p>Algunos sectores acumulan más tiempo, más desgaste y más promesas pendientes. Cada lluvia, cada obra demorada y cada reclamo por mantenimiento reactivan una conversación que no empieza de nuevo: simplemente vuelve a aparecer porque nunca terminó de resolverse.</p>
<h2>Los ejes que más se repiten</h2>
<ul>
<li>Drenaje y escurrimiento</li>
<li>Estado de calles</li>
<li>Mantenimiento urbano</li>
<li>Necesidad de obras sostenidas</li>
<li>Falta de respuestas de largo plazo</li>
</ul>
<h2>Qué debería hacer una cobertura barrial seria</h2>
<p>La cobertura barrial no debería limitarse a “hubo reclamo”. Tiene que poder responder qué reclamo es nuevo, cuál es histórico, qué se prometió, qué se ejecutó y qué sigue sin resolverse. Mirar barrio por barrio no fragmenta la ciudad: la vuelve más visible.</p>
HTML;
    }

    private static function content_campo() {
        return <<<HTML
<p>Rufino forma parte de un corredor productivo donde el agro no es un tema secundario. Sin embargo, en el ecosistema mediático local casi nunca aparece como audiencia central, sino como telón de fondo o como sector al que se menciona sin profundidad.</p>
<h2>Hablar del campo no es repetir slogans</h2>
<p>Hablar del campo en serio no es publicar una foto de cosecha ni repetir el precio de un grano. Es conectar producción, rutas, logística, costos, política y vida local. Y en esa conexión hay una de las mayores vacancias editoriales del ecosistema de medios de Rufino.</p>
<h2>Las cinco dimensiones del tema</h2>
<ul>
<li>Estado de rutas y accesos</li>
<li>Costos logísticos</li>
<li>Valor de la producción</li>
<li>Impacto de decisiones nacionales</li>
<li>Relación entre campo y ciudad</li>
</ul>
<h2>Una cobertura exigente y útil</h2>
<p>Un tratamiento serio de este eje implica leer datos, escuchar productores, observar el territorio y evitar tanto la caricatura anti-campo como la complacencia automática. Si ningún medio local toma al agro como audiencia real, hay una oportunidad clara. Pero también una exigencia: cubrirlo con seriedad y contexto, no con lugares comunes.</p>
HTML;
    }

    private static function content_datos() {
        return <<<HTML
<p>Población, hogares, plataformas y escala urbana: antes de opinar sobre todo, conviene ordenar algunos datos básicos. No dicen todo sobre la ciudad, pero ayudan a discutir mejor.</p>
<h2>Una escala suficiente para una conversación intensa</h2>
<p>Rufino no es una metrópoli, pero tampoco una aldea. Tiene una escala suficiente para que la conversación pública sea intensa, visible y repetitiva. Eso exige una lectura más precisa de cómo circula la información y qué temas concentran más atención.</p>
<h2>Base mínima para empezar a mirar la ciudad</h2>
<ul>
<li>Población aproximada</li>
<li>Cantidad estimada de hogares</li>
<li>Fuerte peso de Facebook en información local</li>
<li>Centralidad de WhatsApp como distribución informal</li>
<li>Importancia de rutas y seguridad como temas de alta intensidad</li>
</ul>
<h2>Qué permiten estos datos</h2>
<p>Estos números sirven para dimensionar el ecosistema local, entender por qué ciertas plataformas pesan más que otras, justificar un medio con foco hiperlocal y bajar el debate de la intuición a una base más legible. Los datos no reemplazan la interpretación, pero vuelven la discusión menos frágil.</p>
HTML;
    }
}

ElRufinoDemoContent::init();
