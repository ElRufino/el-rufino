<?php
/*
Plugin Name: El Rufino - Control Panel v4.3
Description: Dashboard inmersivo (Fullscreen) y Motor de Base de Datos para Promesas.
Version: 4.3.0
Author: El Rufino
*/

if (!defined('ABSPATH')) exit;

/**
 * 1. MOTOR DE BASE DE DATOS - Creación de tabla de Promesas
 */
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'er_promesas';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        fecha datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        funcionario varchar(100) NOT NULL,
        promesa text NOT NULL,
        estado varchar(20) DEFAULT 'pendiente' NOT NULL,
        evidencia_url varchar(255) DEFAULT '',
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

/**
 * 2. OCULTAR INTERFAZ NATIVA DE WORDPRESS (FORZADO FULLSCREEN)
 */
add_action('admin_head', function() {
    if (isset($_GET['page']) && $_GET['page'] === 'el-rufino-panel') {
        echo '
        <style>
            /* Ocultar toda la UI de WordPress */
            #adminmenuback, #adminmenuwrap, #wpadminbar, #wpfooter,
            #adminmenu, .wp-responsive-overlay,
            .update-nag, .notice, #screen-meta-links,
            #screen-meta, .screen-meta-toggle { display: none !important; }

            /* Reset del layout de WP admin */
            html, body { overflow: hidden !important; margin: 0 !important; padding: 0 !important; }
            html.wp-toolbar { padding-top: 0 !important; }
            #wpcontent, #wpbody, #wpbody-content {
                margin: 0 !important;
                padding: 0 !important;
                float: none !important;
            }
            #wpwrap { display: block !important; }

            /* Panel fullscreen sobre todo */
            #el-rufino-fullscreen {
                position: fixed;
                top: 0; left: 0;
                width: 100vw; height: 100vh;
                z-index: 99999;
                overflow: hidden;
                background: #f5f0e8;
            }
        </style>';
    }
});

/**
 * 2b. REDIRIGIR AL PANEL AL ACTIVAR EL PLUGIN
 */
register_activation_hook(__FILE__, function() {
    add_option('el_rufino_do_redirect', true);
});

add_action('admin_init', function() {
    if (get_option('el_rufino_do_redirect', false)) {
        delete_option('el_rufino_do_redirect');
        wp_redirect(admin_url('admin.php?page=el-rufino-panel'));
        exit;
    }
});

/**
 * 3. MENÚ Y RENDERIZADO
 */
add_action('admin_menu', function(){
    add_menu_page('El Rufino', 'El Rufino v4', 'manage_options', 'el-rufino-panel', 'render_er_panel', 'dashicons-database-view', 2);
});

function render_er_panel() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'er_promesas';
    $conteo_promesas = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");

    echo '<div id="el-rufino-fullscreen">';
    ?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Source+Serif+4:wght@300;400;600&family=JetBrains+Mono:wght@400;700&display=swap');

        /* RESET COMPLETO — neutraliza herencia de WP admin */
        #el-rufino-fullscreen * {
            box-sizing: border-box !important;
            -webkit-text-fill-color: unset !important;
        }
        #el-rufino-fullscreen a,
        #el-rufino-fullscreen a:visited,
        #el-rufino-fullscreen a:hover { text-decoration: none !important; }

        /* PANEL */
        #el-rufino-fullscreen .er-wrap { 
            height: 100vh !important; width: 100vw !important; display: flex !important; 
            background: #f5f0e8 !important; font-family: 'Source Serif 4', serif !important;
            overflow: hidden !important; color: #1a1a1a !important;
            margin: 0 !important; padding: 0 !important;
        }

        /* SIDEBAR */
        #el-rufino-fullscreen .er-side { 
            width: 260px !important; min-width: 260px !important;
            background: #1a1a1a !important; color: #d1d1d1 !important; 
            padding: 40px 25px !important; display: flex !important;
            flex-direction: column !important; gap: 10px !important;
        }
        #el-rufino-fullscreen .er-logo { 
            font-family: 'Playfair Display', serif !important; 
            color: #f5f0e8 !important; font-size: 24px !important; 
            font-weight: 900 !important; margin-bottom: 30px !important;
            background: none !important;
        }
        #el-rufino-fullscreen .er-logo span { color: #c0271b !important; }

        #el-rufino-fullscreen .er-nav-label { 
            font-family: 'JetBrains Mono', monospace !important; 
            font-size: 10px !important; text-transform: uppercase !important; 
            color: #666 !important; margin: 20px 0 5px 5px !important;
            background: none !important;
        }
        #el-rufino-fullscreen .er-nav-item { 
            font-family: 'JetBrains Mono', monospace !important; 
            font-size: 12px !important; padding: 10px 15px !important; 
            border-radius: 6px !important; cursor: pointer !important; 
            color: #d1d1d1 !important; display: block !important;
            background: transparent !important; border: none !important;
            margin: 0 !important;
        }
        #el-rufino-fullscreen .er-nav-item:hover { 
            background: #2a2a2a !important; color: #ffffff !important; 
        }
        #el-rufino-fullscreen .er-nav-item.active { 
            background: #c0271b !important; color: #ffffff !important; 
            font-weight: 700 !important; 
        }
        #el-rufino-fullscreen .er-exit { 
            margin-top: auto !important; padding: 12px !important; 
            border: 1px solid #444 !important; color: #888 !important; 
            text-align: center !important; font-size: 10px !important; 
            font-family: 'JetBrains Mono', monospace !important; 
            border-radius: 6px !important; display: block !important;
            background: transparent !important;
        }
        #el-rufino-fullscreen .er-exit:hover { 
            background: #c0271b !important; color: #ffffff !important; 
        }

        /* ÁREA PRINCIPAL */
        #el-rufino-fullscreen .er-main { 
            flex: 1 !important; padding: 60px !important; 
            overflow-y: auto !important; background: #f5f0e8 !important;
        }
        #el-rufino-fullscreen .er-header { 
            max-width: 1100px !important; margin: 0 auto 50px !important; 
            border-bottom: 2px solid #c0271b !important; 
            padding-bottom: 20px !important; display: flex !important; 
            justify-content: space-between !important; align-items: flex-end !important;
            background: none !important;
        }
        #el-rufino-fullscreen .er-header h1 { 
            font-family: 'Playfair Display', serif !important; 
            font-size: 48px !important; margin: 0 !important;
            color: #1a1a1a !important; background: none !important;
        }
        #el-rufino-fullscreen .er-header p {
            color: #666 !important; background: none !important;
        }

        /* CARDS */
        #el-rufino-fullscreen .er-grid { 
            display: grid !important; 
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)) !important; 
            gap: 25px !important; max-width: 1100px !important; margin: 0 auto !important; 
        }
        #el-rufino-fullscreen .er-card { 
            background: #ffffff !important; border: 1px solid #ddd8ce !important; 
            border-radius: 12px !important; padding: 30px !important; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.05) !important;
            color: #1a1a1a !important;
        }
        #el-rufino-fullscreen .er-card h3 { 
            font-family: 'Playfair Display', serif !important; 
            color: #c0271b !important; margin: 0 0 15px 0 !important; 
            font-size: 22px !important; background: none !important;
        }
        #el-rufino-fullscreen .er-card p {
            color: #555 !important; background: none !important;
        }
        #el-rufino-fullscreen .er-badge { 
            display: inline-block !important; background: #eef2f3 !important; 
            color: #444 !important; font-family: 'JetBrains Mono', monospace !important; 
            font-size: 10px !important; padding: 4px 8px !important; 
            border-radius: 4px !important; margin-bottom: 15px !important; 
        }
        #el-rufino-fullscreen .er-stat { 
            font-size: 40px !important; font-weight: 700 !important; 
            font-family: 'JetBrains Mono', monospace !important; 
            color: #1a1a1a !important; background: none !important;
        }
    </style>

    <div class="er-wrap">
        <div class="er-side">
            <div class="er-logo"><span>EL</span> RUFINO</div>
            <div class="er-nav-label">Base</div>
            <a href="#" class="er-nav-item active">Dashboard</a>
            <div class="er-nav-label">Editorial</div>
            <a href="#" class="er-nav-item">Promesas</a>
            <a href="<?php echo admin_url(); ?>" class="er-exit">← SALIR A WORDPRESS</a>
        </div>
        
        <div class="er-main">
            <div class="er-header">
                <div>
                    <h1>Panel El Rufino</h1>
                    <p style="font-family:'JetBrains Mono'; font-size:12px; color: #666; margin-top:10px;">SISTEMA OPERATIVO v4.3 | STATUS: BASE DE DATOS ACTIVA</p>
                </div>
            </div>

            <div class="er-grid">
                <div class="er-card">
                    <span class="er-badge">MÓDULO 10</span>
                    <h3>Promesas Registradas</h3>
                    <div class="er-stat"><?php echo $conteo_promesas; ?></div>
                    <p style="font-size: 12px; color: #888; margin-top: 10px;">Compromisos detectados en Rufino y región.</p>
                </div>

                <div class="er-card">
                    <span class="er-badge">CONFIGURACIÓN</span>
                    <h3>Entorno de Test</h3>
                    <p style="font-family: 'JetBrains Mono'; font-size: 13px;">
                        URL: prueba.infoconectados.com<br>
                        MODO: Fullscreen Canvas
                    </p>
                </div>
            </div>
        </div>
    </div>
    </div><!-- /el-rufino-fullscreen -->
    <?php
}