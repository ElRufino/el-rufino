<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_header() { ?>
    <div class="er-masthead">
        <h1>El Rufino <span class="er-claim">LO QUE PASA Y LO QUE SIGNIFICA</span></h1>
        <div class="er-masthead-badge">● Fase 0 — Reconstrucción</div>
    </div>
<?php }

function er_tabs_nav( $current ) {
    $tabs = [
        'el-rufino'           => 'Resumen',
        'el-rufino-fase-0'    => 'Fase 0',
        'el-rufino-promesas'  => 'Promesas',
        'el-rufino-calendario'=> 'Calendario',
        'el-rufino-redes'     => 'Redes',
        'el-rufino-drive'     => 'Drive',
        'el-rufino-contexto'  => 'Contexto',
        'el-rufino-agentes-ia'=> 'Agentes IA',
    ];
    foreach($tabs as $slug => $label): ?>
        <a href="<?php echo admin_url('admin.php?page=' . $slug); ?>" 
           class="er-tab <?php echo ($current === $slug) ? 'er-tab-active' : ''; ?>">
            <?php echo esc_html($label); ?>
        </a>
    <?php endforeach;
}

function er_get_base_context() {
    // Returns the base context text for seeding
    return file_get_contents( plugin_dir_path( dirname(__FILE__) ) . 'includes/context-base.txt' ) ?: 'Contexto base de El Rufino — medio digital local de Rufino, Santa Fe, Argentina. Claim: Lo que pasa y lo que significa.';
}
