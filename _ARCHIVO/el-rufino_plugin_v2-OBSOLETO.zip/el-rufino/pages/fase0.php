<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_fase0() {
    global $wpdb;

    // Load saved checklist state
    $cl_rows = $wpdb->get_results("SELECT item_key, completado FROM {$wpdb->prefix}er_checklist");
    $cl_state = [];
    foreach($cl_rows as $r) $cl_state[$r->item_key] = (bool)$r->completado;

    // Define checklist sections — ordered by actual workflow
    $sections = [
        'A — Identidad y tema' => [
            'id_logo'       => ['Logo instalado y visible en el header', 'Diseño'],
            'id_colores'    => ['Paleta de colores configurada: rojo #c0271b + negro + blanco + crema', 'Diseño'],
            'id_tipografias'=> ['Tipografías: serif para títulos, sans para cuerpo', 'Diseño'],
            'id_tema'       => ['Tema activo: limpio, rápido, responsive, compatible con plugins', 'Tema'],
            'id_header'     => ['Header con masthead rojo y nombre del medio', 'Diseño'],
            'id_footer'     => ['Footer con info del medio y links configurado', 'Diseño'],
        ],
        'B — Plugins esenciales (en orden)' => [
            'pl_backup'     => ['UpdraftPlus — instalar PRIMERO, configurar backup automático diario', 'Plugin'],
            'pl_seo'        => ['Yoast SEO o Rank Math — instalar y configurar con identidad del medio', 'Plugin'],
            'pl_cache'      => ['Caché/velocidad: WP Rocket, LiteSpeed Cache o W3 Total Cache', 'Plugin'],
            'pl_seguridad'  => ['Seguridad: Wordfence o iThemes Security', 'Plugin'],
            'pl_contacto'   => ['Formulario contacto: Contact Form 7 o WPForms', 'Plugin'],
            'pl_imagenes'   => ['Optimización imágenes: Smush o ShortPixel', 'Plugin'],
            'pl_analytics'  => ['Google Analytics 4 + Google Search Console', 'Analytics'],
            'pl_antispam'   => ['Akismet anti-spam activado', 'Plugin'],
            'pl_ticker'     => ['Breaking news ticker — barra superior', 'Plugin'],
        ],
        'C — Estructura editorial' => [
            'cat_crear'     => ['Categorías editoriales creadas: Actualidad, Seguimiento, Poder y gestión, Barrio a barrio, El campo habla, Rufino en datos', 'Infra'],
            'cat_menu'      => ['Menú de navegación principal configurado con todas las secciones', 'Infra'],
            'cat_home'      => ['Página de inicio: ticker, destacado principal, grilla pilares, bloque seguimiento, bloque WA/suscripción', 'Diseño'],
            'cat_sobre'     => ['Página "Sobre El Rufino" con identidad del medio', 'Infra'],
            'cat_contacto'  => ['Página de contacto con formulario activo', 'Infra'],
        ],
        'D — Infraestructura técnica' => [
            'tec_ssl'       => ['SSL / HTTPS activo y verificado', 'Infra'],
            'tec_sitemap'   => ['Sitemap XML generado y enviado a Search Console', 'SEO'],
            'tec_robots'    => ['robots.txt configurado correctamente', 'SEO'],
            'tec_velocidad' => ['Velocidad de carga menor a 3 segundos verificada', 'Perf'],
            'tec_mobile'    => ['Visualización mobile verificada en Android e iOS', 'Perf'],
            'tec_errores'   => ['Sin errores críticos de PHP en el log — "error crítico" resuelto', 'Infra'],
        ],
        'E — Dominios' => [
            'dom_ar'        => ['elrufino.ar verificado disponible en NIC Argentina', 'Dominio'],
            'dom_ar_reg'    => ['elrufino.ar registrado como dominio principal', 'Dominio'],
            'dom_comar'     => ['elrufino.com.ar registrado (defensivo, redirección 301)', 'Dominio'],
            'dom_redirect'  => ['Redirección configurada desde infoconectados.com.ar al dominio propio', 'Dominio'],
        ],
        'F — Redes y canales' => [
            'red_fb'        => ['Facebook: página @elrufino creada y configurada', 'Social'],
            'red_ig'        => ['Instagram: @elrufino creada y configurada', 'Social'],
            'red_tk'        => ['TikTok: @elrufino creada y configurada', 'Social'],
            'red_wa'        => ['Canal WhatsApp Broadcast "El Rufino" configurado con descripción y horario 7:30 AM', 'WA'],
            'red_bio'       => ['Foto de perfil y bio unificadas en todas las plataformas', 'Social'],
            'red_vinculo'   => ['Todas las redes vinculadas al sitio web', 'Infra'],
            'red_previo'    => ['Post "algo viene" publicado en redes sin revelar qué', 'Social'],
            'red_wa_lista'  => ['Lista pre-suscriptores WhatsApp iniciada (mínimo 20 contactos)', 'WA'],
        ],
        'G — Contenidos pre-lanzamiento' => [
            'cont_plantillas'=> ['Plantillas visuales por tipo: noticia, infografía, Reel, story IG, resumen WA', 'Diseño'],
            'cont_wa_tpl'    => ['Plantilla resumen matutino WhatsApp definida y testeada', 'WA'],
            'cont_tablero'   => ['Tablero editorial configurado: Trello/Notion/Google Sheets', 'Herr.'],
            'cont_protocolo' => ['Protocolo de publicación sensible redactado', 'Editorial'],
            'cont_banco'     => ['Banco de 10 contenidos listos antes del lanzamiento', 'Contenido'],
        ],
    ];

    // Count totals
    $total = 0; $done = 0;
    foreach($sections as $items) {
        foreach($items as $key => $item) {
            $total++;
            if(!empty($cl_state[$key])) $done++;
        }
    }
    $pct = $total ? round($done/$total*100) : 0;

    $tag_colors = [
        'Plugin'=>'blue','Diseño'=>'purple','Infra'=>'gray','SEO'=>'green',
        'Analytics'=>'teal','Perf'=>'orange','Dominio'=>'amber','Social'=>'pink',
        'WA'=>'green','Herr.'=>'gray','Editorial'=>'red','Contenido'=>'teal','Tema'=>'purple',
    ];
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-fase-0'); ?></div>
        <div class="er-body">
            <div class="er-section-title">Fase 0 — Flujo de trabajo ordenado</div>
            <p class="er-desc">Completar en el orden indicado (A → B → C...). WordPress ya está instalado: empezar por la identidad visual, luego plugins, luego estructura.</p>

            <div class="er-progress-row">
                <span>Progreso: <strong id="er-pct-label"><?php echo $pct; ?>%</strong></span>
                <div class="er-pbar"><div class="er-pfill" id="er-pbar-fill" style="width:<?php echo $pct; ?>%"></div></div>
                <span id="er-count-label"><?php echo $done; ?>/<?php echo $total; ?></span>
            </div>

            <button class="er-btn er-btn-secondary" onclick="erCreateCategories()">Crear categorías automáticamente</button>
            <span id="er-cat-msg" style="margin-left:10px;font-size:12px;color:#43a047"></span>

            <div id="er-checklist-wrap" data-total="<?php echo $total; ?>">
            <?php foreach($sections as $section_name => $items): ?>
                <div class="er-checklist-section">
                    <div class="er-checklist-section-title"><?php echo esc_html($section_name); ?></div>
                    <?php foreach($items as $key => $item): 
                        $is_done = !empty($cl_state[$key]);
                        $tag     = $item[1];
                        $color   = $tag_colors[$tag] ?? 'gray';
                    ?>
                    <div class="er-check-item <?php echo $is_done ? 'er-done' : ''; ?>" 
                         data-key="<?php echo esc_attr($key); ?>"
                         onclick="erToggleCheck(this)">
                        <div class="er-checkbox <?php echo $is_done ? 'er-checked' : ''; ?>">
                            <?php if($is_done): ?>✓<?php endif; ?>
                        </div>
                        <span class="er-check-text"><?php echo esc_html($item[0]); ?></span>
                        <span class="er-check-tag er-tag-color-<?php echo $color; ?>"><?php echo esc_html($tag); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            </div>

            <div class="er-section-title" style="margin-top:28px">Semáforo de Fase 0</div>
            <div class="er-sem-detail">
                <div class="er-sem-detail-row">
                    <span class="er-dot er-dot-green"></span>
                    <div><strong>COMPLETO</strong> cuando: sitio online / secciones activas / plugins configurados / redes vinculadas / 10 contenidos listos / canal WA configurado / dominios gestionados</div>
                </div>
                <div class="er-sem-detail-row">
                    <span class="er-dot er-dot-yellow"></span>
                    <div><strong>EN PROCESO</strong> — estado actual. Reconstrucción activa.</div>
                </div>
                <div class="er-sem-detail-row">
                    <span class="er-dot er-dot-red"></span>
                    <div><strong>ALERTA</strong> si al final de la semana 2 hay menos del 50% del checklist completo.</div>
                </div>
            </div>

            <div class="er-section-title" style="margin-top:24px">Error crítico de PHP — diagnóstico</div>
            <div class="er-rule-box">
                <strong>El mensaje "Ha habido un error crítico en este sitio" es de WordPress, no del dashboard.</strong><br><br>
                Causas más comunes: 1) Plugin incompatible activado. 2) Conflicto de PHP. 3) Límite de memoria.<br><br>
                <strong>Pasos para resolverlo:</strong><br>
                1. Ir a <code>elrufino.infoconectados.com.ar/wp-admin/</code> → Plugins → Desactivar el último plugin instalado.<br>
                2. Si persiste: editar <code>wp-config.php</code> y agregar <code>define('WP_DEBUG', true);</code> para ver el error exacto.<br>
                3. En Hostinger: ir al panel → Error logs → Ver el log de PHP más reciente.<br>
                4. El error aparece en el footer pero el admin funciona: generalmente es un widget o shortcode con conflicto.
            </div>
        </div>
    </div>
    <?php
}
