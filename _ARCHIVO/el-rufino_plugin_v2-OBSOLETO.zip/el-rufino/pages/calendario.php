<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_calendario() { ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-calendario'); ?></div>
        <div class="er-body">
            <div class="er-section-title">Calendario semanal tipo</div>
            <div class="er-cal-grid">
                <div class="er-cal-day"><div class="er-cal-dn">Lunes</div><div class="er-cp er-p1">P01 Actualidad</div><div class="er-cp er-p6">P06 Dato local</div></div>
                <div class="er-cal-day"><div class="er-cal-dn">Martes</div><div class="er-cp er-p2">P02 El campo habla</div></div>
                <div class="er-cal-day"><div class="er-cal-dn">Miércoles</div><div class="er-cp er-p4">TikTok / Reel jóvenes</div></div>
                <div class="er-cal-day"><div class="er-cal-dn">Jueves</div><div class="er-cp er-p5">P05 Poder y gestión</div></div>
                <div class="er-cal-day"><div class="er-cal-dn">Viernes</div><div class="er-cp er-p3">P03 Barrio a barrio</div></div>
                <div class="er-cal-day"><div class="er-cal-dn">Sábado</div><div class="er-cp er-p4">P04 Perfil local</div></div>
                <div class="er-cal-day"><div class="er-cal-dn">Domingo</div><div class="er-cp er-p6">Evergreen</div></div>
            </div>
            <div class="er-leyenda">
                <span class="er-cp er-p1">P01 Rufino Real</span>
                <span class="er-cp er-p2">P02 El campo habla</span>
                <span class="er-cp er-p3">P03 Barrio a barrio</span>
                <span class="er-cp er-p4">P04 Generación Rufino</span>
                <span class="er-cp er-p5">P05 Poder y gestión</span>
                <span class="er-cp er-p6">P06 Rufino en datos</span>
            </div>
            <div class="er-section-title">Frecuencia por plataforma</div>
            <table class="er-table">
                <thead><tr><th>Plataforma</th><th>Frecuencia</th><th>Horario clave</th><th>Audiencia core</th><th>KPI mes 6</th></tr></thead>
                <tbody>
                    <tr><td>Facebook</td><td>3–5 posts/día</td><td>8AM · 12PM · 7PM</td><td>25–60 años</td><td>5.000 likes · ER >3%</td></tr>
                    <tr><td>Instagram</td><td>1 post + 3–5 stories/día</td><td>11AM · 7PM (stories)</td><td>18–40 · mujeres 25–45</td><td>2.000 seg. · ER >5%</td></tr>
                    <tr><td><strong>WhatsApp Canal</strong></td><td><strong>1 mensaje/día — SIN FALLAR</strong></td><td><strong>7:30 AM</strong></td><td>Toda la audiencia</td><td>500 suscriptores · apertura >60%</td></tr>
                    <tr><td>TikTok</td><td>3–4 videos/semana (60–90 seg)</td><td>Miércoles + 1</td><td>14–30 años</td><td>1.000 seg. · 1 viral día 60</td></tr>
                </tbody>
            </table>
            <div class="er-section-title" style="margin-top:20px">Plantilla resumen matutino WhatsApp — 7:30 AM</div>
            <div class="er-code-block">Buenos días Rufino. Las 3 noticias de hoy:

[1] [TÍTULO BREVE Y CONCRETO]
[2] [TÍTULO BREVE Y CONCRETO]
[3] [TÍTULO BREVE Y CONCRETO]

→ Leé todo en elrufino.ar</div>
        </div>
    </div>
<?php }

function er_render_redes() {
    $plataformas = [
        ['name'=>'Facebook','icon'=>'f','color'=>'#1877f2','meta'=>'Meta mes 6: 5.000 likes · ER >3%','desc'=>'3–5 posts/día · Canal principal de credibilidad · Audiencia 25–60','pct'=>0,'priority'=>false],
        ['name'=>'Instagram','icon'=>'IG','color'=>'#e1306c','meta'=>'Meta mes 6: 2.000 seguidores · ER >5%','desc'=>'1 post + 3–5 stories/día · Reels explicativos · Mujeres 25–45','pct'=>0,'priority'=>false],
        ['name'=>'WhatsApp Canal','icon'=>'WA','color'=>'#25d366','meta'=>'Meta mes 3: 500 suscriptores · apertura >60%','desc'=>'7:30 AM todos los días — sin excepción','pct'=>0,'priority'=>true],
        ['name'=>'TikTok','icon'=>'TK','color'=>'#111','meta'=>'Meta mes 4: 1.000 seguidores · 1 viral antes del día 60','desc'=>'3–4 videos/semana · 60–90 seg · CANCHA VACÍA en Rufino','pct'=>0,'priority'=>false],
    ];
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-redes'); ?></div>
        <div class="er-body">
            <div class="er-section-title">Estado de plataformas y KPIs</div>
            <div class="er-plat-grid">
            <?php foreach($plataformas as $p): ?>
                <div class="er-plat-card <?php echo $p['priority'] ? 'er-plat-priority' : ''; ?>">
                    <div class="er-plat-header">
                        <div class="er-plat-icon" style="background:<?php echo $p['color']; ?>"><?php echo $p['icon']; ?></div>
                        <div>
                            <div class="er-plat-name"><?php echo esc_html($p['name']); ?></div>
                            <div class="er-plat-meta"><?php echo esc_html($p['meta']); ?></div>
                        </div>
                    </div>
                    <?php if($p['priority']): ?>
                    <div class="er-plat-priority-label">⚠ MÁXIMA PRIORIDAD</div>
                    <?php endif; ?>
                    <div class="er-plat-desc"><?php echo esc_html($p['desc']); ?></div>
                    <div class="er-pbar" style="margin-top:8px"><div class="er-pfill" style="width:<?php echo $p['pct']; ?>%"></div></div>
                </div>
            <?php endforeach; ?>
            </div>
            <div class="er-section-title">Competencia — mapa de brechas</div>
            <table class="er-table">
                <thead><tr><th>Medio</th><th>FB likes</th><th>Fortaleza</th><th>Brecha que explotamos</th></tr></thead>
                <tbody>
                    <tr><td><strong>Sucesos</strong></td><td>29.731</td><td>Breaking news, velocidad</td><td>Sin contexto, sin campo agropecuario, sin seguimiento</td></tr>
                    <tr><td>FM Rufino 106.3</td><td>28.712</td><td>Audiencia 45+, radio</td><td>No nativo digital. Sin IG/TikTok</td></tr>
                    <tr><td>La Tribuna del Sur</td><td>19.327</td><td>Tradición local</td><td>Sin seguimiento de promesas</td></tr>
                    <tr><td>Municipalidad</td><td>17.983</td><td>Canal oficial</td><td>No cubre a los vecinos</td></tr>
                    <tr><td>Rufino Web</td><td>10.634</td><td>Única en Instagram</td><td>Sin TikTok, sin análisis</td></tr>
                </tbody>
            </table>
        </div>
    </div>
<?php }

function er_render_drive() { ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-drive'); ?></div>
        <div class="er-body">
            <div class="er-section-title">Estructura de archivo — Google Drive</div>
            <div class="er-btn-row">
                <button class="er-btn er-btn-primary" onclick="erCopyDriveStructure()">Copiar estructura completa</button>
            </div>
            <div class="er-drive-grid">
                <?php
                $folders = [
                    ['01_SITIO_WEB','📁','Temas · plugins · credenciales · backups · capturas · documentación técnica'],
                    ['02_CONTENIDOS','📁','P01–P06 por pilar · borradores · publicados · banco de notas'],
                    ['03_IMAGENES','📁','Fotos propias · stock · logos · infografías · plantillas Canva por plataforma'],
                    ['04_REDES_SOCIALES','📁','FB · IG · TikTok · WA · publicado-archivo · métricas mensuales'],
                    ['05_SEGUIMIENTO_PROMESAS','📁','Base de datos (Sheets) · capturas anuncios · historial · informes mensuales'],
                    ['06_COMERCIAL','📁','Propuestas anunciantes · paquetes sponsoreo · contratos · anunciantes activos'],
                    ['07_EDITORIAL','📁','Manual de tono · protocolos · tablero editorial (Sheets) · guías de estilo'],
                    ['08_DATOS_LOCALES','📁','INDEC · presupuesto municipal · estadísticas propias · fuentes agropecuarias'],
                    ['09_MULTIMEDIA','📁','Videos brutos · exportados · audios · grabaciones entrevistas · edición'],
                ];
                foreach($folders as $f): ?>
                <div class="er-drive-folder">
                    <div class="er-drive-icon"><?php echo $f[1]; ?></div>
                    <div class="er-drive-name"><?php echo esc_html($f[0]); ?></div>
                    <div class="er-drive-meta"><?php echo esc_html($f[2]); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="er-section-title" style="margin-top:20px">Convenciones de nombres de archivo</div>
            <div class="er-code-block">Notas:        AAAA-MM-DD_P01_slug-titulo.docx
Imágenes:     AAAA-MM-DD_FB_descripcion-breve.jpg
Promesas:     PROM-001_AAAA-MM-DD_quien_tema.xlsx
Videos TK:    AAAA-MM-DD_TK_tema_v1.mp4
Plantillas:   TEMPLATE_IG_post-noticia_v2.psd
Resumen WA:   AAAA-MM-DD_WA_resumen-matutino.txt</div>
        </div>
    </div>
<?php }
