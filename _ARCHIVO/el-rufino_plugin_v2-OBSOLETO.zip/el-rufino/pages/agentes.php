<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_agentes() {
    global $wpdb;
    $contexto_activo = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}er_contexto WHERE activo=1");
    $ctx_snippet = $contexto_activo 
        ? substr($contexto_activo->contenido, 0, 200) . '...' 
        : '[Sin contexto activo — ir a la pestaña Contexto para subir uno]';

    $agents = er_get_agent_definitions();
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-agentes-ia'); ?></div>
        <div class="er-body">
            <div class="er-section-title">Sistema de agentes IA</div>
            <p class="er-desc">Cada agente tiene un rol específico. Hacé clic en "Copiar prompt" para obtener el mensaje completo con el contexto activo incluido. Pegalo en Claude, GPT-4 o cualquier asistente IA para ejecutar la tarea.</p>

            <?php if(!$contexto_activo): ?>
            <div class="er-alert" style="margin-bottom:16px">
                <span class="er-tag er-tag-urgente">ATENCIÓN</span>
                No hay contexto activo. 
                <a href="<?php echo admin_url('admin.php?page=el-rufino-contexto'); ?>">Ir a Contexto →</a>
            </div>
            <?php endif; ?>

            <div class="er-agents-grid">
            <?php foreach($agents as $agent): ?>
                <div class="er-agent-card">
                    <div class="er-agent-header">
                        <span class="er-agent-icon"><?php echo $agent['icon']; ?></span>
                        <div>
                            <div class="er-agent-name"><?php echo esc_html($agent['nombre']); ?></div>
                            <div class="er-agent-role"><?php echo esc_html($agent['rol']); ?></div>
                        </div>
                    </div>
                    <div class="er-agent-desc"><?php echo esc_html($agent['descripcion']); ?></div>
                    <div class="er-agent-output">
                        <strong>Entrega:</strong> <?php echo esc_html($agent['entrega']); ?>
                    </div>
                    <button class="er-btn er-btn-primary er-btn-full" 
                            onclick="erCopyAgentPrompt('<?php echo esc_js($agent['id']); ?>')">
                        Copiar prompt completo →
                    </button>
                </div>
            <?php endforeach; ?>
            </div>

            <!-- Prompt viewer -->
            <div class="er-modal-overlay" id="er-modal-prompt" style="display:none">
                <div class="er-modal er-modal-large">
                    <h3 id="er-prompt-title">Prompt para agente</h3>
                    <p style="font-size:12px;color:var(--er-text2);margin-bottom:12px">Copiá este texto completo y pegalo en Claude, GPT-4 o cualquier asistente IA:</p>
                    <textarea id="er-prompt-content" rows="16" style="width:100%;font-size:12px;font-family:monospace;padding:12px;border:1px solid var(--er-border);border-radius:6px;background:var(--er-bg2);color:var(--er-text);resize:vertical"></textarea>
                    <div class="er-modal-footer">
                        <button class="er-btn er-btn-secondary" onclick="erCloseModal('er-modal-prompt')">Cerrar</button>
                        <button class="er-btn er-btn-primary" onclick="erCopyFromPromptModal()">Copiar al portapapeles</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    var erContextoActivo = <?php echo json_encode($contexto_activo ? $contexto_activo->contenido : ''); ?>;
    var erAgents = <?php echo json_encode($agents); ?>;

    function erCopyAgentPrompt(agentId) {
        var agent = erAgents.find(function(a){ return a.id === agentId; });
        if(!agent) return;
        var ctx = erContextoActivo || '[CONTEXTO NO DISPONIBLE — subir contexto en la pestaña Contexto]';
        var prompt = agent.prompt_template.replace('{{CONTEXTO}}', ctx);
        document.getElementById('er-prompt-title').textContent = 'Prompt: ' + agent.nombre;
        document.getElementById('er-prompt-content').value = prompt;
        erOpenModal('er-modal-prompt');
    }

    function erCopyFromPromptModal() {
        var ta = document.getElementById('er-prompt-content');
        ta.select();
        document.execCommand('copy');
        var btn = document.querySelector('#er-modal-prompt .er-btn-primary');
        var orig = btn.textContent;
        btn.textContent = '✓ Copiado';
        setTimeout(function(){ btn.textContent = orig; }, 2000);
    }
    </script>
    <?php
}

function er_get_agent_definitions() {
    return [
        [
            'id'          => 'configurador_yoast',
            'icon'        => '⚙',
            'nombre'      => 'Agente: Configurador SEO',
            'rol'         => 'Especialista en configuración de Yoast SEO / Rank Math',
            'descripcion' => 'Toma el contexto del medio y genera la configuración óptima de Yoast SEO o Rank Math: título del sitio, descripción, metadata, redes sociales, schema, y todas las opciones editoriales.',
            'entrega'     => 'Lista paso a paso de configuración con los valores exactos a ingresar en cada campo del plugin.',
            'prompt_template' => "Sos un experto en SEO técnico y en configuración de WordPress para medios digitales latinoamericanos.\n\nA continuación tenés el contexto completo de El Rufino, un medio digital local de Rufino, Santa Fe, Argentina:\n\n---\n{{CONTEXTO}}\n---\n\nTu tarea es generar la configuración completa y óptima para Yoast SEO (o Rank Math si se prefiere).\n\nEntregá:\n1. Título del sitio y descripción meta (exactamente como deben aparecer en el campo)\n2. Configuración de Open Graph para Facebook e Instagram (título, descripción, imagen por defecto)\n3. Schema.org: tipo de organización, nombre, URL, logo\n4. Configuración de Twitter/X card\n5. Opciones de indexación: qué páginas indexar y cuáles no\n6. Estructura de breadcrumbs\n7. Configuración del sitemap XML\n8. Redirecciones recomendadas\n9. Palabras clave semilla para cada sección editorial\n\nSé concreto: entregá los valores exactos, no explicaciones generales.",
        ],
        [
            'id'          => 'generador_categorias',
            'icon'        => '🗂',
            'nombre'      => 'Agente: Generador de categorías y entradas',
            'rol'         => 'Arquitecto de contenido editorial',
            'descripcion' => 'Lee el contexto del medio y genera las categorías editoriales con sus descripciones, y las primeras entradas (posts) para cada categoría, listas para importar en WordPress.',
            'entrega'     => 'Lista de categorías con slugs y descripciones + 3 borradores de entradas por categoría en formato WordPress.',
            'prompt_template' => "Sos un editor digital especializado en medios locales argentinos.\n\nA continuación tenés el contexto completo de El Rufino:\n\n---\n{{CONTEXTO}}\n---\n\nTu tarea es generar la arquitectura editorial completa para WordPress.\n\nEntregá:\n\n1. CATEGORÍAS (mínimo las definidas en el contexto, podés sugerir adicionales si el contexto lo justifica):\n   - Nombre de la categoría\n   - Slug (URL amigable, sin acentos, en minúsculas)\n   - Descripción (2-3 oraciones: qué cubre, para qué audiencia, qué tipo de cobertura)\n   - Categoría padre (si corresponde)\n\n2. ENTRADAS BASE (3 por categoría):\n   - Título (aplicando la regla de 2 capas: lo que pasó + lo que significa)\n   - Bajada (2-3 oraciones)\n   - Esquema del contenido (bullets con los puntos que debe desarrollar)\n   - Categoría asignada\n   - Tags sugeridos\n   - Nota al editor (qué hace que esta nota sea diferente a lo que ya existe)\n\n3. ENTRADAS EVERGREEN (5 entradas que no tienen fecha de vencimiento):\n   - Estas deben funcionar como puertas de entrada al medio para nuevos lectores\n   - Ejemplo: 'Qué es El Rufino y por qué lo hacemos', 'Cómo funciona nuestro seguimiento de promesas'\n\nAplicá siempre el tono editorial definido en el contexto: directo, verificado, humano.",
        ],
        [
            'id'          => 'configurador_tema',
            'icon'        => '🎨',
            'nombre'      => 'Agente: Configurador de tema visual',
            'rol'         => 'Diseñador WordPress especializado en medios digitales',
            'descripcion' => 'Toma la identidad visual del medio (colores, tipografías, estructura) y genera el código PHP/CSS del tema hijo y las instrucciones exactas de configuración del Customizer.',
            'entrega'     => 'Código del tema hijo (functions.php + style.css) + instrucciones paso a paso del Customizer.',
            'prompt_template' => "Sos un desarrollador WordPress especializado en medios de comunicación digitales.\n\nA continuación tenés el contexto completo de El Rufino:\n\n---\n{{CONTEXTO}}\n---\n\nIdentidad visual definida:\n- Color principal: #c0271b (rojo)\n- Colores de soporte: negro (#1a1a1a), blanco (#ffffff), crema (#f5f0e8)\n- Tipografía títulos: serif (Georgia, Playfair Display o similar)\n- Tipografía cuerpo: sans-serif limpio\n- Header: masthead rojo con nombre del medio en blanco\n- Estilo: periodismo clásico, diario, editorial\n\nTu tarea es entregar:\n\n1. style.css del tema hijo (con todos los comentarios de cabecera de WordPress requeridos)\n2. functions.php del tema hijo con:\n   - Enqueue correcto del tema padre\n   - Tipografías de Google Fonts\n   - Soporte para menús de navegación\n   - Tamaños de imágenes para el medio\n   - Funciones de limpieza del head\n3. CSS personalizado para:\n   - Header con masthead rojo\n   - Breaking news ticker\n   - Grilla de artículos por sección\n   - Bloque de suscripción WhatsApp\n   - Footer con columnas de secciones\n   - Cards de artículos (imagen, categoría, título, bajada)\n   - Responsive mobile-first\n4. Instrucciones exactas del Customizer (Apariencia > Personalizar): qué configurar en cada sección\n\nEl sitio tiene 70%+ de tráfico mobile. Priorizar velocidad y legibilidad.",
        ],
        [
            'id'          => 'planificador_semanal',
            'icon'        => '📅',
            'nombre'      => 'Agente: Planificador editorial semanal',
            'rol'         => 'Editor de planificación de contenidos',
            'descripcion' => 'Genera el calendario editorial completo para la próxima semana: títulos concretos, plataforma, pilar, formato, audiencia target y segunda capa de cada pieza.',
            'entrega'     => 'Calendario completo en tabla con 7 días, 3-5 piezas por día, listo para copiar al tablero editorial.',
            'prompt_template' => "Sos el editor de planificación de El Rufino, un medio digital local de Rufino, Santa Fe, Argentina.\n\nContexto del medio:\n\n---\n{{CONTEXTO}}\n---\n\nTu tarea es generar el calendario editorial para la próxima semana.\n\nPara CADA pieza entregá:\n- Día y fecha\n- Plataforma: Sitio web / Facebook / Instagram / TikTok / WhatsApp\n- Pilar editorial (P01 a P06)\n- Título completo (aplicando la regla de 2 capas)\n- CAPA 1: Lo que pasó (el hecho)\n- CAPA 2: Lo que significa / el contexto que falta\n- Formato: nota larga / hilo FB / Reel / TikTok / infografía / resumen WA\n- Audiencia target: cuál de los 4 segmentos definidos en el contexto\n- Fuentes sugeridas: con quién hablar o qué consultar\n- Tiempo estimado de producción\n\nReglas obligatorias:\n- Lunes: P01 + P06 (actualidad + dato)\n- Martes: P02 (campo)\n- Miércoles: TikTok/Reel jóvenes\n- Jueves: P05 (poder y gestión)\n- Viernes: P03 (barrio a barrio)\n- Al menos 1 nota larga en el sitio por semana\n- Resumen WA todos los días a las 7:30 AM\n- Sin segunda capa = no se publica\n\nActivá los temas con mayor volumen de conversación del contexto: rutas, seguridad, política local, inundaciones.",
        ],
        [
            'id'          => 'redactor_nota',
            'icon'        => '✍',
            'nombre'      => 'Agente: Redactor de nota periodística',
            'rol'         => 'Periodista de El Rufino',
            'descripcion' => 'Redacta una nota completa en el tono editorial del medio. Recibe el tema y produce la nota con las dos capas obligatorias, título, bajada, cuerpo y cierre.',
            'entrega'     => 'Nota completa lista para publicar: título, bajada, cuerpo (600-1000 palabras), tags sugeridos.',
            'prompt_template' => "Sos el periodista principal de El Rufino, un medio digital local de Rufino, Santa Fe, Argentina.\n\nContexto del medio y tono editorial:\n\n---\n{{CONTEXTO}}\n---\n\nTu tarea es redactar una nota periodística completa.\n\n[COMPLETAR: describí el tema a cubrir, el hecho concreto que ocurrió, y cualquier dato o fuente que tengas]\n\nLa nota debe:\n1. Aplicar la REGLA DE LAS DOS CAPAS:\n   - CAPA 1: Lo que pasó (el hecho verificado)\n   - CAPA 2: Lo que significa / el contexto que falta / la pregunta que nadie hizo\n\n2. Estructura:\n   - Título: directo, sin clickbait, con la segunda capa implícita\n   - Bajada: 2-3 oraciones que responden qué/quién/cuándo + por qué importa\n   - Cuerpo: entre 600 y 1000 palabras\n   - Cierre: qué viene ahora, qué hay que seguir\n\n3. Tono: directo sin ser agresivo / verificado / local sin ser localista / humano sin ser amarillista\n\n4. NUNCA: burocrático / sensacionalista / comunicado sin contexto / lenguaje técnico innecesario\n\n5. Si hay datos: citarlos con fuente. Si algo no está confirmado: aclararlo con 'Según...' o 'Hasta ahora lo que se sabe es...'\n\n6. Al final: sugerir tags, categoría asignada, y nota al editor sobre el seguimiento.",
        ],
        [
            'id'          => 'guionista_tiktok',
            'icon'        => '🎬',
            'nombre'      => 'Agente: Guionista TikTok/Reels',
            'rol'         => 'Creador de contenido para redes sociales',
            'descripcion' => 'Genera guiones de 60-90 segundos para TikTok e Instagram Reels. Formatos: "¿Sabías que en Rufino...?", explicadores locales, historias de vecinos. Voz auténtica, sin formalidad.',
            'entrega'     => 'Guion completo con texto a cámara, indicaciones visuales, texto en pantalla y hashtags.',
            'prompt_template' => "Sos el creador de contenido de El Rufino para TikTok e Instagram Reels.\n\nContexto del medio:\n\n---\n{{CONTEXTO}}\n---\n\nTu tarea es escribir un guion completo para un video de 60-90 segundos.\n\n[COMPLETAR: indicá el tema o el dato local que querés contar]\n\nFormato del guion:\n\nHOOK (0-5 seg): La primera frase que detiene el scroll. Opción A: pregunta directa. Opción B: dato sorprendente. Opción C: problema reconocible.\n\nDESARROLLO (5-70 seg):\n- Texto a cámara (exactamente lo que se dice)\n- Indicaciones visuales entre corchetes: [mostrar mapa] [texto en pantalla] [imagen de archivo]\n- Texto en pantalla (qué aparece sobreimpreso)\n\nCIERRE (70-90 seg): llamada a la acción. Opción: comentar, seguir, enviar a alguien que lo viva.\n\nREGLAS:\n- Voz auténtica, como habla un rufineño, no como locutor\n- Sin 'hola chicos' ni lenguaje corporativo\n- Usar datos del contexto cuando sea posible\n- Recordar: TikTok en Rufino es territorio virgen — cada video puede ser el primero en ese tema\n- Target: 14-30 años pero que lo entiendan todos\n- Hashtags: 5-7, mezcla local + temático\n\nEntregá también: miniatura sugerida (texto + imagen) y mejor horario de publicación.",
        ],
        [
            'id'          => 'seguimiento_promesas',
            'icon'        => '🔍',
            'nombre'      => 'Agente: Nota de seguimiento de promesas',
            'rol'         => 'Periodista de investigación y accountability',
            'descripcion' => 'Toma el registro de promesas y genera una nota de seguimiento del tipo "¿Qué pasó con lo que prometieron?". El diferenciador más potente del medio.',
            'entrega'     => 'Nota completa lista para publicar + versión corta para hilo de Facebook + resumen para WhatsApp.',
            'prompt_template' => "Sos el periodista de accountability de El Rufino.\n\nContexto del medio:\n\n---\n{{CONTEXTO}}\n---\n\nRegistro de promesas:\n[COMPLETAR: pegá aquí las promesas del registro que querés incluir en la nota]\n\nTu tarea es redactar:\n\n1. NOTA PRINCIPAL (600-800 palabras) para el sitio web:\n   - Título del tipo: '¿Qué pasó con [promesa]? [Tiempo] después, la respuesta'\n   - Por cada promesa: qué se prometió exactamente / fecha / cuándo se cumplía / qué pasó realmente\n   - Usar el protocolo: 'Según la versión oficial...' cuando no está verificado\n   - Cerrar con pregunta abierta al lector\n\n2. HILO DE FACEBOOK (5-7 posts cortos):\n   - Post 1: hook (la promesa más llamativa)\n   - Posts 2-5: una promesa por post con estado actual\n   - Post final: '¿Qué querés que sigamos?'\n\n3. RESUMEN WHATSAPP (máx 3 líneas):\n   - Para el resumen matutino de las 7:30 AM\n\nTono: verificador, no opositor. El objetivo es el registro, no el ataque. Usar siempre fechas y fuentes. La narrativa dominante de Rufino es 'el gobierno promete y no cumple' — este seguimiento es el antídoto al rumor, no su aliado.",
        ],
    ];
}
