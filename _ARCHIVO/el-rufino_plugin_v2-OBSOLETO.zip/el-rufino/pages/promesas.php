<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_promesas() {
    global $wpdb;
    $promesas = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}er_promesas ORDER BY fecha DESC");
    $next_id  = $wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}er_promesas") + 1;
    $next_codigo = 'PROM-' . str_pad($next_id, 3, '0', STR_PAD_LEFT);

    $estado_labels = [
        'pendiente'  => ['label'=>'Pendiente','class'=>'pen'],
        'proceso'    => ['label'=>'En proceso','class'=>'proc'],
        'cumplida'   => ['label'=>'Cumplida','class'=>'done'],
        'incumplida' => ['label'=>'Incumplida','class'=>'bro'],
        'abandonada' => ['label'=>'Abandonada','class'=>'bro'],
    ];
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-promesas'); ?></div>
        <div class="er-body">
            <div class="er-section-title">Registro público de promesas municipales</div>
            <p class="er-desc">Cada anuncio registrado con fecha, quién lo hizo, qué prometió exactamente. Seguimiento a 30 y 90 días. Esta es la herramienta de diferenciación más potente del medio.</p>

            <div class="er-btn-row">
                <button class="er-btn er-btn-primary" onclick="erOpenModal('er-modal-promesa')">+ Nueva promesa</button>
                <button class="er-btn er-btn-secondary" onclick="erExportCSV()">Exportar CSV</button>
            </div>

            <div class="er-table-wrap">
                <table class="er-table" id="er-promesas-table">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Fecha</th>
                            <th>Quién</th>
                            <th>Promesa</th>
                            <th>Plataforma</th>
                            <th>Seg. 30d</th>
                            <th>Estado</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="er-promesas-body">
                    <?php if(empty($promesas)): ?>
                        <tr><td colspan="8" class="er-empty">
                            Sin promesas registradas.<br>
                            <a href="#" onclick="erLoadEjemplos();return false;">Cargar 3 ejemplos para empezar →</a>
                        </td></tr>
                    <?php else: ?>
                        <?php foreach($promesas as $p): 
                            $e = $estado_labels[$p->estado] ?? ['label'=>$p->estado,'class'=>'pen'];
                        ?>
                        <tr>
                            <td><strong><?php echo esc_html($p->codigo); ?></strong></td>
                            <td><?php echo esc_html($p->fecha); ?></td>
                            <td><?php echo esc_html($p->quien); ?></td>
                            <td class="er-td-promesa"><?php echo esc_html($p->promesa); ?></td>
                            <td><?php echo esc_html($p->plataforma); ?></td>
                            <td><?php echo esc_html($p->seg_30 ?: '—'); ?></td>
                            <td><span class="er-status er-status-<?php echo $e['class']; ?>"><?php echo $e['label']; ?></span></td>
                            <td>
                                <button class="er-btn-icon" onclick="erEditPromesa(<?php echo $p->id; ?>)">✏</button>
                                <button class="er-btn-icon er-btn-del" onclick="erDeletePromesa(<?php echo $p->id; ?>)">✕</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="er-note">
                Campos: código · fecha · quién · promesa exacta · plataforma · seguimiento 30d · seguimiento 90d · estado (pendiente / en proceso / cumplida / incumplida / abandonada)
            </div>
        </div>
    </div>

    <!-- Modal nueva/editar promesa -->
    <div class="er-modal-overlay" id="er-modal-promesa" style="display:none">
        <div class="er-modal">
            <h3 id="er-modal-title">Nueva promesa</h3>
            <input type="hidden" id="er-form-id" value="">
            <div class="er-form-group">
                <label>Código</label>
                <input type="text" id="er-form-codigo" value="<?php echo esc_attr($next_codigo); ?>">
            </div>
            <div class="er-form-group">
                <label>Quién lo prometió</label>
                <input type="text" id="er-form-quien" placeholder="Ej: Intendente Lattanzi">
            </div>
            <div class="er-form-group">
                <label>Fecha del anuncio</label>
                <input type="date" id="er-form-fecha" value="<?php echo date('Y-m-d'); ?>">
            </div>
            <div class="er-form-group">
                <label>Promesa exacta (palabras textuales)</label>
                <textarea id="er-form-promesa" rows="3" placeholder="Transcribir las palabras exactas..."></textarea>
            </div>
            <div class="er-form-group">
                <label>Plataforma / medio</label>
                <select id="er-form-plataforma">
                    <option value="">— Seleccionar —</option>
                    <option>Facebook oficial</option>
                    <option>Conferencia de prensa</option>
                    <option>Nota en medio local</option>
                    <option>Acto público</option>
                    <option>WhatsApp / comunicado</option>
                    <option>Entrevista radial</option>
                    <option>Otro</option>
                </select>
            </div>
            <div class="er-form-group">
                <label>Seguimiento 30 días</label>
                <textarea id="er-form-seg30" rows="2" placeholder="¿Qué pasó a los 30 días?"></textarea>
            </div>
            <div class="er-form-group">
                <label>Seguimiento 90 días</label>
                <textarea id="er-form-seg90" rows="2" placeholder="¿Qué pasó a los 90 días?"></textarea>
            </div>
            <div class="er-form-group">
                <label>Estado</label>
                <select id="er-form-estado">
                    <option value="pendiente">Pendiente seguimiento</option>
                    <option value="proceso">En proceso</option>
                    <option value="cumplida">Cumplida</option>
                    <option value="incumplida">Incumplida</option>
                    <option value="abandonada">Abandonada</option>
                </select>
            </div>
            <div class="er-modal-footer">
                <button class="er-btn er-btn-secondary" onclick="erCloseModal('er-modal-promesa')">Cancelar</button>
                <button class="er-btn er-btn-primary" onclick="erSavePromesa()">Guardar promesa</button>
            </div>
        </div>
    </div>

    <script>
    var erPromesasData = <?php echo json_encode($promesas); ?>;
    </script>
    <?php
}
