<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_contexto() {
    global $wpdb;
    $contextos = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}er_contexto ORDER BY created_at DESC");
    $activo    = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}er_contexto WHERE activo=1");
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-contexto'); ?></div>
        <div class="er-body">
            <div class="er-section-title">Gestor de contexto editorial</div>
            <p class="er-desc">El contexto es la base de conocimiento del medio. Todos los agentes IA trabajan sobre él. Podés subir versiones actualizadas del contexto y elegir cuál está activo.</p>

            <div class="er-two-col">
                <div>
                    <div class="er-section-title" style="margin-top:0">Contextos guardados</div>
                    <div id="er-contextos-list">
                    <?php if(empty($contextos)): ?>
                        <p class="er-empty">Sin contextos guardados.</p>
                    <?php else: ?>
                        <?php foreach($contextos as $ctx): ?>
                        <div class="er-context-item <?php echo $ctx->activo ? 'er-context-active' : ''; ?>">
                            <div class="er-context-header">
                                <strong><?php echo esc_html($ctx->nombre); ?></strong>
                                <?php if($ctx->activo): ?>
                                    <span class="er-tag er-tag-editorial">ACTIVO</span>
                                <?php endif; ?>
                            </div>
                            <div class="er-context-meta">
                                <?php echo esc_html(date('d/m/Y H:i', strtotime($ctx->created_at))); ?> — 
                                <?php echo number_format(strlen($ctx->contenido)); ?> caracteres
                            </div>
                            <div class="er-context-actions">
                                <?php if(!$ctx->activo): ?>
                                <button class="er-btn er-btn-secondary er-btn-sm" onclick="erSetActiveContext(<?php echo $ctx->id; ?>)">Activar</button>
                                <?php endif; ?>
                                <button class="er-btn er-btn-secondary er-btn-sm" onclick="erCopyContext(<?php echo $ctx->id; ?>)">Copiar texto</button>
                                <button class="er-btn er-btn-secondary er-btn-sm" onclick="erViewContext(<?php echo $ctx->id; ?>)">Ver</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </div>
                </div>

                <div>
                    <div class="er-section-title" style="margin-top:0">Subir nuevo contexto</div>
                    <div class="er-form-group">
                        <label>Nombre / versión</label>
                        <input type="text" id="er-ctx-nombre" placeholder="Ej: Contexto El Rufino v2.0 — Abril 2026">
                    </div>
                    <div class="er-form-group">
                        <label>Contenido del contexto</label>
                        <textarea id="er-ctx-contenido" rows="12" placeholder="Pegá aquí el texto completo del contexto actualizado..."></textarea>
                    </div>
                    <button class="er-btn er-btn-primary" onclick="erSaveContext()">Guardar y activar</button>
                </div>
            </div>

            <!-- Viewer modal -->
            <div class="er-modal-overlay" id="er-modal-ctx-view" style="display:none">
                <div class="er-modal er-modal-large">
                    <h3 id="er-ctx-view-title">Contexto</h3>
                    <pre id="er-ctx-view-content" style="white-space:pre-wrap;font-size:12px;max-height:500px;overflow-y:auto;background:var(--er-bg2);padding:12px;border-radius:6px;border:1px solid var(--er-border)"></pre>
                    <div class="er-modal-footer">
                        <button class="er-btn er-btn-secondary" onclick="erCloseModal('er-modal-ctx-view')">Cerrar</button>
                        <button class="er-btn er-btn-primary" onclick="erCopyFromViewer()">Copiar todo</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    var erContextosData = <?php echo json_encode(array_map(function($c){
        return ['id'=>$c->id,'nombre'=>$c->nombre,'contenido'=>$c->contenido,'activo'=>(bool)$c->activo];
    }, $contextos)); ?>;
    </script>
    <?php
}
