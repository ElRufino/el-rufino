<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_main() {
    global $wpdb;
    $promesas_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}er_promesas");
    $wa_subs        = get_option('er_wa_suscriptores', 0);
    $fase_actual    = get_option('er_fase_actual', 0);
    $fase_estado    = json_decode(get_option('er_fase_estado', '{}'), true);

    $checklist_done = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}er_checklist WHERE completado=1");
    $checklist_total = 35;
    $pct = $checklist_total > 0 ? round($checklist_done / $checklist_total * 100) : 0;

    $sem_labels = ['f0'=>'Fase 0','f1'=>'Fase 1','f2'=>'Fase 2','f3'=>'Fase 3'];
    $sem_descs  = [
        'f0'=>'Infraestructura técnica — reconstrucción activa',
        'f1'=>'Lanzamiento — pendiente cierre Fase 0',
        'f2'=>'Hábito editorial — espera Fase 1',
        'f3'=>'Monetización — horizonte mes 4–6',
    ];
    $sem_colors = ['proceso'=>'yellow','pendiente'=>'red','completo'=>'green','alerta'=>'red'];
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>

        <div class="er-tabs">
            <?php er_tabs_nav('el-rufino'); ?>
        </div>

        <div class="er-body">

            <div class="er-section-title">Estado general del proyecto</div>
            <div class="er-metrics">
                <div class="er-metric er-amber">
                    <div class="er-metric-val">Fase <?php echo esc_html($fase_actual); ?></div>
                    <div class="er-metric-label">Etapa actual</div>
                    <div class="er-metric-sub">Reconstrucción</div>
                </div>
                <div class="er-metric er-red">
                    <div class="er-metric-val"><?php echo $pct; ?>%</div>
                    <div class="er-metric-label">Avance Fase 0</div>
                    <div class="er-metric-sub"><?php echo $checklist_done; ?>/<?php echo $checklist_total; ?> tareas</div>
                </div>
                <div class="er-metric">
                    <div class="er-metric-val er-editable" data-option="er_wa_suscriptores" data-value="<?php echo esc_attr($wa_subs); ?>"><?php echo esc_html($wa_subs); ?></div>
                    <div class="er-metric-label">Suscriptores WA</div>
                    <div class="er-metric-sub">Meta sem 1: 50</div>
                </div>
                <div class="er-metric">
                    <div class="er-metric-val"><?php echo esc_html($promesas_count); ?></div>
                    <div class="er-metric-label">Promesas registradas</div>
                    <div class="er-metric-sub">Iniciar hoy</div>
                </div>
            </div>

            <div class="er-section-title">Semáforos de fase</div>
            <div class="er-semaphore-grid">
                <?php foreach($sem_labels as $key => $label): 
                    $estado = $fase_estado[$key] ?? 'pendiente';
                    $color  = $sem_colors[$estado] ?? 'red';
                ?>
                <div class="er-sem-card">
                    <span class="er-dot er-dot-<?php echo $color; ?>"></span>
                    <strong><?php echo esc_html($label); ?></strong>
                    <p><?php echo esc_html($sem_descs[$key]); ?></p>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="er-section-title">Prioridades críticas activas</div>
            <div class="er-alerts">
                <div class="er-alert"><span class="er-tag er-tag-urgente">URGENTE</span> Construir lista de suscriptores de WhatsApp — tarea más urgente.</div>
                <div class="er-alert"><span class="er-tag er-tag-urgente">URGENTE</span> Registrar la primera promesa municipal con fecha y quién la hizo.</div>
                <div class="er-alert"><span class="er-tag er-tag-tecnico">TÉCNICO</span> UpdraftPlus activo desde día 1 — backup automático para que no vuelva a pasar lo del servidor.</div>
                <div class="er-alert"><span class="er-tag er-tag-editorial">EDITORIAL</span> Nota inaugural: 2 capas obligatorias. Sin segunda capa no se publica.</div>
                <div class="er-alert"><span class="er-tag er-tag-editorial">EDITORIAL</span> Banco de 10 contenidos listos antes del primer post público.</div>
            </div>

            <div class="er-section-title">Actualizar métricas</div>
            <div class="er-form-inline">
                <label>Suscriptores WhatsApp: <input type="number" id="er-wa-input" value="<?php echo esc_attr($wa_subs); ?>" min="0" style="width:80px"></label>
                <button class="er-btn er-btn-primary" onclick="erSaveOption('er_wa_suscriptores', document.getElementById('er-wa-input').value)">Guardar</button>
            </div>

            <div class="er-section-title" style="margin-top:24px">Regla central</div>
            <div class="er-rule-box">
                <strong>Cada pieza tiene DOS CAPAS:</strong> (1) Lo que pasó + (2) Lo que significa. Sin segunda capa, no se publica.<br><br>
                <strong>Ventaja competitiva:</strong> Contexto · Seguimiento de promesas · Campo agropecuario · TikTok virgen<br>
                <strong>Dominio objetivo:</strong> elrufino.ar · <strong>URL actual:</strong> elrufino.infoconectados.com.ar
            </div>
        </div>
    </div>
    <?php
}
