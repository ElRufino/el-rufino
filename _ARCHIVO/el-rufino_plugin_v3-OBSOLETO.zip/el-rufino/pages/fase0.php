<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function er_render_fase0() {
    global $wpdb;

    $cl_rows = $wpdb->get_results("SELECT item_key, completado FROM {$wpdb->prefix}er_checklist");
    $cl_state = [];
    foreach($cl_rows as $r) $cl_state[$r->item_key] = (bool)$r->completado;

    // Context for agent prompts
    $contexto_activo = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}er_contexto WHERE activo=1");
    $ctx_content = $contexto_activo ? $contexto_activo->contenido : '';

    // Sections: key => [ title, items[], agent_id|null, agent_label|null, section_note|null ]
    $sections = [
        'A' => [
            'title'  => 'Identidad y tema',
            'agent'  => 'configurador_tema',
            'agent_label' => 'Agente 3 — Instrucciones de diseño y Customizer',
            'agent_hint'  => 'El agente entrega el CSS del tema hijo + los valores exactos para configurar el Customizer. No necesitás completar nada extra.',
            'items'  => [
                'id_logo'       => ['Logo instalado y visible en el header', 'Diseño'],
                'id_colores'    => ['Paleta configurada: rojo #c0271b + negro + blanco + crema', 'Diseño'],
                'id_tipografias'=> ['Tipografías: serif para títulos, sans para cuerpo', 'Diseño'],
                'id_tema'       => ['Tema activo: limpio, rápido, responsive, compatible con plugins', 'Tema'],
                'id_header'     => ['Header con masthead rojo y nombre del medio', 'Diseño'],
                'id_footer'     => ['Footer con info del medio y links configurado', 'Diseño'],
            ],
        ],
        'B' => [
            'title'  => 'Plugins esenciales (en orden)',
            'agent'  => 'configurador_yoast',
            'agent_label' => 'Agente 1 — Configuración completa de Yoast SEO',
            'agent_hint'  => 'Una vez instalado Yoast o Rank Math, usá este agente para obtener los valores exactos de cada campo. No necesitás completar nada extra.',
            'items'  => [
                'pl_backup'     => ['UpdraftPlus — instalar PRIMERO, backup automático diario', 'Plugin'],
                'pl_seo'        => ['Yoast SEO o Rank Math — instalar. Configurar con el Agente 1.', 'Plugin'],
                'pl_cache'      => ['Caché: LiteSpeed Cache (gratis, recomendado para Hostinger)', 'Plugin'],
                'pl_seguridad'  => ['Seguridad: Wordfence o iThemes Security', 'Plugin'],
                'pl_contacto'   => ['Formulario contacto: Contact Form 7 o WPForms', 'Plugin'],
                'pl_imagenes'   => ['Optimización imágenes: Smush o ShortPixel', 'Plugin'],
                'pl_analytics'  => ['Google Analytics 4 + Google Search Console conectados', 'Analytics'],
                'pl_antispam'   => ['Akismet anti-spam activado', 'Plugin'],
                'pl_ticker'     => ['Breaking news ticker — barra superior', 'Plugin'],
            ],
        ],
        'C' => [
            'title'  => 'Estructura editorial',
            'agent'  => 'generador_categorias',
            'agent_label' => 'Agente 2 — Categorías con descripciones + 3 notas por sección',
            'agent_hint'  => 'El agente genera los slugs, descripciones y primeras entradas de cada sección. No necesitás completar nada extra.',
            'items'  => [
                'cat_crear'     => ['Categorías editoriales creadas (o usá el botón Crear automáticamente)', 'Infra'],
                'cat_menu'      => ['Menú de navegación configurado con todas las secciones', 'Infra'],
                'cat_home'      => ['Inicio: ticker, destacado principal, grilla pilares, bloque WA', 'Diseño'],
                'cat_sobre'     => ['Página "Sobre El Rufino" con identidad del medio', 'Infra'],
                'cat_contacto'  => ['Página de contacto con formulario activo', 'Infra'],
            ],
        ],
        'D' => [
            'title'  => 'Infraestructura técnica',
            'agent'  => null,
            'items'  => [
                'tec_ssl'       => ['SSL / HTTPS activo y verificado', 'Infra'],
                'tec_sitemap'   => ['Sitemap XML generado y enviado a Search Console', 'SEO'],
                'tec_robots'    => ['robots.txt configurado correctamente', 'SEO'],
                'tec_velocidad' => ['Velocidad de carga menor a 3 segundos (probar en PageSpeed)', 'Perf'],
                'tec_mobile'    => ['Visualización mobile verificada en Android e iOS', 'Perf'],
            ],
        ],
        'E' => [
            'title'  => 'Dominios',
            'agent'  => null,
            'items'  => [
                'dom_ar'        => ['elrufino.ar disponible en nic.ar', 'Dominio'],
                'dom_ar_reg'    => ['elrufino.ar registrado como dominio principal', 'Dominio'],
                'dom_comar'     => ['elrufino.com.ar registrado (defensivo, redirección 301)', 'Dominio'],
                'dom_redirect'  => ['Redirección configurada desde infoconectados.com.ar', 'Dominio'],
            ],
        ],
        'F' => [
            'title'  => 'Redes y canales',
            'agent'  => null,
            'items'  => [
                'red_fb'        => ['Facebook: página @elrufino creada y configurada', 'Social'],
                'red_ig'        => ['Instagram: @elrufino creada y configurada', 'Social'],
                'red_tk'        => ['TikTok: @elrufino creada y configurada', 'Social'],
                'red_wa'        => ['Canal WhatsApp Broadcast "El Rufino" — descripción + horario 7:30 AM', 'WA'],
                'red_bio'       => ['Foto de perfil y bio unificadas en todas las plataformas', 'Social'],
                'red_previo'    => ['Post "algo viene" publicado en redes sin revelar qué', 'Social'],
                'red_wa_lista'  => ['Lista pre-suscriptores WhatsApp iniciada (mínimo 20 contactos)', 'WA'],
            ],
        ],
        'G' => [
            'title'  => 'Contenidos pre-lanzamiento',
            'agent'  => 'planificador_semanal',
            'agent_label' => 'Agente 4 — Calendario editorial completo para la semana',
            'agent_hint'  => 'El agente genera 7 días de contenido con títulos, plataforma, formato y segunda capa. No necesitás completar nada extra.',
            'items'  => [
                'cont_plantillas'=> ['Plantillas visuales por tipo: noticia, infografía, Reel, story IG, resumen WA', 'Diseño'],
                'cont_wa_tpl'    => ['Plantilla resumen matutino WhatsApp definida y testeada', 'WA'],
                'cont_tablero'   => ['Tablero editorial configurado: Trello / Notion / Google Sheets', 'Herr.'],
                'cont_protocolo' => ['Protocolo de publicación sensible redactado', 'Editorial'],
                'cont_banco'     => ['Banco de 10 contenidos listos antes del lanzamiento público', 'Contenido'],
            ],
        ],
    ];

    $total = 0; $done = 0;
    foreach($sections as $items) {
        foreach($items['items'] as $key => $item) {
            $total++;
            if(!empty($cl_state[$key])) $done++;
        }
    }
    $pct = $total ? round($done/$total*100) : 0;

    $tag_colors = [
        'Plugin'=>'blue','Diseño'=>'purple','Infra'=>'gray','SEO'=>'green',
        'Analytics'=>'teal','Perf'=>'orange','Dominio'=>'amber','Social'=>'pink',
        'WA'=>'green','Herr.'=>'gray','Editorial'=>'red','Contenido'=>'teal','Tema'=>'purple',
    ];

    // Get agent definitions for prompt copy
    $agents_raw = er_get_agent_definitions();
    $agents_map = [];
    foreach($agents_raw as $a) $agents_map[$a['id']] = $a;
    ?>
    <div class="er-wrap">
        <?php er_header(); ?>
        <div class="er-tabs"><?php er_tabs_nav('el-rufino-fase-0'); ?></div>
        <div class="er-body">

            <div class="er-progress-row">
                <strong>Fase 0 — Progreso: <span id="er-pct-label"><?php echo $pct; ?>%</span></strong>
                <div class="er-pbar"><div class="er-pfill" id="er-pbar-fill" style="width:<?php echo $pct; ?>%"></div></div>
                <span id="er-count-label"><?php echo $done; ?>/<?php echo $total; ?> completadas</span>
            </div>

            <?php if(!$contexto_activo): ?>
            <div class="er-alert" style="margin-bottom:14px">
                <span class="er-tag er-tag-tecnico">INFO</span>
                Sin contexto activo — los botones de agente copiarán el prompt sin contexto. <a href="<?php echo admin_url('admin.php?page=el-rufino-contexto'); ?>">Subir contexto →</a>
            </div>
            <?php endif; ?>

            <p class="er-desc">Completar en orden A → G. Hacé clic en el encabezado de cada sección para expandirla. Cada sección tiene el agente IA correspondiente para ejecutar esa tarea.</p>

            <div id="er-checklist-wrap" data-total="<?php echo $total; ?>">
            <?php
            $default_open = ['A','B','C'];
            foreach($sections as $sec_key => $sec):
                $sec_done = 0; $sec_total = count($sec['items']);
                foreach($sec['items'] as $key => $item) {
                    if(!empty($cl_state[$key])) $sec_done++;
                }
                $sec_pct = $sec_total ? round($sec_done/$sec_total*100) : 0;
                $is_open = in_array($sec_key, $default_open);
                $is_complete = ($sec_done === $sec_total && $sec_total > 0);
            ?>
            <div class="er-accordion <?php echo $is_open ? 'er-acc-open' : ''; ?>" id="er-acc-<?php echo $sec_key; ?>">
                <div class="er-acc-header" onclick="erToggleAcc('<?php echo $sec_key; ?>')">
                    <span class="er-acc-letter <?php echo $is_complete ? 'er-acc-letter-done' : ''; ?>"><?php echo $sec_key; ?></span>
                    <span class="er-acc-title"><?php echo esc_html($sec['title']); ?></span>
                    <?php if($sec['agent'] && isset($agents_map[$sec['agent']])): ?>
                    <span class="er-acc-agent-badge"><?php echo esc_html($agents_map[$sec['agent']]['icon']); ?> Agente</span>
                    <?php endif; ?>
                    <span class="er-acc-progress <?php echo $is_complete ? 'er-acc-progress-done' : ''; ?>"><?php echo $sec_done; ?>/<?php echo $sec_total; ?></span>
                    <span class="er-acc-arrow">▼</span>
                </div>
                <div class="er-acc-body">
                    <?php if($sec['agent'] && isset($agents_map[$sec['agent']])): 
                        $agent = $agents_map[$sec['agent']];
                    ?>
                    <div class="er-acc-cta">
                        <div class="er-acc-cta-inner">
                            <div class="er-acc-cta-info">
                                <strong><?php echo esc_html($sec['agent_label'] ?? $agent['nombre']); ?></strong>
                                <span><?php echo esc_html($sec['agent_hint'] ?? $agent['descripcion']); ?></span>
                            </div>
                            <button class="er-btn er-btn-primary er-btn-sm" 
                                    onclick="erF0CopyAgent('<?php echo esc_js($agent['id']); ?>', this)">
                                Copiar prompt →
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($sec_key === 'C'): ?>
                    <div class="er-acc-action-row">
                        <button class="er-btn er-btn-secondary er-btn-sm" onclick="erCreateCategories()">
                            ⚡ Crear categorías automáticamente
                        </button>
                        <span id="er-cat-msg" style="font-size:12px;color:#43a047"></span>
                    </div>
                    <?php endif; ?>

                    <?php if($sec_key === 'G'): ?>
                    <div class="er-acc-action-row">
                        <button class="er-btn er-btn-secondary er-btn-sm"
                                onclick="erF0CopyAgent('redactor_nota', this)">
                            ✍ Copiar prompt Agente 5 — Redactor de nota
                        </button>
                        <span style="font-size:11px;color:var(--er-text3);margin-left:6px">Completar el campo [TEMA] antes de pegar</span>
                    </div>
                    <?php endif; ?>

                    <?php foreach($sec['items'] as $key => $item):
                        $is_done = !empty($cl_state[$key]);
                        $tag     = $item[1];
                        $color   = $tag_colors[$tag] ?? 'gray';
                    ?>
                    <div class="er-check-item <?php echo $is_done ? 'er-done' : ''; ?>" 
                         data-key="<?php echo esc_attr($key); ?>"
                         onclick="erToggleCheck(this)">
                        <div class="er-checkbox <?php echo $is_done ? 'er-checked' : ''; ?>">
                            <?php if($is_done): ?>✓<?php endif; ?>
                        </div>
                        <span class="er-check-text"><?php echo esc_html($item[0]); ?></span>
                        <span class="er-check-tag er-tag-color-<?php echo $color; ?>"><?php echo esc_html($tag); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
            </div>

        </div>
    </div>

    <script>
    var erF0Context = <?php echo json_encode($ctx_content); ?>;
    var erF0Agents  = <?php echo json_encode($agents_map); ?>;

    // Accordion
    function erToggleAcc(key) {
        var el = document.getElementById('er-acc-' + key);
        el.classList.toggle('er-acc-open');
    }

    // Copy agent prompt from Fase 0 (no modal, direct to clipboard)
    window.erF0CopyAgent = function(agentId, btn) {
        var agent = erF0Agents[agentId];
        if (!agent) return;
        var ctx = erF0Context || '[CONTEXTO NO DISPONIBLE — subir contexto en la pestaña Contexto]';
        var prompt = agent.prompt_template.replace('{{CONTEXTO}}', ctx);
        erCopyText(prompt);
        var orig = btn.textContent;
        btn.textContent = '✓ Copiado — pegalo en Claude';
        btn.style.background = '#43a047';
        setTimeout(function(){ btn.textContent = orig; btn.style.background = ''; }, 3000);
    };
    </script>
    <?php
}
