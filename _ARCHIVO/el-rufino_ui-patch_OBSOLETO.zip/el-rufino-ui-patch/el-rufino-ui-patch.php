<?php
/**
 * Plugin Name: El Rufino UI Patch
 * Description: Ajustes finos de maquetación para la portada editorial de El Rufino.
 * Version: 1.0.0
 * Author: OpenAI
 */

if (!defined('ABSPATH')) {
    exit;
}

function eruip_enqueue_assets() {
    wp_enqueue_style(
        'eruip-style',
        plugin_dir_url(__FILE__) . 'assets/el-rufino-ui-patch.css',
        [],
        '1.0.0'
    );
    wp_enqueue_script(
        'eruip-script',
        plugin_dir_url(__FILE__) . 'assets/el-rufino-ui-patch.js',
        [],
        '1.0.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'eruip_enqueue_assets', 30);
