document.addEventListener('DOMContentLoaded', function () {
  var waBox = document.querySelector('.erui-wa-box');
  if (!waBox) return;

  var button = waBox.querySelector('a.erui-btn');
  var text = waBox.querySelector('p');
  if (!button || !text) return;

  var href = (button.getAttribute('href') || '').trim();
  if (href === '#' || href === '' || href === window.location.href + '#') {
    waBox.classList.add('eruip-pending');
    text.textContent = 'Canal en preparación. Cuando actives el enlace real, este bloque funcionará como acceso directo a la distribución diaria.';
    button.textContent = 'Próximamente';
    button.setAttribute('aria-disabled', 'true');
  }
});
