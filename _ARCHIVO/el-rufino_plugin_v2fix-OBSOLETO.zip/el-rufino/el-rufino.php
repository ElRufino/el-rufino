<?php
/**
 * Plugin Name: El Rufino — Panel de Operaciones
 * Plugin URI:  https://elrufino.ar
 * Description: Sistema operativo completo para El Rufino. Gestión editorial, promesas municipales, semáforos de fase, configuración del sitio y sistema de agentes IA.
 * Version:     2.0.0
 * Author:      El Rufino
 * Text Domain: el-rufino
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ER_VERSION', '2.0.0' );
define( 'ER_PATH', plugin_dir_path( __FILE__ ) );
define( 'ER_URL',  plugin_dir_url( __FILE__ ) );

// --- Activation: create DB tables ---
register_activation_hook( __FILE__, 'er_activate' );
function er_activate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    // Promises table
    $sql1 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}er_promesas (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        codigo      VARCHAR(20) NOT NULL,
        fecha       DATE NOT NULL,
        quien       VARCHAR(200) NOT NULL,
        promesa     TEXT NOT NULL,
        plataforma  VARCHAR(100),
        seg_30      TEXT,
        seg_90      TEXT,
        estado      VARCHAR(30) DEFAULT 'pendiente',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;";

    // Context store
    $sql2 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}er_contexto (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        nombre      VARCHAR(200) NOT NULL,
        contenido   LONGTEXT NOT NULL,
        activo      TINYINT(1) DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;";

    // Phase checklist state
    $sql3 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}er_checklist (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        item_key    VARCHAR(100) NOT NULL UNIQUE,
        completado  TINYINT(1) DEFAULT 0,
        updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) $charset;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql1 );
    dbDelta( $sql2 );
    dbDelta( $sql3 );

    // Set default options
    add_option( 'er_wa_suscriptores', 0 );
    add_option( 'er_fase_actual', 0 );
    add_option( 'er_fase_estado', json_encode([
        'f0' => 'proceso', 'f1' => 'pendiente', 'f2' => 'pendiente', 'f3' => 'pendiente'
    ]));
    add_option( 'er_setup_done', 0 );

    // Create default categories
    er_create_default_categories();

    // Seed default context
    er_seed_context();
}

function er_create_default_categories() {
    $cats = [
        'Actualidad'        => 'Noticias verificadas con contexto. Lo que pasó y lo que significa.',
        'Seguimiento'       => 'Registro visible de promesas, obras y anuncios que el medio no abandona.',
        'Poder y gestión'   => 'Seguimiento de promesas, obras, presupuesto y política local.',
        'Barrio a barrio'   => 'Inundaciones, cloacas, empedrado, viviendas. Geografía del reclamo vecinal.',
        'El campo habla'    => 'Cobertura seria de economía regional. Rutas, costos, cosecha, política agraria.',
        'Rufino en datos'   => 'Contenido basado en números locales: INDEC, presupuesto municipal, salud, educación.',
        'Generación Rufino' => 'Jóvenes, emprendedores, artistas, deportistas. Contrarrestar la narrativa de éxodo.',
    ];
    foreach ( $cats as $name => $desc ) {
        if ( ! term_exists( $name, 'category' ) ) {
            wp_insert_term( $name, 'category', [ 'description' => $desc ] );
        }
    }
}

function er_seed_context() {
    global $wpdb;
    $existing = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}er_contexto");
    if ( $existing > 0 ) return;
    $wpdb->insert( $wpdb->prefix . 'er_contexto', [
        'nombre'    => 'Contexto base — El Rufino v1.0',
        'contenido' => er_get_base_context(),
        'activo'    => 1,
    ]);
}

// --- Admin menu ---
add_action( 'admin_menu', 'er_admin_menu' );
function er_admin_menu() {
    add_menu_page(
        'El Rufino',
        'El Rufino',
        'manage_options',
        'el-rufino',
        'er_render_main',
        'dashicons-flag',
        2
    );
    $pages = [
        'Fase 0'    => 'er_render_fase0',
        'Promesas'  => 'er_render_promesas',
        'Calendario'=> 'er_render_calendario',
        'Redes'     => 'er_render_redes',
        'Drive'     => 'er_render_drive',
        'Contexto'  => 'er_render_contexto',
        'Agentes IA'=> 'er_render_agentes',
    ];
    foreach ( $pages as $title => $cb ) {
        $slug = 'el-rufino-' . sanitize_title($title);
        add_submenu_page( 'el-rufino', $title, $title, 'manage_options', $slug, $cb );
    }
}

// --- Enqueue assets ---
add_action( 'admin_enqueue_scripts', 'er_enqueue' );
function er_enqueue( $hook ) {
    if ( strpos($hook, 'el-rufino') === false ) return;
    wp_enqueue_style( 'er-style', ER_URL . 'assets/style.css', [], ER_VERSION );
    wp_enqueue_script( 'er-script', ER_URL . 'assets/script.js', ['jquery'], ER_VERSION, true );
    wp_localize_script( 'er-script', 'ER', [
        'ajax' => admin_url('admin-ajax.php'),
        'nonce'=> wp_create_nonce('er_nonce'),
    ]);
}

// --- AJAX handlers ---
add_action( 'wp_ajax_er_save_checklist', 'er_ajax_save_checklist' );
function er_ajax_save_checklist() {
    check_ajax_referer('er_nonce','nonce');
    global $wpdb;
    $key  = sanitize_key($_POST['item_key']);
    $done = intval($_POST['completado']);
    $wpdb->replace( $wpdb->prefix . 'er_checklist', [
        'item_key'   => $key,
        'completado' => $done,
        'updated_at' => current_time('mysql'),
    ]);
    wp_send_json_success(['key'=>$key,'done'=>$done]);
}

add_action( 'wp_ajax_er_save_promesa', 'er_ajax_save_promesa' );
function er_ajax_save_promesa() {
    check_ajax_referer('er_nonce','nonce');
    global $wpdb;
    $data = [
        'codigo'    => sanitize_text_field($_POST['codigo']),
        'fecha'     => sanitize_text_field($_POST['fecha']),
        'quien'     => sanitize_text_field($_POST['quien']),
        'promesa'   => sanitize_textarea_field($_POST['promesa']),
        'plataforma'=> sanitize_text_field($_POST['plataforma']),
        'seg_30'    => sanitize_textarea_field($_POST['seg_30'] ?? ''),
        'seg_90'    => sanitize_textarea_field($_POST['seg_90'] ?? ''),
        'estado'    => sanitize_text_field($_POST['estado']),
    ];
    if ( !empty($_POST['id']) ) {
        $wpdb->update( $wpdb->prefix . 'er_promesas', $data, ['id' => intval($_POST['id'])] );
        $id = intval($_POST['id']);
    } else {
        $wpdb->insert( $wpdb->prefix . 'er_promesas', $data );
        $id = $wpdb->insert_id;
    }
    wp_send_json_success(['id' => $id]);
}

add_action( 'wp_ajax_er_delete_promesa', 'er_ajax_delete_promesa' );
function er_ajax_delete_promesa() {
    check_ajax_referer('er_nonce','nonce');
    global $wpdb;
    $wpdb->delete( $wpdb->prefix . 'er_promesas', ['id' => intval($_POST['id'])] );
    wp_send_json_success();
}

add_action( 'wp_ajax_er_save_option', 'er_ajax_save_option' );
function er_ajax_save_option() {
    check_ajax_referer('er_nonce','nonce');
    $allowed = ['er_wa_suscriptores','er_fase_actual','er_fase_estado'];
    $key = sanitize_key($_POST['option_key']);
    if ( in_array($key, $allowed) ) {
        update_option( $key, sanitize_text_field($_POST['option_value']) );
        wp_send_json_success();
    }
    wp_send_json_error();
}

add_action( 'wp_ajax_er_save_context', 'er_ajax_save_context' );
function er_ajax_save_context() {
    check_ajax_referer('er_nonce','nonce');
    global $wpdb;
    $nombre   = sanitize_text_field($_POST['nombre']);
    $contenido= wp_kses_post($_POST['contenido']);
    $wpdb->insert( $wpdb->prefix . 'er_contexto', [
        'nombre'   => $nombre,
        'contenido'=> $contenido,
        'activo'   => 1,
    ]);
    // Deactivate others
    $wpdb->query( "UPDATE {$wpdb->prefix}er_contexto SET activo=0 WHERE id != {$wpdb->insert_id}" );
    wp_send_json_success(['id' => $wpdb->insert_id]);
}

add_action( 'wp_ajax_er_set_active_context', 'er_ajax_set_active_context' );
function er_ajax_set_active_context() {
    check_ajax_referer('er_nonce','nonce');
    global $wpdb;
    $id = intval($_POST['id']);
    $wpdb->query("UPDATE {$wpdb->prefix}er_contexto SET activo=0");
    $wpdb->update( $wpdb->prefix . 'er_contexto', ['activo'=>1], ['id'=>$id] );
    wp_send_json_success();
}

add_action( 'wp_ajax_er_get_promesas', 'er_ajax_get_promesas' );
function er_ajax_get_promesas() {
    check_ajax_referer('er_nonce','nonce');
    global $wpdb;
    $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}er_promesas ORDER BY fecha DESC");
    wp_send_json_success($rows);
}

add_action( 'wp_ajax_er_get_checklist', 'er_ajax_get_checklist' );
function er_ajax_get_checklist() {
    check_ajax_referer('er_nonce','nonce');
    global $wpdb;
    $rows = $wpdb->get_results("SELECT item_key, completado FROM {$wpdb->prefix}er_checklist");
    $result = [];
    foreach($rows as $r) $result[$r->item_key] = (bool)$r->completado;
    wp_send_json_success($result);
}

add_action( 'wp_ajax_er_create_categories', 'er_ajax_create_categories' );
function er_ajax_create_categories() {
    check_ajax_referer('er_nonce','nonce');
    er_create_default_categories();
    wp_send_json_success(['message'=>'Categorías creadas.']);
}

// --- Load sub-pages ---
require_once ER_PATH . 'pages/main.php';
require_once ER_PATH . 'pages/fase0.php';
require_once ER_PATH . 'pages/promesas.php';
require_once ER_PATH . 'pages/calendario.php'; // includes er_render_redes() and er_render_drive()
require_once ER_PATH . 'pages/contexto.php';
require_once ER_PATH . 'pages/agentes.php';
require_once ER_PATH . 'includes/context-data.php';
