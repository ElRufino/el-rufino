<?php get_header(); ?>

<main>
<div class="er-container">
<div class="er-main">

  <!-- ════════════════════════════
       COLUMNA PRINCIPAL
  ════════════════════════════ -->
  <div>

    <!-- EDITORIAL -->
    <div class="er-editorial">
      <div class="er-editorial-kicker">Editorial · Criterio Archivístico</div>
      <div class="er-editorial-titulo">Dar voz a lo que casi se pierde: el registro sonoro del sur santafesino</div>
      <div class="er-editorial-cuerpo">Entre 2007 y 2012, el ciclo de entrevistas radiales de Rufino construyó un corpus documental único sobre la vida política, productiva y cultural del sur santafesino. Este archivo busca preservar esas voces, catalogarlas con rigor y ponerlas a disposición de investigadores, periodistas y la comunidad. Cada registro es un fragmento de memoria territorial.</div>
    </div>

    <!-- DESTACADAS -->
    <?php
    $dest = new WP_Query([
        'post_type'      => 'entrevista',
        'posts_per_page' => 3,
        'meta_key'       => 'er_destacada',
        'meta_value'     => '1',
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);
    if ($dest->have_posts()):
    ?>
    <div class="er-section-label">Entrevistas Destacadas</div>
    <div class="er-hero">
    <?php
    $i = 0;
    while ($dest->have_posts()): $dest->the_post();
      $pid    = get_the_ID();
      $cats   = get_the_terms($pid, 'cat_entrevista');
      $cat    = $cats ? $cats[0] : null;
      $slug   = $cat ? $cat->slug : 'politica';
      $color  = er_cat_color($slug);
      $nombre = er_cat_nombre($slug);
      $quien  = get_post_meta($pid,'er_nombre',true);
      $cargo  = get_post_meta($pid,'er_cargo',true);
      $fecha  = get_post_meta($pid,'er_fecha',true);
      $id_doc = get_post_meta($pid,'er_id_doc',true);
      $audio  = get_post_meta($pid,'er_audio',true);
      $main   = ($i === 0);
    ?>
    <div class="<?php echo $main ? 'er-hero-main er-card' : 'er-hero-sec er-card'; ?>">
      <div class="er-card-img <?php echo $main ? 'er-card-img-main' : 'er-card-img-sec'; ?>">
        <?php if (has_post_thumbnail()): ?>
          <?php the_post_thumbnail($main ? 'er-hero' : 'er-card', ['class'=>'er-post-thumb','loading'=>'eager']); ?>
        <?php else: ?>
          <div class="er-post-thumb" style="width:100%;height:100%;background:linear-gradient(135deg,#f9f9f9 0%,#f0f0f0 100%);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:.5rem">
            <span style="font-family:var(--f-cond);font-size:.65rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:<?php echo $color; ?>"><?php echo esc_html($nombre); ?></span>
          </div>
        <?php endif; ?>
        <?php echo er_badge($pid); ?>
      </div>
      <div class="<?php echo $main ? 'er-card-body er-card-body-main' : 'er-card-body'; ?>">
        <span class="er-card-cat" style="color:<?php echo $color; ?>"><?php echo esc_html($nombre); ?></span>
        <div class="er-card-titulo <?php echo $main ? 'er-card-titulo-main' : 'er-card-titulo-sec'; ?>">
          <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </div>
        <?php if ($quien): ?>
        <div class="er-card-quien"><?php echo esc_html($quien.($cargo ? ' · '.$cargo : '')); ?></div>
        <?php endif; ?>
        <?php if ($main): ?>
        <div class="er-card-extracto"><?php echo wp_trim_words(get_the_excerpt(), 30); ?></div>
        <?php endif; ?>
        <div class="er-card-meta">
          <?php if ($fecha): ?><span><?php echo esc_html($fecha); ?></span><?php endif; ?>
          <?php if ($id_doc): ?><span class="er-card-id"><?php echo esc_html($id_doc); ?></span><?php endif; ?>
        </div>
        <?php if ($audio && $main): ?>
        <div class="er-audio-wrap">
          <div class="er-audio-lbl">🎧 Escuchar entrevista</div>
          <audio controls src="<?php echo esc_url($audio); ?>" preload="none"></audio>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php $i++; endwhile; wp_reset_postdata(); ?>
    </div>
    <?php endif; ?>

    <!-- AD SLOT 5 — LEADERBOARD INTERMEDIO -->
    <div class="er-ad-slot er-ad-mid">
      <?php echo do_shortcode('[er_slot id="5"]'); ?>
    </div>

    <!-- ÚLTIMAS INCORPORACIONES -->
    <?php
    $recientes = new WP_Query([
        'post_type'      => 'entrevista',
        'posts_per_page' => 8,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);
    if ($recientes->have_posts()):
    ?>
    <div class="er-section-label">Últimas Incorporaciones</div>
    <div class="er-strip">
    <?php $n = 1; while ($recientes->have_posts()): $recientes->the_post();
      $pid  = get_the_ID();
      $cats = get_the_terms($pid,'cat_entrevista');
      $cat  = $cats ? $cats[0] : null;
      $slug = $cat ? $cat->slug : 'politica';
    ?>
    <div class="er-strip-item">
      <div class="er-strip-n"><?php echo str_pad($n++, 2, '0', STR_PAD_LEFT); ?></div>
      <div>
        <div class="er-strip-titulo"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
        <div class="er-strip-meta" style="color:<?php echo er_cat_color($slug); ?>"><?php echo esc_html(er_cat_nombre($slug)); ?> · <?php echo esc_html(get_post_meta($pid,'er_nombre',true)); ?> · <?php echo esc_html(get_post_meta($pid,'er_anio',true)); ?></div>
      </div>
    </div>
    <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <?php endif; ?>

    <!-- AD SLOT 6 — BANNER INTERTEMÁTICO -->
    <div class="er-ad-slot er-ad-banner">
      <?php echo do_shortcode('[er_slot id="6"]'); ?>
    </div>

    <!-- FILTROS + ARCHIVO COMPLETO -->
    <div class="er-section-label">Archivo Completo</div>

    <div class="er-filtros">
      <div class="er-filtros-row">
        <span class="er-filtro-lbl">Categoría</span>
        <a href="<?php echo esc_url(home_url('/')); ?>"
           class="er-chip <?php echo (is_front_page()&&!is_tax())?'active':''; ?>">Todas</a>
        <?php
        $all_cats = get_terms(['taxonomy'=>'cat_entrevista','hide_empty'=>false]);
        $queried  = is_tax('cat_entrevista') ? get_queried_object() : null;
        if (!is_wp_error($all_cats)):
          foreach ($all_cats as $tc):
            $active = ($queried && $queried->term_id === $tc->term_id) ? 'active' : '';
        ?>
        <a href="<?php echo esc_url(get_term_link($tc)); ?>"
           class="er-chip <?php echo $active; ?>">
          <?php echo esc_html(er_cat_nombre($tc->slug)); ?>
        </a>
        <?php endforeach; endif; ?>
      </div>
    </div>

    <!-- GRILLA ARCHIVO -->
    <?php
    $archivo_args = [
        'post_type'      => 'entrevista',
        'posts_per_page' => 12,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ];
    if (is_tax('cat_entrevista')) {
        $archivo_args['tax_query'] = [[
            'taxonomy' => 'cat_entrevista',
            'field'    => 'term_id',
            'terms'    => get_queried_object()->term_id,
        ]];
    }
    $archivo = new WP_Query($archivo_args);
    ?>
    <div class="er-grid">
    <?php if ($archivo->have_posts()): while ($archivo->have_posts()): $archivo->the_post();
      $pid   = get_the_ID();
      $cats  = get_the_terms($pid,'cat_entrevista');
      $cat   = $cats ? $cats[0] : null;
      $slug  = $cat ? $cat->slug : 'politica';
      $audio = get_post_meta($pid,'er_audio',true);
      $quien = get_post_meta($pid,'er_nombre',true);
      $fecha = get_post_meta($pid,'er_fecha',true);
      $id_doc= get_post_meta($pid,'er_id_doc',true);
    ?>
    <div class="er-grid-card">
      <div class="er-card-img">
        <?php if (has_post_thumbnail()): ?>
          <?php the_post_thumbnail('er-strip',['class'=>'er-post-thumb','loading'=>'lazy']); ?>
        <?php else: ?>
          <div class="er-post-thumb" style="height:125px;background:linear-gradient(135deg,#f9f9f9,#f0f0f0);display:flex;align-items:center;justify-content:center"><span style="font-family:var(--f-cond);font-size:.6rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:<?php echo er_cat_color($slug); ?>"><?php echo esc_html(er_cat_nombre($slug)); ?></span></div>
        <?php endif; ?>
        <?php echo er_badge($pid); ?>
      </div>
      <span class="er-card-cat" style="color:<?php echo er_cat_color($slug); ?>"><?php echo esc_html(er_cat_nombre($slug)); ?></span>
      <div class="er-card-titulo" style="font-size:.83rem;margin:.3rem 0"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
      <?php if ($quien): ?><div class="er-card-quien"><?php echo esc_html($quien); ?></div><?php endif; ?>
      <div class="er-card-meta"><?php echo esc_html($fecha); ?><?php if ($id_doc): ?><span class="er-card-id"><?php echo esc_html($id_doc); ?></span><?php endif; ?></div>
      <?php if ($audio): ?><audio controls src="<?php echo esc_url($audio); ?>" preload="none"></audio><?php endif; ?>
    </div>
    <?php endwhile; wp_reset_postdata();
    else: ?>
    <div class="er-no-results">Sin entrevistas para esta selección</div>
    <?php endif; ?>
    </div>

    <!-- AD SLOT 9 — LEADERBOARD BLOQUE FINAL -->
    <div class="er-ad-slot er-ad-final">
      <?php echo do_shortcode('[er_slot id="9"]'); ?>
    </div>

    <!-- GRILLA FINAL + SLOT 10 -->
    <?php
    $gf = new WP_Query(['post_type'=>'entrevista','posts_per_page'=>2,'orderby'=>'rand']);
    ?>
    <div class="er-grilla-final">
    <?php $gn=0; while($gf->have_posts()): $gf->the_post();
      if($gn===1): ?>
      <div style="padding:0"><div class="er-ad-slot" style="width:100%;height:100%;min-height:180px"><?php echo do_shortcode('[er_slot id="10"]'); ?></div></div>
    <?php endif;
      $pid2=get_the_ID();
      $cats2=get_the_terms($pid2,'cat_entrevista');$cat2=$cats2?$cats2[0]:null;$slug2=$cat2?$cat2->slug:'politica';
    ?>
    <div class="er-grilla-art">
      <span class="er-card-cat" style="color:<?php echo er_cat_color($slug2); ?>"><?php echo esc_html(er_cat_nombre($slug2)); ?></span>
      <div class="er-grilla-titulo"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
      <div class="er-grilla-meta"><?php echo esc_html(get_post_meta($pid2,'er_nombre',true)); ?> · <?php echo esc_html(get_post_meta($pid2,'er_anio',true)); ?></div>
    </div>
    <?php $gn++; endwhile; wp_reset_postdata();
    if($gn<2): ?><div style="padding:0"><div class="er-ad-slot" style="width:100%;height:100%;min-height:180px"><?php echo do_shortcode('[er_slot id="10"]'); ?></div></div><?php endif; ?>
    </div>

  </div><!-- /columna principal -->

  <!-- ════════════════════════════
       SIDEBAR
  ════════════════════════════ -->
  <aside class="er-sidebar">

    <!-- AD SLOT 3 — BOX LATERAL 1 -->
    <div class="er-ad-slot er-ad-sidebar">
      <?php echo do_shortcode('[er_slot id="3"]'); ?>
    </div>

    <!-- WIDGET: ESTADO DEL ARCHIVO -->
    <div class="er-widget">
      <div class="er-widget-titulo">Estado del Archivo</div>
      <?php
      $total_e   = (int)(wp_count_posts('entrevista')->publish ?? 0);
      $revisados = count(get_posts(['post_type'=>'entrevista','numberposts'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'er_estado','value'=>'revisado']]]));
      $pendientes= count(get_posts(['post_type'=>'entrevista','numberposts'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'er_estado','value'=>'pendiente']]]));
      $digital   = count(get_posts(['post_type'=>'entrevista','numberposts'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'er_estado','value'=>'digitalizar']]]));
      ?>
      <div>
        <div class="er-stat-row"><span>Total entrevistas</span><span class="er-stat-num"><?php echo $total_e; ?></span></div>
        <div class="er-stat-row"><span>Revisadas</span><span class="er-stat-num" style="color:var(--verde)"><?php echo $revisados; ?></span></div>
        <div class="er-stat-row"><span>Pendientes</span><span class="er-stat-num" style="color:var(--naranja)"><?php echo $pendientes; ?></span></div>
        <div class="er-stat-row"><span>A digitalizar</span><span class="er-stat-num" style="color:var(--morado)"><?php echo $digital; ?></span></div>
        <div class="er-stat-row"><span>Período</span><span class="er-stat-num">2007–2012</span></div>
      </div>
    </div>

    <!-- WIDGET: LO MÁS CONSULTADO -->
    <div class="er-widget">
      <div class="er-widget-titulo">Lo más consultado</div>
      <?php
      $top = new WP_Query(['post_type'=>'entrevista','posts_per_page'=>7,'orderby'=>'comment_count','order'=>'DESC']);
      $n=1; while($top->have_posts()): $top->the_post();
        $pid_t=get_the_ID();
        $cats_t=get_the_terms($pid_t,'cat_entrevista');$cat_t=$cats_t?$cats_t[0]:null;$slug_t=$cat_t?$cat_t->slug:'politica';
      ?>
      <div class="er-top-item">
        <div class="er-top-n"><?php echo $n++; ?></div>
        <div>
          <div class="er-top-titulo"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
          <div class="er-top-meta" style="color:<?php echo er_cat_color($slug_t); ?>"><?php echo esc_html(er_cat_nombre($slug_t)); ?></div>
        </div>
      </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>

    <!-- AD SLOT 7 — BOX SIDEBAR STICKY -->
    <div class="er-ad-slot er-ad-sidebar" style="position:sticky;top:52px">
      <?php echo do_shortcode('[er_slot id="7"]'); ?>
    </div>

    <!-- WIDGET: COLUMNA EDITORIAL -->
    <div class="er-widget">
      <div class="er-widget-titulo">Criterio Archivístico</div>
      <div class="er-columna">
        "El documento sonoro no es solo información: es atmósfera, acento, emoción. Preservarlo es preservar la textura de una época que los textos escritos no pueden capturar del todo."
      </div>
      <div class="er-columna-firma">— Equipo editorial · El Rufino</div>
    </div>

    <!-- AD SLOT 8 — BOX SIDEBAR INFERIOR -->
    <div class="er-ad-slot er-ad-sidebar">
      <?php echo do_shortcode('[er_slot id="8"]'); ?>
    </div>

  </aside>

</div><!-- /main -->
</div><!-- /container -->
</main>

<?php get_footer(); ?>
