<?php
// sidebar.php — widgets que NO están en index.php
// Estos se usan en archive-entrevista.php
?>
<div class="er-ad-slot er-ad-sidebar"><?php echo do_shortcode('[er_slot id="3"]'); ?></div>
<div class="er-widget">
  <div class="er-widget-titulo">Secciones</div>
  <?php $cats=get_terms(['taxonomy'=>'cat_entrevista','hide_empty'=>false]);
  if(!is_wp_error($cats)) foreach($cats as $c): ?>
  <div style="padding:.3rem 0;border-bottom:1px solid var(--linea-suave)">
    <a href="<?php echo esc_url(get_term_link($c)); ?>" style="font-family:var(--f-cond);font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:<?php echo er_cat_color($c->slug); ?>;text-decoration:none"><?php echo esc_html(er_cat_nombre($c->slug)); ?></a>
  </div>
  <?php endforeach; ?>
</div>
<div class="er-ad-slot er-ad-sidebar" style="position:sticky;top:52px"><?php echo do_shortcode('[er_slot id="7"]'); ?></div>
