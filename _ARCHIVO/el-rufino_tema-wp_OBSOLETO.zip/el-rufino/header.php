<?php
/**
 * header.php — El Rufino
 * Tema hijo de Hello Elementor
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ═══ TOPBAR ═══ -->
<div class="er-topbar">
  <div class="er-topbar-inner">
    <div class="er-topbar-left">
      <div class="er-topbar-item" id="er-fecha-item">
        <span id="er-fecha"></span>
      </div>
      <div class="er-topbar-item">📻 Archivo 2007–2012 · Sur santafesino</div>
    </div>
    <div class="er-topbar-right">
      <span style="font-family:var(--f-cond);font-size:.6rem;letter-spacing:.06em;color:var(--gris-5)">elrufino.com.ar</span>
      <?php if (current_user_can('manage_options')): ?>
      <a href="<?php echo esc_url(admin_url('admin.php?page=vdi-setup')); ?>" class="er-admin-btn">⚙ Admin</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ═══ AD SLOT 1 — LEADERBOARD SUPERIOR ═══ -->
<div class="er-ad-slot er-ad-top">
  <?php echo do_shortcode('[er_slot id="1"]'); ?>
</div>

<!-- ═══ HEADER ═══ -->
<header class="er-header">
  <div class="er-header-inner">
    <div class="er-header-left">
      <div class="er-header-sub">Rufino · Santa Fe · Argentina</div>
      <div class="er-header-meta">Noticias · Archivo · Comunidad</div>
    </div>

    <div class="er-logo">
      <a href="<?php echo esc_url(home_url('/')); ?>" title="El Rufino — Inicio">
        <span class="er-logo-el">el</span>
        <span class="er-logo-rufino">Rufino</span>
        <div class="er-logo-tagline">Periódico Digital del Sur Santafesino</div>
      </a>
    </div>

    <div class="er-header-right">
      <!-- AD SLOT 2 — HEADER DERECHA -->
      <div class="er-ad-slot er-ad-hdr-r">
        <?php echo do_shortcode('[er_slot id="2"]'); ?>
      </div>
    </div>
  </div>
</header>

<!-- ═══ TICKER ═══ -->
<div class="er-ticker">
  <div class="er-ticker-label">HOY</div>
  <div class="er-ticker-track">
    <div class="er-ticker-content">
      <?php
      $items = [
        'Archivo de entrevistas radiales 2007–2012 disponible en línea',
        'Rufino · Sur santafesino · Política, salud, agro, cultura y más',
        'Nuevo: entrevistas de la categoría sindical y educación incorporadas',
        'elrufino.com.ar · El periódico digital de Rufino y la región',
        'Archivo de entrevistas radiales 2007–2012 disponible en línea',
        'Rufino · Sur santafesino · Política, salud, agro, cultura y más',
        'Nuevo: entrevistas de la categoría sindical y educación incorporadas',
        'elrufino.com.ar · El periódico digital de Rufino y la región',
      ];
      foreach ($items as $item): ?>
      <span class="er-ticker-item"><?php echo esc_html($item); ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ═══ NAVBAR STICKY ═══ -->
<nav class="er-navbar" role="navigation" aria-label="Navegación principal">
  <div class="er-navbar-inner">
    <div class="er-nav-links">
      <!-- "Todas" siempre primero, con clase active en portada -->
      <a href="<?php echo esc_url(home_url('/')); ?>"
         class="er-nav-link <?php echo (is_front_page() && !is_tax()) ? 'active' : ''; ?>">
        Todas
      </a>
      <?php
      // Categorías en orden editorial
      $orden = ['politica','salud','agro','sindical','educacion','cultura','social','economia'];
      $cats  = get_terms(['taxonomy'=>'cat_entrevista','hide_empty'=>false,'number'=>20]);

      if (!is_wp_error($cats) && $cats) {
          // Ordenar según el orden editorial definido
          usort($cats, function($a, $b) use ($orden) {
              $pa = array_search($a->slug, $orden);
              $pb = array_search($b->slug, $orden);
              return ($pa === false ? 99 : $pa) - ($pb === false ? 99 : $pb);
          });

          $queried = is_tax('cat_entrevista') ? get_queried_object() : null;

          foreach ($cats as $cat):
              $active = ($queried && $queried->term_id === $cat->term_id) ? 'active' : '';
          ?>
          <a href="<?php echo esc_url(get_term_link($cat)); ?>"
             class="er-nav-link <?php echo $active; ?>">
            <?php echo esc_html(er_cat_nombre($cat->slug)); ?>
          </a>
          <?php endforeach;
      } ?>
    </div>

    <!-- Búsqueda mínima -->
    <div style="font-family:var(--f-cond);font-size:.65rem;color:var(--gris-4);letter-spacing:.05em;cursor:pointer;padding:0 .5rem;flex-shrink:0" onclick="document.getElementById('er-search-bar').classList.toggle('visible')">
      🔍
    </div>
  </div>
  <!-- Barra de búsqueda expandible -->
  <div id="er-search-bar" style="display:none;padding:.4rem 1.25rem;border-top:1px solid var(--linea);background:var(--gris-7)">
    <?php get_search_form(); ?>
  </div>
</nav>
