=== El Rufino Bootstrap ===
Con este plugin se configura una base inicial para el sitio de El Rufino en WordPress.

Qué hace al activarlo:
- Cambia el título del sitio a “El Rufino”
- Cambia la descripción corta a “Lo que pasa y lo que significa.”
- Desalienta indexación de buscadores (staging)
- Activa estructura de enlaces amigables /%postname%/
- Crea páginas base
- Crea categorías editoriales
- Borra “Hello world!” y la página de ejemplo si existen
- Configura portada estática y página de entradas
- Crea un menú principal y lo asigna a la primera ubicación disponible del tema

Nota:
La apariencia final sigue dependiendo del tema activo. El plugin arma la estructura editorial y limpia el arranque.
