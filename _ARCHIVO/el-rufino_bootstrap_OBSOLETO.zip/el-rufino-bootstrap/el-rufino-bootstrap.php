<?php
/**
 * Plugin Name: El Rufino Bootstrap
 * Description: Configura la base editorial inicial de El Rufino: páginas, categorías, portada estática, menú, limpieza de contenido por defecto y ajustes básicos de staging.
 * Version: 0.1.0
 * Author: OpenAI
 * License: GPLv2 or later
 * Text Domain: el-rufino-bootstrap
 */

if (!defined('ABSPATH')) {
    exit;
}

final class El_Rufino_Bootstrap {
    const VERSION = '0.1.0';
    const OPTION_SETUP = 'el_rufino_bootstrap_setup_done';
    const OPTION_NOTICE = 'el_rufino_bootstrap_admin_notice';

    public static function init() {
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        add_action('admin_notices', [__CLASS__, 'admin_notice']);
    }

    public static function activate() {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        // Identidad base del sitio.
        update_option('blogname', 'El Rufino');
        update_option('blogdescription', 'Lo que pasa y lo que significa.');

        // Staging: desalentar indexación.
        update_option('blog_public', '0');

        // Estructura de enlaces amigables.
        global $wp_rewrite;
        update_option('permalink_structure', '/%postname%/');
        if ($wp_rewrite instanceof WP_Rewrite) {
            $wp_rewrite->set_permalink_structure('/%postname%/');
            $wp_rewrite->flush_rules();
        } else {
            flush_rewrite_rules();
        }

        $page_ids = self::ensure_pages();
        self::ensure_categories();
        self::cleanup_defaults();
        self::set_front_and_posts_pages($page_ids);
        self::ensure_menu($page_ids);

        update_option(self::OPTION_SETUP, [
            'version' => self::VERSION,
            'timestamp' => current_time('mysql'),
            'pages' => $page_ids,
        ]);
        set_transient(self::OPTION_NOTICE, 1, 60);
    }

    private static function ensure_pages() {
        $pages = [
            'inicio' => [
                'title' => 'Inicio',
                'content' => self::default_home_content(),
            ],
            'actualidad' => [
                'title' => 'Actualidad',
                'content' => '<!-- Página de entradas / noticias -->',
            ],
            'seguimiento' => [
                'title' => 'Seguimiento',
                'content' => self::default_page_intro('Seguimiento', 'Acá irá el registro público de promesas, obras, temas abiertos y su estado de actualización.'),
            ],
            'poder-gestion' => [
                'title' => 'Poder y gestión',
                'content' => self::default_page_intro('Poder y gestión', 'Espacio para notas sobre decisiones públicas, anuncios, presupuestos, obras y seguimiento institucional.'),
            ],
            'barrio-barrio' => [
                'title' => 'Barrio a barrio',
                'content' => self::default_page_intro('Barrio a barrio', 'Cobertura territorial de reclamos, servicios, infraestructura y vida urbana en Rufino.'),
            ],
            'campo' => [
                'title' => 'El campo habla',
                'content' => self::default_page_intro('El campo habla', 'Cobertura de producción, rutas, logística, costos y economía regional.'),
            ],
            'datos' => [
                'title' => 'Rufino en datos',
                'content' => self::default_page_intro('Rufino en datos', 'Página para visualizaciones, series, indicadores y piezas explicativas basadas en datos locales.'),
            ],
            'sobre' => [
                'title' => 'Sobre El Rufino',
                'content' => self::about_content(),
            ],
            'contacto' => [
                'title' => 'Contacto',
                'content' => self::default_page_intro('Contacto', 'Canal abierto para enviar información, proponer temas, corregir datos o acercar material de interés público.'),
            ],
        ];

        $page_ids = [];
        foreach ($pages as $slug => $data) {
            $existing = get_page_by_path($slug, OBJECT, 'page');
            if ($existing instanceof WP_Post) {
                $page_ids[$slug] = (int) $existing->ID;
                wp_update_post([
                    'ID' => $existing->ID,
                    'post_title' => $data['title'],
                ]);
                continue;
            }

            $page_ids[$slug] = wp_insert_post([
                'post_type' => 'page',
                'post_status' => 'publish',
                'post_title' => $data['title'],
                'post_name' => $slug,
                'post_content' => $data['content'],
                'comment_status' => 'closed',
            ]);
        }

        return $page_ids;
    }

    private static function ensure_categories() {
        $categories = [
            'Actualidad',
            'Seguimiento',
            'Poder y gestión',
            'Barrio a barrio',
            'El campo habla',
            'Rufino en datos',
            'Generación Rufino',
            'Voces',
        ];

        foreach ($categories as $category_name) {
            if (!term_exists($category_name, 'category')) {
                wp_insert_term($category_name, 'category');
            }
        }
    }

    private static function cleanup_defaults() {
        // Hello world!
        $hello = get_page_by_title('Hello world!', OBJECT, 'post');
        if ($hello instanceof WP_Post) {
            wp_delete_post((int) $hello->ID, true);
        }

        // Página de ejemplo.
        $sample_page = get_page_by_title('Sample Page', OBJECT, 'page');
        if (!$sample_page) {
            $sample_page = get_page_by_title('Página de ejemplo', OBJECT, 'page');
        }
        if ($sample_page instanceof WP_Post) {
            wp_delete_post((int) $sample_page->ID, true);
        }

        // Comentario por defecto.
        $comments = get_comments([
            'search' => 'A WordPress Commenter',
            'number' => 20,
            'status' => 'all',
        ]);
        foreach ($comments as $comment) {
            wp_delete_comment((int) $comment->comment_ID, true);
        }
    }

    private static function set_front_and_posts_pages($page_ids) {
        if (!empty($page_ids['inicio'])) {
            update_option('show_on_front', 'page');
            update_option('page_on_front', (int) $page_ids['inicio']);
        }
        if (!empty($page_ids['actualidad'])) {
            update_option('page_for_posts', (int) $page_ids['actualidad']);
        }
    }

    private static function ensure_menu($page_ids) {
        $menu_name = 'Menú principal El Rufino';
        $menu = wp_get_nav_menu_object($menu_name);
        $menu_id = $menu ? (int) $menu->term_id : wp_create_nav_menu($menu_name);

        $items = [
            'inicio',
            'actualidad',
            'seguimiento',
            'campo',
            'barrio-barrio',
            'datos',
            'sobre',
            'contacto',
        ];

        $existing_items = wp_get_nav_menu_items($menu_id);
        $existing_object_ids = [];
        if (is_array($existing_items)) {
            foreach ($existing_items as $item) {
                $existing_object_ids[] = (int) $item->object_id;
            }
        }

        foreach ($items as $slug) {
            if (empty($page_ids[$slug])) {
                continue;
            }
            $page_id = (int) $page_ids[$slug];
            if (in_array($page_id, $existing_object_ids, true)) {
                continue;
            }
            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-title' => get_the_title($page_id),
                'menu-item-object' => 'page',
                'menu-item-object-id' => $page_id,
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish',
            ]);
        }

        $locations = get_theme_mod('nav_menu_locations', []);
        $registered = get_registered_nav_menus();
        foreach ($registered as $location => $description) {
            if (!isset($locations[$location])) {
                $locations[$location] = $menu_id;
                break; // asigna la primera ubicación libre del tema.
            }
        }
        set_theme_mod('nav_menu_locations', $locations);
    }

    public static function admin_notice() {
        if (!current_user_can('manage_options') || !get_transient(self::OPTION_NOTICE)) {
            return;
        }
        delete_transient(self::OPTION_NOTICE);
        echo '<div class="notice notice-success is-dismissible"><p><strong>El Rufino Bootstrap:</strong> se configuró la base inicial del sitio. Revisá Ajustes, Páginas, Categorías y Menús para personalizar detalles del tema activo.</p></div>';
    }

    private static function default_home_content() {
        return <<<HTML
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":1} -->
<h1>El Rufino</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Lo que pasa y lo que significa.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Este es el entorno base de trabajo del medio. Desde acá se va a construir la portada editorial, el seguimiento de temas y la estructura del sitio definitivo.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li>Actualidad</li><li>Seguimiento</li><li>Poder y gestión</li><li>Barrio a barrio</li><li>El campo habla</li><li>Rufino en datos</li></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->
HTML;
    }

    private static function default_page_intro($title, $description) {
        $title = esc_html($title);
        $description = esc_html($description);
        return "<!-- wp:heading {\"level\":1} --><h1>{$title}</h1><!-- /wp:heading --><!-- wp:paragraph --><p>{$description}</p><!-- /wp:paragraph -->";
    }

    private static function about_content() {
        return <<<HTML
<!-- wp:heading {"level":1} -->
<h1>Sobre El Rufino</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>El Rufino</strong> es un medio digital local orientado a producir información verificada, contexto útil y seguimiento de los temas que afectan la vida cotidiana, institucional, económica y social de la ciudad.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Su regla editorial central es simple: cada contenido debe aportar al menos dos capas, el hecho y su significado.</p>
<!-- /wp:paragraph -->
HTML;
    }
}

El_Rufino_Bootstrap::init();
